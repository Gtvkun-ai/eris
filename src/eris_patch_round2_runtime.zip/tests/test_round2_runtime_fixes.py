from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest
import requests

from llm.client import OpenAICompatibleClient
from llm.key_pool import ApiKeyPool, reset_provider_circuits
from llm.service import LlmService
from llm.token_budget import PromptBlockBudget, assemble_budgeted_prompt_blocks, estimate_tokens
from memory.json_store_io import atomic_write_json
from memory.memory_cognition import MemoryCognitionCore
from memory.semantic_memory import SemanticMemoryItem, SemanticMemoryStore
from runtime.presence_controller import PresenceControllerMixin
from runtime.stage_output import SentenceSegmenter
from runtime.tts_engine import _language_hint


class _ValidJsonClient:
    base_url = "https://api.groq.com/openai/v1"
    model_name = "qwen/qwen3-32b"

    def __init__(self, *, on_call=None) -> None:
        self.calls: list[dict] = []
        self.on_call = on_call

    def create_chat_completion(self, **kwargs):
        self.calls.append(kwargs)
        if self.on_call is not None:
            self.on_call()
        payload = {
            "text": "Đã hiểu.",
            "intent": "reply",
            "action": "",
            "animation": "stand",
            "reasoning_tags": [],
            "should_speak": True,
            "confidence": 0.9,
            "direction": 0,
            "target_x": -1.0,
            "bounce_action": "",
            "extracted_fact": "",
            "debug_trace": "round2 test",
            "next_animation": "",
            "system_action": "",
            "action_input": "",
            "delivery_hint": "",
            "nonverbal_cue": "",
            "stage_motion": "",
        }
        return {"choices": [{"message": {"content": json.dumps(payload, ensure_ascii=False)}}]}


def test_sentence_segmenter_keeps_decimal_and_all_tail(monkeypatch) -> None:
    monkeypatch.setenv("ERIS_STAGE_MIN_SPLIT_CHARS", "24")
    monkeypatch.setenv("ERIS_STAGE_MAX_TTS_SEGMENTS", "4")
    text = (
        "Gemini 3.5 Flash đang chạy. "
        "Câu thứ hai đủ dài. "
        "Câu thứ ba đủ dài. "
        "Câu thứ tư đủ dài. "
        "Câu thứ năm không được mất. "
        "Câu thứ sáu cũng phải còn."
    )
    parts = SentenceSegmenter().split(text)
    assert len(parts) == 4
    assert "3.5" in parts[0]
    assert "Câu thứ năm" in parts[-1]
    assert "Câu thứ sáu" in parts[-1]
    assert " ".join(parts) == text


def test_tts_auto_defaults_to_vietnamese(monkeypatch) -> None:
    monkeypatch.delenv("ERIS_TTS_LANGUAGE", raising=False)
    assert _language_hint() == "vi"
    monkeypatch.setenv("ERIS_TTS_LANGUAGE", "auto")
    assert _language_hint() == "vi"
    monkeypatch.setenv("ERIS_TTS_LANGUAGE", "ja")
    assert _language_hint() == "ja"


def test_atomic_writer_survives_concurrent_writes(tmp_path: Path) -> None:
    target = tmp_path / "memory.json"
    errors: list[Exception] = []

    def writer(worker_id: int) -> None:
        try:
            for turn in range(25):
                atomic_write_json(target, {"worker": worker_id, "turn": turn})
        except Exception as exc:  # pragma: no cover - assertion below captures it
            errors.append(exc)

    threads = [threading.Thread(target=writer, args=(idx,)) for idx in range(8)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert errors == []
    payload = json.loads(target.read_text(encoding="utf-8"))
    assert set(payload) == {"worker", "turn"}
    assert not list(tmp_path.glob("*.tmp"))


def test_memory_lookup_ignores_contradicted_old_fact(tmp_path: Path) -> None:
    store = SemanticMemoryStore(str(tmp_path / "semantic.json"))
    store.save(
        [
            SemanticMemoryItem(
                id="old",
                claim="Tên cũ",
                status="contradicted",
                confidence=0.99,
                updated_at="2026-01-01T00:00:00+0000",
                metadata={"fact_key": "user.name", "value": "Tên cũ"},
            ),
            SemanticMemoryItem(
                id="new",
                claim="Tên mới",
                status="active",
                confidence=0.8,
                updated_at="2026-02-01T00:00:00+0000",
                metadata={"fact_key": "user.name", "value": "Tên mới"},
            ),
        ]
    )
    core = MemoryCognitionCore(str(tmp_path / "core"))
    # Dùng store fixture trực tiếp để cô lập lookup facade khỏi embedding/runtime.
    core.semantic = store
    assert core.lookup_fact("user.name") == "Tên mới"


def test_memory_save_does_not_rewrite_all_stores(tmp_path: Path, monkeypatch) -> None:
    core = MemoryCognitionCore(str(tmp_path / "core"))

    def forbidden(*_args, **_kwargs):
        raise AssertionError("save() không được rewrite store không đổi")

    monkeypatch.setattr(core.semantic, "save", forbidden)
    monkeypatch.setattr(core.relational, "save", forbidden)
    monkeypatch.setattr(core.episodic, "save", forbidden)
    core.save({"active_state": {"active_task": "test"}})
    assert core.active_state.load().active_task == "test"


class _FakeResponse(requests.Response):
    def __init__(self, status: int, payload: dict | None = None):
        super().__init__()
        self.status_code = status
        self.url = "https://provider.invalid/chat/completions"
        self.reason = "fake"
        self._content = json.dumps(payload or {"error": "fake"}).encode("utf-8")


def test_provider_5xx_does_not_poison_keys(monkeypatch) -> None:
    reset_provider_circuits()
    pool = ApiKeyPool(["key-a", "key-b"])
    client = OpenAICompatibleClient(
        base_url="https://provider.invalid/v1",
        api_key="key-a",
        model_name="model",
        key_pool=pool,
    )
    monkeypatch.setattr(requests, "post", lambda *_args, **_kwargs: _FakeResponse(503))

    with pytest.raises(requests.HTTPError):
        client.create_chat_completion(
            messages=[{"role": "user", "content": "hello"}],
            temperature=0.1,
            frequency_penalty=0.0,
            presence_penalty=0.0,
            max_tokens=32,
        )

    assert pool.stats()["dead"] == 0
    assert pool.stats()["alive"] == 2


def test_provider_auth_error_disables_only_failed_key(monkeypatch) -> None:
    reset_provider_circuits()
    pool = ApiKeyPool(["key-a", "key-b"])
    calls = {"count": 0}

    def fake_post(*_args, **_kwargs):
        calls["count"] += 1
        if calls["count"] == 1:
            return _FakeResponse(401)
        return _FakeResponse(200, {"choices": [{"message": {"content": "ok"}}]})

    monkeypatch.setattr(requests, "post", fake_post)
    client = OpenAICompatibleClient(
        base_url="https://auth.invalid/v1",
        api_key="key-a",
        model_name="model",
        key_pool=pool,
    )
    response = client.create_chat_completion(
        messages=[{"role": "user", "content": "hello"}],
        temperature=0.1,
        frequency_penalty=0.0,
        presence_penalty=0.0,
        max_tokens=32,
    )
    assert response["choices"][0]["message"]["content"] == "ok"
    assert pool.stats()["dead"] == 1


def test_generic_prompt_blocks_are_capped_before_assembly() -> None:
    huge = "khối dữ liệu " * 5000
    budget = PromptBlockBudget()
    messages, report = assemble_budgeted_prompt_blocks(
        system_rules_text=huge,
        user_text=huge,
        grounding_text=huge,
        memory_text=huge,
        state_style_text=huge,
        budget=budget,
    )
    assert report["system_rules"] <= 1800
    assert report["user_history"] <= 500
    assert report["grounding"] <= 500
    assert report["memory"] <= 400
    assert report["state_style"] <= 300
    assert estimate_tokens(messages) <= budget.input_limit


def test_directive_uses_block_budget_and_channel_timeout() -> None:
    client = _ValidJsonClient()
    service = LlmService(client, logger=logging.getLogger("test.directive_budget"))
    huge = "khối dữ liệu " * 5000
    service.generate_directive(
        telemetry_data=huge,
        ti_context=huge,
        ni_context=huge,
        fe_context=huge,
        appraisal_context=huge,
        internal_state_context=huge,
        memory_context=huge,
        avoid_text=huge,
        speech_intent="screen_observation",
    )
    assert len(client.calls) == 1
    call = client.calls[0]
    assert estimate_tokens(call["messages"]) <= 4800 - call["max_tokens"]
    assert call["timeout"] == 15.0


class _EmptyPresenceHarness(PresenceControllerMixin):
    def __init__(self) -> None:
        self.logger = logging.getLogger("test.micro_cooldown")
        self.last_text = ""
        self.calls = 0

    def _safe_local_micro_presence_fallback(self, *_args, **_kwargs):
        return ""

    def _should_try_micro_presence_llm(self, **_kwargs):
        return True

    def _micro_presence_generator(self):
        def generate(**_kwargs):
            self.calls += 1
            return ""
        return generate

    def _sanitize_micro_presence_llm_text(self, *_args, **_kwargs):
        self._last_micro_sanitize_reason = "empty"
        return ""


def test_empty_micro_draft_enters_cooldown(monkeypatch) -> None:
    monkeypatch.setenv("ERIS_MICRO_EMPTY_COOLDOWN_S", "120")
    monkeypatch.setenv("ERIS_MICRO_EMPTY_RETRY", "0")
    harness = _EmptyPresenceHarness()
    snapshot = SimpleNamespace(active_window_kind="", focus_summary="", idle_seconds=0.0)

    first = harness._hybrid_micro_presence_text(
        kind="private_life_surface",
        snapshot=snapshot,
        force_llm=True,
        signal_score=0.5,
    )
    second = harness._hybrid_micro_presence_text(
        kind="private_life_surface",
        snapshot=snapshot,
        force_llm=True,
        signal_score=0.5,
    )
    assert first[0] == ""
    assert second == ("", "empty_draft_cooldown")
    assert harness.calls == 1


def test_cancel_epoch_discards_stale_directive_result() -> None:
    service: LlmService

    def cancel_during_call() -> None:
        service.cancel_pending_requests("test")

    client = _ValidJsonClient(on_call=cancel_during_call)
    service = LlmService(client, logger=logging.getLogger("test.cancel"))
    raw = service.generate_directive(
        telemetry_data="screen unchanged",
        speech_intent="screen_observation",
    )
    payload = json.loads(raw)
    assert payload["should_speak"] is False
    assert payload["intent"] == "cancelled_stale"


def test_semantic_parser_has_no_duplicate_module_functions() -> None:
    import ast
    from memory.understanding import semantic_parser

    path = Path(semantic_parser.__file__)
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names: set[str] = set()
    duplicates: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name in names:
                duplicates.add(node.name)
            names.add(node.name)
    assert duplicates == set()
