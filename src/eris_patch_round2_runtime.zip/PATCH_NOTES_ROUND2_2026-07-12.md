# ERIS runtime fixes — round 2 (2026-07-12)

Bản này xây tiếp trên `src_34_fixed_tutor_keypool_prompt_budget.zip`.

## Đã sửa

### Memory persistence
- Thêm `memory/json_store_io.py`: lock theo file, temp file duy nhất, `flush + fsync`, retry `os.replace()` khi Windows tạm khóa file.
- Tất cả memory store chính dùng chung atomic writer.
- `MemoryCognitionCore.commit()` được serialize bằng `RLock`, bảo vệ chuỗi `load -> mutate -> save`.
- `MemoryCognitionCore.save()` không còn load rồi rewrite toàn bộ semantic/episodic/relational/... store.
- Xóa `lookup_fact()` trùng; facade luôn dùng `SemanticMemoryStore.lookup_fact()` và bỏ fact `contradicted`.

### TTS / stage output
- Không tách dấu chấm trong số thập phân, version, URL hay tên file nếu không có whitespace sau dấu chấm.
- Khi vượt `ERIS_STAGE_MAX_TTS_SEGMENTS`, phần dư được gộp vào segment cuối thay vì bị xóa.
- `ERIS_TTS_LANGUAGE` mặc định và `auto` giờ là `vi`; chỉ dùng tiếng Nhật khi cấu hình rõ `ja/jp/japanese`.

### API key và provider outage
- HTTP 429 cooldown đúng key lease.
- HTTP 401/403 khóa dài hạn đúng key lỗi và thử key tiếp theo.
- HTTP 5xx không còn đánh dấu key chết.
- Thêm provider circuit breaker dùng chung theo endpoint: mở circuit sau lỗi 5xx liên tiếp, tránh mọi worker tiếp tục đập provider đang outage.
- Timeout mặc định client giảm từ 180 giây xuống 30 giây; timeout theo channel trong `LlmService`:
  - chat: 30s
  - directive/autonomous: 15s
  - parser/repair/micro-presence: 10s

### Prompt budgeting
- Thêm `PromptBlockBudget` và `assemble_budgeted_prompt_blocks()` cho channel ngoài chat.
- Directive dùng quota block-first trước khi ghép:
  - total 4800
  - output reserve 512
  - system 1800
  - user/instruction 500
  - grounding 500
  - memory 400
  - state/style 300
- Micro-presence có budget riêng nhưng vẫn block-first và tổng 4800.
- Parser/repair legacy có hard-cap cuối để không gửi prompt vượt trần.
- DDS directive mặc định tắt vì memory đã có quota; bật lại bằng `ERIS_DIRECTIVE_HARD_BUDGET_USE_DDS=1`.

### Micro-presence
- Draft rỗng tạo cooldown theo `kind`, mặc định 120 giây và tăng tối đa 300 giây.
- Không retry request thứ hai sau draft rỗng theo mặc định.
- Có thể bật retry debug bằng `ERIS_MICRO_EMPTY_RETRY=1`, nhưng chỉ với signal mạnh và có seed.

### Cooperative cancellation
- Khi runtime bước vào chat, generation autonomous đang bay được đánh dấu stale.
- Request HTTP sync không thể bị cưỡng bức đóng an toàn, nhưng timeout đã ngắn và kết quả stale bị loại, trả decision `should_speak=false` thay vì chen vào chat.

### Cleanup
- Xóa hai hàm module trùng trong `memory/understanding/semantic_parser.py`.

## Kiểm tra
- `python -m compileall -q .`: PASS
- `python -m pytest -q`: **18 passed**
- Test bao gồm: concurrent memory writes, fact contradicted/active, save-all regression, decimal/version TTS, segment tail preservation, 503 không poison key, 401 chỉ khóa key lỗi, block prompt budget, directive timeout, empty-draft cooldown và stale generation cancellation.
