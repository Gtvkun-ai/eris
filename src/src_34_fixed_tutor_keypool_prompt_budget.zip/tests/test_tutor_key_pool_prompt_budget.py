from __future__ import annotations

import json
import logging
from types import SimpleNamespace

from cortex.fe import FeRenderer
from llm.key_pool import ApiKeyPool
from llm.service import LlmService
from llm.token_budget import ChatPromptBudget, assemble_budgeted_chat_messages, estimate_tokens
from runtime.coordinator import RuntimeCoordinator


def test_world_knowledge_intent_excludes_eris_self_identity() -> None:
    assert FeRenderer._is_world_knowledge_question("Rust là gì?") is True
    assert FeRenderer._is_world_knowledge_question("Tại sao trời có màu xanh?") is True
    assert FeRenderer._is_world_knowledge_question("hỏi Gemini xem entropy là gì") is True

    assert FeRenderer._is_world_knowledge_question("gọi tôi là bạn. bạn là cái gì") is False
    assert FeRenderer._is_world_knowledge_question("bạn là ai") is False
    assert FeRenderer._is_world_knowledge_question("bạn có cảm xúc không") is False
    assert FeRenderer._is_world_knowledge_question("sửa lỗi Python này") is False


class _TutorGateFake:
    _maybe_tutor_on_unclear_user = RuntimeCoordinator._maybe_tutor_on_unclear_user

    def __init__(self, intent: str) -> None:
        self.logger = logging.getLogger("test.tutor_gate")
        self.tutor_daemon = SimpleNamespace(config=SimpleNamespace(min_seconds_between_episodes=0.0))
        self.last_user_intent = intent
        self.request_tutor_answer = lambda *_args, **_kwargs: "answer"
        self.started: list[str] = []
        self._research_in_flight = False
        self._last_research_ts = 0.0

    def _research_can_start(self) -> bool:
        return True

    def _fire_research_followup(self, topic: str, *, context: str = "") -> None:
        self.started.append(topic)

    def _fire_tutor_lookup(self, topic: str, *, context: str = "") -> None:
        return None


def test_tutor_user_facing_gate_requires_world_knowledge_intent() -> None:
    frame = SimpleNamespace(meaning_layer=SimpleNamespace(meaning="known"))

    identity = _TutorGateFake("ordinary_dialogue")
    identity._maybe_tutor_on_unclear_user("gọi tôi là bạn. bạn là cái gì", frame)
    assert identity.started == []

    knowledge = _TutorGateFake("world_knowledge")
    knowledge._maybe_tutor_on_unclear_user("Rust là ngôn ngữ gì", frame)
    assert knowledge.started == ["Rust là ngôn ngữ gì"]


def test_key_pool_marks_the_failed_lease_not_global_cursor() -> None:
    pool = ApiKeyPool(["key-a", "key-b", "key-c"])
    lease_a = pool.acquire()
    assert lease_a is not None and lease_a.index == 0

    # Giả lập thread B đã chuyển con trỏ sang key khác trước khi request A trả 429.
    lease_b = pool.acquire(exclude_indices={lease_a.index})
    assert lease_b is not None and lease_b.index == 1

    pool.mark_dead(60.0, lease=lease_a, reason="test_http_429")
    lease_c = pool.acquire(exclude_indices={lease_b.index})
    assert lease_c is not None and lease_c.index == 2
    assert pool.stats()["dead"] == 1


def test_key_pool_stops_when_every_key_is_cooling() -> None:
    pool = ApiKeyPool(["key-a", "key-b"])
    first = pool.acquire()
    assert first is not None
    pool.mark_dead(60.0, lease=first, reason="test")
    second = pool.acquire(exclude_indices={first.index})
    assert second is not None
    pool.mark_dead(60.0, lease=second, reason="test")

    assert pool.acquire() is None
    assert pool.next_available_in() > 0.0


def test_chat_prompt_blocks_are_capped_before_assembly() -> None:
    huge = "khối dữ liệu " * 5000
    messages, report = assemble_budgeted_chat_messages(
        system_rules_text=huge,
        state_style_text=huge,
        grounding_text=huge,
        memory_text=huge,
        conversation_context=huge,
        chat_history=[
            {"role": "assistant", "content": huge},
            {"role": "user", "content": huge},
        ],
        user_message="Giải thích cơ chế này. " + ("chi tiết " * 1000),
        budget=ChatPromptBudget(),
    )

    assert report["system_rules"] <= 1800
    assert report["user_history"] <= 500
    assert report["grounding"] <= 500
    assert report["memory"] <= 400
    assert report["state_style"] <= 300
    assert report["output_reserve"] == 512
    assert estimate_tokens(messages) <= 4288


class _DummyGroqClient:
    base_url = "https://api.groq.com/openai/v1"
    model_name = "qwen/qwen3-32b"

    def __init__(self) -> None:
        self.calls: list[dict] = []

    def create_chat_completion(self, **kwargs):
        self.calls.append(kwargs)
        payload = {
            "text": "Đã hiểu.",
            "intent": "reply",
            "action": "",
            "animation": "stand",
            "reasoning_tags": [],
            "should_speak": True,
            "confidence": 0.9,
            "direction": 0,
            "target_x": -1.0,
            "bounce_action": "",
            "extracted_fact": "",
            "debug_trace": "budget test",
            "next_animation": "",
            "system_action": "",
            "action_input": "",
            "delivery_hint": "",
            "nonverbal_cue": "",
            "stage_motion": "",
        }
        return {"choices": [{"message": {"content": json.dumps(payload, ensure_ascii=False)}}]}


def test_generate_chat_reply_uses_one_budgeted_main_call(monkeypatch) -> None:
    monkeypatch.delenv("ERIS_CHAT_HARD_BUDGET_USE_DDS", raising=False)
    client = _DummyGroqClient()
    service = LlmService(client, logger=logging.getLogger("test.prompt_budget"))
    huge = "khối dữ liệu " * 4000

    service.generate_chat_reply(
        chat_history=[
            {"role": "assistant", "content": huge},
            {"role": "user", "content": huge},
        ],
        user_message="Giải thích cơ chế này " + ("chi tiết " * 800),
        raw_user_text="Giải thích cơ chế này",
        ti_context=huge,
        ni_context=huge,
        fe_context=huge,
        appraisal_context=huge,
        internal_state_context=huge,
        conversation_context=huge,
        memory_context=huge,
        grounding_context=huge,
    )

    assert len(client.calls) == 1
    assert client.calls[0]["max_tokens"] == 512
    assert estimate_tokens(client.calls[0]["messages"]) <= 4288
