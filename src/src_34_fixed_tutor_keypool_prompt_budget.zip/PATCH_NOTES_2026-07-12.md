# Eris patch: Tutor gate, key-pool lease, chat prompt hard budget

## Đã sửa

1. Tutor user-facing chỉ chạy khi `last_user_intent == "world_knowledge"`.
   - Bộ phân loại intent nằm tại `cortex/fe.py`.
   - Loại trừ câu hỏi self-identity như `bạn là ai`, `bạn là cái gì`, `bạn có cảm xúc không`.
   - `runtime/coordinator.py` không còn tự quét chuỗi `"là gì"` để bật Tutor.

2. Key pool dùng `ApiKeyLease(index, key)`.
   - Request báo lỗi theo đúng lease đã dùng, không đánh dấu nhầm con trỏ toàn cục.
   - Khi toàn bộ key đang cooldown, request dừng và báo thời gian chờ thay vì tiếp tục đập vào key sắp hồi.
   - Đã nối lease vào OpenAI-compatible, Gemini chat và Gemini TTS.
   - Key cuối cùng thất bại cũng được cooldown.

3. Chat prompt có hard budget trước khi ghép:
   - Total: 4800
   - Output reserve: 512
   - System rules: 1800
   - User/history: 500
   - Grounding: 500
   - Memory: 400
   - State/style: 300
   - Headroom còn lại: 788

4. DDS chat mặc định tắt vì hard-budget deterministic đã xử lý trước synthesis.
   - Bật lại bằng `ERIS_CHAT_HARD_BUDGET_USE_DDS=1` khi cần semantic distillation.

## Kiểm tra

- `python -m compileall -q .`: PASS
- `PYTHONPATH=. pytest -q tests/test_tutor_key_pool_prompt_budget.py`: 6 PASS
- Integration prompt cực lớn: chỉ 1 model call chính, input dưới 4288 token, output reserve 512.
