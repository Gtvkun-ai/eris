﻿import json
import re
import unicodedata

from actions.contracts import VALID_SYSTEM_ACTIONS
from guard_config import OFF_GUARD_MODE, STRICT_GUARD_MODE, get_guard_mode
from llm.contracts import VALID_ANIMATIONS
# ParserGroundingMixin là một lớp mixin cung cấp các phương thức để xử lý và
#  "ground" (định hình) các quyết định được tạo ra bởi một mô hình ngôn ngữ lớn (LLM)
#  thành các hành động có thể thực thi trong runtime của ứng dụng.
# Lớp này bao gồm các phương thức để trích xuất thông tin từ văn bản,
#  kiểm tra xem các mệnh đề có vượt quá khả năng runtime hay không,
#  và xây dựng các phản hồi được điều chỉnh để phù hợp với khả năng của hệ thống.


CAPABILITY_PROFILE = {
    "observe": [
        "telemetry cục bộ trên máy Windows",
        "tiêu đề cửa sổ, tab và URL nếu UI Automation đọc được",
        "mức CPU, RAM, thời gian, ngữ cảnh focus",
    ],
    "respond": [
        "trả lời bằng văn bản",
        "đề xuất bước tiếp theo",
        "thừa nhận khi không chắc",
    ],
    "embody": [
        "đổi animation, hướng di chuyển và vị trí nhân vật trong Godot",
    ],
    "memory": [
        "lưu working/episodic/semantic/norm memory trong long_term_memory.json",
    ],
}

UNSUPPORTED_ACTION_VERBS = [
    "khóa", "ngắt", "đóng", "mở", "tắt", "bật", "tăng", "giảm",
    "gọi", "đặt", "hủy", "xóa", "ép", "cưỡng chế", "ghi đè",
    "can thiệp", "điều khiển", "chiếm hữu", "chặn", "phát", "kích hoạt",
    "thiết lập", "reset", "shutdown", "hibernate", "suspend",
    "thu gọn", "dọn", "gom", "thu hồi", "vô hiệu hóa", "disable",
]

UNSUPPORTED_ACTION_TARGETS = [
    "bàn phím", "chuột", "màn hình", "tab", "trình duyệt", "cửa sổ",
    "mạng", "wifi", "internet", "hệ điều hành", "windows", "thiết bị",
    "đèn", "nhiệt độ phòng", "phòng", "nhà thông minh", "robot",
    "thuốc", "đơn hàng", "ví điện tử", "âm thanh tần số", "loa",
    "phần cứng sinh học", "thiết bị vật lý",
    "ứng dụng", "app", "mạng xã hội",
]

ALLOWED_SELF_CLAIMS = [
    "tôi có thể quan sát",
    "tôi chỉ có thể quan sát",
    "tôi chỉ có thể nhắc",
    "tôi chỉ có thể đề nghị",
    "tôi không chắc",
    "tôi không đủ dữ kiện",
    "tôi không có cơ chế",
    "tôi có thể đổi animation",
    "tôi có thể trả lời",
    "tôi đã ghi nhớ",
    "tôi đã lưu",
]


class ParserGroundingMixin:
    def _normalize_keyword_text(self, text: str) -> str:
        lowered = unicodedata.normalize("NFD", (text or "").lower())
        lowered = "".join(ch for ch in lowered if unicodedata.category(ch) != "Mn")
        lowered = re.sub(r"[^a-z0-9#]+", " ", lowered)
        return " ".join(lowered.split())

    def _contains_keyword(self, text: str, keyword: str) -> bool:
        normalized_text = self._normalize_keyword_text(text)
        normalized_keyword = self._normalize_keyword_text(keyword)
        if not normalized_text or not normalized_keyword:
            return False
        return f" {normalized_keyword} " in f" {normalized_text} "

    def _contains_any_keyword(self, text: str, keywords) -> bool:
        return any(self._contains_keyword(text, keyword) for keyword in keywords)

    def _is_embodied_command_request(self, text: str) -> bool:
        normalized = self._normalize_keyword_text(text)
        if not normalized:
            return False

        command_phrases = [
            "đi dạo",
            "tản bộ",
            "di chuyển",
            "đi qua",
            "đi sang phải",
            "đi sang trái",
            "sang phải",
            "sang trái",
            "qua phải",
            "qua trái",
            "move",
            "walk",
            "run",
            "nhìn sang phải",
            "nhìn sang trái",
            "quay mặt",
            "quay sang",
            "hướng sang",
            "ra giữa",
            "về giữa",
            "center",
            "middle",
            "đọc",
            "theo dõi",
            "giám sát",
            "monitor",
            "xem tài liệu",
            "nghiên cứu",
            "sit down",
            "ngồi xuống",
            "sit",
            "ngủ đi",
            "nghỉ ngủ",
            "sleep",
            "ăn uống",
            "food",
            "ôm",
            "vuốt ve",
            "ân cần",
            "chơi đàn",
            "đánh đàn",
            "piano",
            "leo",
            "climb",
            "trèo",
            "divine",
            "phân tách",
        ]
        return self._contains_any_keyword(normalized, command_phrases)

    def _should_infer_embodied_animation(self, text: str, user_hint: str = "") -> bool:
        if (user_hint or "").strip():
            return self._is_embodied_command_request(user_hint)
        return True

    def _preview_raw_response(self, raw_text: str):
        preview = (raw_text or "").replace("\n", "\\n").strip()
        if len(preview) > 240:
            preview = preview[:240] + "...(truncated)"
        return preview

    def _normalize_debug_trace(self, value: str):
        text = self._normalize_salvaged_text(str(value or ""))
        return text[:240]

    def _build_parser_debug_trace(self, *, parse_mode: str, raw_text: str, reason: str, text: str = "", animation: str = ""):
        parts = [f"parse_mode={parse_mode}", reason]
        if animation:
            parts.append(f"animation={animation}")
        if text:
            parts.append(f"text={text[:80]}")
        parts.append(f"raw={self._preview_raw_response(raw_text)}")
        return " | ".join(part for part in parts if part)

    def _collect_capability_violations(self, text: str):
        violations = []
        previous_unit = ""
        for unit in self._split_into_claim_units(text):
            if self._clause_exceeds_runtime_capability(unit, previous_unit=previous_unit, context=text):
                violations.append(unit)
            previous_unit = unit
        return violations

    def _infer_animation_reason(self, final_animation: str, text: str, user_hint: str = ""):
        combined = f"{user_hint}\n{text}"
        keyword_groups = [
            ("stand_walk", ["đi dạo", "tản bộ", "di chuyển", "walk", "đi ", "di ", "move "]),
            ("sleep", ["ngủ", "ngủ đông", "sleep"]),
            ("read", ["đọc", "theo dõi", "giám sát", "monitor", "ide", "code", "dự án"]),
            ("sad", ["buồn", "thất vọng", "chán"]),
            ("sit", ["ngồi", "nghỉ"]),
            ("affection", ["vui", "hài lòng", "thích", "ôm", "ân cần"]),
            ("food", ["ăn", "uống", "đồ ăn", "food"]),
            ("piano", ["piano", "chơi đàn", "đánh đàn"]),
            ("climb", ["leo", "trèo", "climb"]),
            ("divine", ["divine", "phân tách"]),
        ]
        for animation_name, keywords in keyword_groups:
            if final_animation != animation_name:
                continue
            for keyword in keywords:
                if self._contains_keyword(combined, keyword):
                    return f"animation={final_animation} vì phát hiện từ khóa '{keyword}'"
        return f"animation={final_animation} vì fallback mặc định hoặc không có từ khóa rõ ràng"

    def _build_parser_trace_summary(
        self,
        *,
        parse_mode: str,
        original_text: str,
        final_text: str,
        final_animation: str,
        user_hint: str = "",
        grounded_changed: bool = False,
    ):
        parts = [f"parse_mode={parse_mode}"]

        violations = self._collect_capability_violations(original_text)
        if violations:
            preview = "; ".join(violations[:2])
            parts.append(f"capability_violation={preview[:140]}")
        else:
            parts.append("capability_violation=không phát hiện")

        # Giữ parser_trace gọn: chỉ log capability + grounding, không spam lý do animation.
        if grounded_changed:
            parts.append("grounding=đã viết lại nội dung vượt capability")
        else:
            parts.append("grounding=không cần viết lại")

        return " | ".join(parts)

    def _log(self, level: str, message: str):
        logger = getattr(self, "logger", None)
        if logger is not None:
            getattr(logger, level)(message)
        else:
            safe_message = message.encode("ascii", "backslashreplace").decode("ascii")
            print(safe_message, flush=True)

    def _extract_first_json_object(self, text: str):
        start = text.find("{")
        if start == -1:
            return None

        depth = 0
        in_string = False
        escaped = False

        for idx in range(start, len(text)):
            ch = text[idx]
            if in_string:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_string = False
                continue

            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start:idx + 1]

        return None

    def _extract_first_json_candidate(self, text: str) -> str:
        start = text.find("{")
        if start == -1:
            return ""
        return text[start:].strip()

    def _repair_json_candidate(self, text: str) -> str:
        candidate = str(text or "").strip()
        if not candidate:
            return ""
        candidate = (
            candidate.replace("\u201c", '"')
            .replace("\u201d", '"')
            .replace("\u2018", "'")
            .replace("\u2019", "'")
        )
        candidate = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", " ", candidate)
        candidate = re.sub(r",(\s*[}\]])", r"\1", candidate)

        depth = 0
        in_string = False
        escaped = False
        for ch in candidate:
            if in_string:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_string = False
                continue
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth = max(0, depth - 1)
        if depth > 0:
            candidate += "}" * depth
        candidate = re.sub(r",(\s*[}\]])", r"\1", candidate)
        return candidate.strip()

    def _patch_missing_decision_fields(self, payload: dict, *, parse_mode: str, user_hint: str = "") -> tuple[dict, bool]:
        patched = self._apply_cognition_action_defaults(dict(payload or {}), user_hint=user_hint)
        fields_patched = False

        text = self._normalize_salvaged_text(str(patched.get("text", "") or ""))
        if not text:
            text = self._normalize_salvaged_text(str(patched.get("extracted_fact", "") or ""))
        if not text and self._coerce_bool(patched.get("should_speak", True), fallback=True):
            text = self.fallback["text"]
            fields_patched = True
        patched["text"] = text

        structured = self._infer_structured_action(text or user_hint, user_hint=user_hint)
        default_fields = {
            "intent": "",
            "action": "",
            "reasoning_tags": (),
            "should_speak": bool(text),
            "confidence": 0.0,
            "animation": structured["animation"] or self.fallback["animation"],
            "extracted_fact": patched.get("extracted_fact", ""),
            "direction": structured["direction"],
            "next_animation": structured["next_animation"],
            "target_x": structured["target_x"],
            "bounce_action": structured["bounce_action"],
            "debug_trace": "",
            "system_action": "",
            "action_input": "",
            "motion_intent": "",
            "motion_target_x": structured["target_x"],
            "motion_facing": structured["direction"],
            "parse_mode": parse_mode,
        }
        for key, default in default_fields.items():
            value = patched.get(key, None)
            if value in (None, "") and key not in {"direction", "target_x", "motion_target_x", "motion_facing", "should_speak", "confidence"}:
                patched[key] = default
                fields_patched = True
                continue
            if key in {"direction", "target_x", "motion_target_x", "motion_facing"} and key not in patched:
                patched[key] = default
                fields_patched = True
                continue
            if key in {"should_speak", "confidence"} and key not in patched:
                patched[key] = default
                fields_patched = True
        return patched, fields_patched

    def _finalize_loaded_json_payload(self, payload, *, parse_mode: str, user_hint: str = ""):
        data = self._normalize_decision_field_keys(payload)
        if "response" in data and isinstance(data["response"], list) and len(data["response"]) > 0:
            data = self._normalize_decision_field_keys(data["response"][0])
        data, fields_patched = self._patch_missing_decision_fields(
            data,
            parse_mode=parse_mode,
            user_hint=user_hint,
        )

        text = str(data.get("text", self.fallback["text"]))
        animation = self._sanitize_animation(
            data.get("animation", self.fallback["animation"]),
            fallback_text=text,
            user_hint=user_hint,
        )
        fact = str(data.get("extracted_fact", "")).strip()
        direction = self._sanitize_direction(data.get("direction", 0))
        next_anim = str(data.get("next_animation", "")).strip()
        bounce_action = str(data.get("bounce_action", "")).strip()
        target_x = self._sanitize_target_x(data.get("target_x", -1.0))

        final_parse_mode = "hard_json_repair" if fields_patched and parse_mode == "json" else parse_mode
        return self._finalize_decision({
            "text": text,
            "intent": data.get("intent", ""),
            "action": data.get("action", ""),
            "reasoning_tags": data.get("reasoning_tags", ()),
            "should_speak": data.get("should_speak", bool(text)),
            "confidence": data.get("confidence", 0.0),
            "animation": animation,
            "extracted_fact": fact,
            "direction": direction,
            "next_animation": next_anim,
            "target_x": target_x,
            "bounce_action": bounce_action,
            "debug_trace": data.get("debug_trace", data.get("_thought", "")),
            "parse_mode": final_parse_mode,
            "system_action": data.get("system_action", ""),
            "action_input": data.get("action_input", ""),
            "motion_intent": data.get("motion_intent", ""),
            "motion_target_x": data.get("motion_target_x", target_x),
            "motion_facing": data.get("motion_facing", direction),
        }, user_hint=user_hint)

    def _try_parse_hard_json_repair(self, text: str, user_hint: str = ""):
        candidate = self._extract_first_json_candidate(text)
        if not candidate or ":" not in candidate:
            return None

        attempts: list[str] = []
        exact_object = self._extract_first_json_object(candidate)
        if exact_object:
            attempts.append(exact_object)
        attempts.append(self._repair_json_candidate(candidate))

        seen: set[str] = set()
        for attempt in attempts:
            attempt = str(attempt or "").strip()
            if not attempt or attempt in seen:
                continue
            seen.add(attempt)
            try:
                data = json.loads(attempt)
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            return self._finalize_loaded_json_payload(
                data,
                parse_mode="hard_json_repair",
                user_hint=user_hint,
            )
        return None

    def _normalize_salvaged_text(self, text: str):
        # Nếu model trả về block kiểu "text: ... animation: ...",
        # thì chỉ giữ phần từ sau "text:" tới trước field tiếp theo để tránh spam meta-field.
        m = re.search(r"\btext\s*[:=]\s*", text, flags=re.IGNORECASE)
        if m:
            after = text[m.end():]
            field_pattern = r"\b(animation|direction|target_x|bounce_action|extracted_fact|debug_trace|next_animation|system_action|action_input|motion_intent|motion_target_x|motion_facing)\s*[:=]"
            m2 = re.search(field_pattern, after, flags=re.IGNORECASE)
            if m2:
                text = after[: m2.start()]
            else:
                text = after

        text = re.sub(r"\|\s*animation\s*=.*$", "", text, flags=re.IGNORECASE)
        text = re.sub(r"<[^>]+>", " ", text)
        text = text.replace("\\n", " ").replace("\n", " ")
        text = re.sub(r"\s+", " ", text).strip()
        if len(text) >= 2 and text[0] == text[-1] and text[0] in {'"', "'"}:
            text = text[1:-1].strip()
        text = re.sub(r"^(trả lời trước|tra loi truoc)\s*:\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"^(eris|assistant|ai|response)\s*:\s*", "", text, flags=re.IGNORECASE)
        text = self._cut_inline_metadata_from_public_text(text)
        text = self._repair_sentence_boundaries(text)
        return text

    def _repair_sentence_boundaries(self, text: str) -> str:
        repaired = (text or "").strip()
        if not repaired:
            return repaired
        repaired = re.sub(
            r"(?<=[a-zàáảãạăắằẳẵặâấầẩẫậđèéẻẽẹêếềểễệìíỉĩịòóỏõọôốồổỗộơớờởỡợùúủũụưứừửữựỳýỷỹỵ0-9])\s+(?=(Tôi|Hãy|Đừng|Nếu|Nhưng|Mọi|Đó|Sự|Trạng thái)\b)",
            ". ",
            repaired,
        )
        repaired = re.sub(r"\.\s+\.", ".", repaired)
        return repaired.strip()

    def _normalize_decision_field_keys(self, value):
        if isinstance(value, list):
            return [self._normalize_decision_field_keys(item) for item in value]
        if not isinstance(value, dict):
            return value

        normalized = {}
        for key, item in value.items():
            normalized_key = key.strip() if isinstance(key, str) else key
            normalized_item = self._normalize_decision_field_keys(item)
            if normalized_key in normalized and normalized_key != key:
                continue
            normalized[normalized_key] = normalized_item
        return normalized

    def _coerce_bool(self, value, *, fallback: bool = True) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return value != 0
        text = str(value or "").strip().lower()
        if text in {"true", "yes", "y", "1", "speak", "noi", "nói"}:
            return True
        if text in {"false", "no", "n", "0", "silent", "silence", "im", "im_lang", "im lặng"}:
            return False
        return fallback

    def _coerce_confidence(self, value, *, fallback: float = 0.0) -> float:
        if isinstance(value, bool):
            return fallback
        try:
            confidence = float(value)
        except (TypeError, ValueError):
            return fallback
        return max(0.0, min(1.0, confidence))

    def _coerce_reasoning_tags(self, value) -> tuple[str, ...]:
        if isinstance(value, str):
            raw_items = re.split(r"[,|;/]+", value)
        elif isinstance(value, list):
            raw_items = value
        else:
            raw_items = []

        tags: list[str] = []
        seen: set[str] = set()
        for item in raw_items:
            tag = str(item or "").strip().lower()
            tag = unicodedata.normalize("NFD", tag)
            tag = "".join(ch for ch in tag if unicodedata.category(ch) != "Mn")
            tag = re.sub(r"[^a-z0-9_\-\s]+", "", tag)
            tag = re.sub(r"\s+", "_", tag).strip("_")
            if not tag or tag in seen:
                continue
            tags.append(tag[:40])
            seen.add(tag)
            if len(tags) >= 8:
                break
        return tuple(tags)

    def _action_field(self, action, *names, default=None):
        if not isinstance(action, dict):
            return default
        for name in names:
            if name in action:
                return action.get(name)
        return default

    def _apply_cognition_action_defaults(self, data: dict, user_hint: str = "") -> dict:
        action = data.get("action")
        if not isinstance(action, dict):
            if isinstance(action, str) and action.strip() and "system_action" not in data:
                data["system_action"] = action.strip()
            return data

        merged = dict(data)
        text = str(merged.get("text", "") or "")
        structured = self._infer_structured_action(
            " ".join(str(action.get(key, "")) for key in ("type", "name", "intent", "description", "motion_intent")),
            user_hint=f"{user_hint}\n{text}",
        )

        if "animation" not in merged or not str(merged.get("animation", "")).strip():
            merged["animation"] = self._action_field(action, "animation", "pose", default=structured["animation"] or "stand")
        if "direction" not in merged:
            merged["direction"] = self._action_field(action, "direction", "facing", default=structured["direction"])
        if "target_x" not in merged:
            merged["target_x"] = self._action_field(action, "target_x", "x", default=structured["target_x"])
        if "next_animation" not in merged:
            merged["next_animation"] = self._action_field(action, "next_animation", default=structured["next_animation"])
        if "bounce_action" not in merged:
            merged["bounce_action"] = self._action_field(action, "bounce_action", default=structured["bounce_action"])
        if "motion_intent" not in merged:
            merged["motion_intent"] = self._action_field(action, "motion_intent", "type", "name", default="")
        if "motion_target_x" not in merged:
            merged["motion_target_x"] = self._action_field(action, "motion_target_x", "target_x", "x", default=merged.get("target_x", -1.0))
        if "motion_facing" not in merged:
            merged["motion_facing"] = self._action_field(action, "motion_facing", "direction", "facing", default=merged.get("direction", 0))

        system_action = self._action_field(action, "system_action", "systemAction", "tool", "name", default="")
        if system_action and not str(merged.get("system_action", "")).strip():
            merged["system_action"] = system_action
        action_input = self._action_field(action, "action_input", "input", "query", "url", "argument", default="")
        if action_input and not str(merged.get("action_input", "")).strip():
            merged["action_input"] = action_input
        return merged

    def _clean_inline_field_value(self, value: str) -> str:
        cleaned = str(value or "")
        for _ in range(4):
            before = cleaned
            cleaned = cleaned.strip()
            cleaned = cleaned.rstrip(",;").strip()
            if cleaned.endswith("}") and cleaned.count("{") < cleaned.count("}"):
                cleaned = cleaned[:-1].strip()
            if len(cleaned) >= 2 and cleaned[0] == cleaned[-1] and cleaned[0] in {'"', "'"}:
                cleaned = cleaned[1:-1].strip()
            if cleaned.endswith('"') and cleaned.count('"') % 2 == 1:
                cleaned = cleaned[:-1].rstrip(" ,;")
            if cleaned.endswith("'") and cleaned.count("'") % 2 == 1:
                cleaned = cleaned[:-1].rstrip(" ,;")
            if cleaned == before:
                break
        cleaned = cleaned.strip()
        if cleaned.lower() in {"null", "none", "nil"} or cleaned in {"[]", "{}"}:
            return ""
        return cleaned

    def _cut_inline_metadata_from_public_text(self, text: str) -> str:
        """Remove leaked decision-schema tail from a public text field."""
        cleaned = str(text or "")
        if not cleaned:
            return ""
        # Common failure: text='...', 'intent': 'x', 'action': ... after
        # LlmService wrapped a truncated JSON blob into a JSON text field.
        metadata_pattern = re.compile(
            r"(?P<head>.*?)(?:[\"']?\s*,\s*)[\"'](?:intent|action|reasoning_tags|should_speak|confidence|animation|debug_trace|system_action)[\"']\s*:",
            flags=re.IGNORECASE | re.DOTALL,
        )
        match = metadata_pattern.match(cleaned)
        if match:
            cleaned = match.group("head")
        # Also catch prose-shaped payload leaks: ` intent: ... action: ...`
        cleaned = re.split(
            r"\s+(?:intent|action|reasoning_tags|should_speak|confidence|debug_trace|system_action)\s*[:=]",
            cleaned,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]
        return self._clean_inline_field_value(cleaned)

    def _looks_like_prompt_or_contract_leak_text(self, text: str) -> bool:
        raw = str(text or "")
        lowered = raw.lower()
        markers = (
            "speech intent:",
            "speech evidence",
            "persona:",
            "constraints:",
            "return only",
            "valid json object",
            "ghi chú nền",
            "gợi ý điều phối",
            "critical output contract",
            "runtime requirement for this call",
            "llm final prompt",
        )
        hits = sum(1 for marker in markers if marker in lowered)
        return hits >= 2 or (hits >= 1 and raw.count("*   ") >= 1)

    def _looks_like_non_json_analysis_or_debug_text(self, text: str) -> bool:
        raw = str(text or "").strip()
        if not raw:
            return False
        lowered = raw.lower()
        normalized = self._normalize_keyword_text(raw)
        markers = (
            "user input:",
            "context:",
            "goal:",
            "eris's current state",
            "speech intent:",
            "speech evidence",
            "constraints:",
            "return only",
            "valid json object",
            "critical output contract",
            "runtime requirement for this call",
            "llm final prompt",
            "reasoning_tags",
            "should_speak",
            "debug_trace",
            "parse_mode",
            "system_action",
            "action_input",
            "correction_triggers_repair",
            "relational_repair_rule",
        )
        hits = sum(1 for marker in markers if marker in lowered or self._normalize_keyword_text(marker) in normalized)
        instruction_shape = sum(
            1
            for marker in (
                "you are eris",
                "do not",
                "must not",
                "only use",
                "data bans",
                "hard bans",
                "internal state",
            )
            if marker in lowered or self._normalize_keyword_text(marker) in normalized
        )
        return hits >= 2 or (hits >= 1 and instruction_shape >= 1)

    def _non_json_semantic_fallback_payload(self, *, parse_mode: str, raw_text: str, reason: str) -> dict:
        return {
            **self.fallback,
            "text": "Cau vua roi bi loi format noi bo. Toi bo phan phan tich ky thuat va giu lai cau tra loi an toan.",
            "debug_trace": self._build_parser_debug_trace(
                parse_mode=parse_mode,
                raw_text=raw_text,
                reason=reason,
                text="non_json_semantic_fallback",
                animation=self.fallback["animation"],
            ),
            "parse_mode": parse_mode,
            "intent": "protocol_repair",
            "system_action": "",
            "action_input": "",
        }

    # _try_extract_nested_decision_from_text là một phương thức để cố gắng trích xuất một đối tượng JSON
    # lồng nhau từ trường text của quyết định.
    def _try_extract_inline_decision_fields_from_text(self, text: str):
        candidate = (text or "").strip()
        if not candidate:
            return None

        fields = [
            "text",
            "intent",
            "action",
            "reasoning_tags",
            "should_speak",
            "confidence",
            "animation",
            "direction",
            "target_x",
            "bounce_action",
            "extracted_fact",
            "debug_trace",
            "next_animation",
            "system_action",
            "action_input",
            "motion_intent",
            "motion_target_x",
            "motion_facing",
        ]
        field_group = "|".join(re.escape(field) for field in fields)
        pattern = re.compile(
            rf"(?:(?<=^)|(?<=[\s,;{{]))[\"']?\s*(?P<field>{field_group})\s*[\"']?\s*[:=]\s*",
            flags=re.IGNORECASE,
        )
        matches = list(pattern.finditer(candidate))
        if len(matches) < 2:
            return None

        extracted = {}
        for index, match in enumerate(matches):
            field = match.group("field").lower()
            start = match.end()
            end = matches[index + 1].start() if index + 1 < len(matches) else len(candidate)
            raw_value = self._clean_inline_field_value(candidate[start:end])
            extracted[field] = raw_value

        if "text" not in extracted:
            return None
        return extracted

    def _sanitize_direction(self, value) -> int:
        try:
            direction = int(value)
        except (TypeError, ValueError):
            return 0
        return direction if direction in {-1, 0, 1} else 0

    def _sanitize_target_x(self, value, *, fallback: float = -1.0) -> float:
        try:
            target_x = float(value)
        except (TypeError, ValueError):
            return fallback

        if target_x == -1.0:
            return -1.0
        if 0.0 <= target_x <= 1.0:
            return target_x
        return fallback

    def _sanitize_motion_facing(self, value, *, fallback: int = 0) -> int:
        try:
            facing = int(value)
        except (TypeError, ValueError):
            return fallback
        return facing if facing in {-1, 0, 1} else fallback

    def _try_extract_nested_decision_from_text(self, text: str):
        candidate = self._unwrap_structured_text_candidate(text)
        if not candidate.startswith("{") or '"text"' not in candidate:
            return None

        try:
            nested = json.loads(candidate)
        except Exception:
            nested = None

        if not isinstance(nested, dict):
            inline_fields = self._try_extract_inline_decision_fields_from_text(candidate)
            if inline_fields is None:
                return None
            nested = inline_fields
        else:
            nested = self._normalize_decision_field_keys(nested)

        return {
            "text": self._clean_nested_field_text(nested.get("text", "")),
            "animation": self._clean_nested_field_scalar(nested.get("animation", "")),
            "extracted_fact": self._clean_nested_field_text(nested.get("extracted_fact", "")),
            "debug_trace": self._clean_nested_field_text(nested.get("debug_trace", nested.get("_thought", ""))),
            "direction": nested.get("direction", 0),
            "next_animation": self._clean_nested_field_scalar(nested.get("next_animation", "")),
            "target_x": nested.get("target_x", -1.0),
            "bounce_action": self._clean_nested_field_scalar(nested.get("bounce_action", "")),
            "system_action": self._clean_nested_field_scalar(nested.get("system_action", "")),
            "action_input": self._clean_nested_field_text(nested.get("action_input", "")),
            "motion_intent": self._clean_nested_field_scalar(nested.get("motion_intent", "")),
            "motion_target_x": nested.get("motion_target_x", -1.0),
            "motion_facing": nested.get("motion_facing", 0),
        }

    def _unwrap_structured_text_candidate(self, text: str) -> str:
        candidate = (text or "").strip()
        if not candidate:
            return ""

        seen: set[str] = set()
        for _ in range(4):
            if not candidate or candidate in seen:
                break
            seen.add(candidate)

            if len(candidate) >= 2 and candidate[0] == candidate[-1] and candidate[0] in {'"', "'"}:
                candidate = candidate[1:-1].strip()
                continue

            try:
                decoded = json.loads(candidate)
            except Exception:
                decoded = None

            if isinstance(decoded, dict):
                return json.dumps(decoded, ensure_ascii=False)

            if isinstance(decoded, str):
                candidate = decoded.strip()
                continue

            if candidate.startswith("{") and '\\"' in candidate:
                candidate = candidate.replace('\\"', '"')
                continue

            break

        return candidate

    def _clean_nested_field_scalar(self, value) -> str:
        text = str(value or "").strip()
        lowered = text.lower()
        if lowered in {"null", "none", "nil"}:
            return ""
        if text in {"[]", "{}"}:
            return ""
        text = text.rstrip("}").strip()
        if len(text) >= 2 and text[0] == text[-1] and text[0] in {'"', "'"}:
            text = text[1:-1].strip()
        if text.endswith('"') and text.count('"') % 2 == 1:
            text = text[:-1].rstrip()
        if text.endswith("'") and text.count("'") % 2 == 1:
            text = text[:-1].rstrip()
        return text

    def _clean_nested_field_text(self, value) -> str:
        return self._normalize_salvaged_text(self._clean_nested_field_scalar(value))

    def _sanitize_motion_intent(self, value: str) -> str:
        intent = str(value or "").strip().strip('"').strip("'").lower()
        valid = {
            "",
            "pose",
            "face",
            "walk",
            "walk_to",
            "climb_loop",
            "climb_to_top",
            "drop",
        }
        if intent in valid:
            return intent
        return ""

    def _infer_motion_intent(
        self,
        *,
        animation: str,
        next_animation: str,
        direction: int,
        target_x: float,
    ) -> str:
        if animation == "climb" and next_animation == "climb_top":
            return "climb_to_top"
        if animation == "climb_top":
            return "climb_to_top"
        if animation == "climb":
            return "climb_loop"
        if animation in {"air_swing_l", "air_swing_r"}:
            return "drop"
        if target_x >= 0.0:
            return "walk_to"
        if animation == "stand_walk":
            return "walk"
        if direction in {-1, 1}:
            return "face"
        return ""

    def _sanitize_animation(self, value: str, fallback_text: str = "", user_hint: str = ""):
        animation = str(value or "").strip().strip('"').strip("'").lower()
        if animation in {"", "null", "none", "nil"}:
            animation = ""
        if animation in VALID_ANIMATIONS:
            return animation
        inferred = ""
        if fallback_text and self._should_infer_embodied_animation(fallback_text, user_hint=user_hint):
            source_text = user_hint or fallback_text
            inferred = self._infer_animation_from_text(source_text)
        if inferred in VALID_ANIMATIONS:
            return inferred
        return self.fallback["animation"]

    def _sanitize_system_action(self, value: str):
        action_name = str(value or "").strip().strip('"').strip("'")
        if action_name in VALID_SYSTEM_ACTIONS:
            return action_name
        return ""

    def _is_strict_direction_value(self, value) -> bool:
        if isinstance(value, bool):
            return False
        if isinstance(value, int):
            return value in {-1, 0, 1}
        if isinstance(value, float):
            return value.is_integer() and int(value) in {-1, 0, 1}
        if isinstance(value, str):
            stripped = value.strip()
            return stripped in {"-1", "0", "1"}
        return False

    def _is_strict_target_x_value(self, value) -> bool:
        if isinstance(value, bool):
            return False
        try:
            target_x = float(value)
        except (TypeError, ValueError):
            return False
        return target_x == -1.0 or 0.0 <= target_x <= 1.0

    def _requires_lax_json_mode(self, payload: dict) -> bool:
        animation = str(payload.get("animation", "") or "").strip().strip('"').strip("'").lower()
        if animation and animation not in VALID_ANIMATIONS:
            return True

        next_animation = str(payload.get("next_animation", "") or "").strip().strip('"').strip("'").lower()
        if next_animation and next_animation not in VALID_ANIMATIONS:
            return True

        bounce_action = str(payload.get("bounce_action", "") or "").strip().strip('"').strip("'").lower()
        if bounce_action and bounce_action not in VALID_ANIMATIONS:
            return True

        if not self._is_strict_direction_value(payload.get("direction", 0)):
            return True

        if not self._is_strict_target_x_value(payload.get("target_x", -1.0)):
            return True

        system_action = str(payload.get("system_action", "") or "").strip().strip('"').strip("'")
        if system_action and system_action not in VALID_SYSTEM_ACTIONS:
            return True

        return False
    def _get_runtime_capability_summary(self):
        parts = []
        for group_name in ("observe", "respond", "embody", "memory"):
            parts.extend(CAPABILITY_PROFILE.get(group_name, []))
        return "; ".join(parts)

    def _split_into_claim_units(self, text: str):
        chunks = re.split(r"(?<=[\.?\!])\s+|\s*;\s*|\s+(?:nhưng|và rồi|đồng thời)\s+", text.strip())
        return [chunk.strip(" ,") for chunk in chunks if chunk and chunk.strip(" ,")]

    def _is_allowed_self_claim(self, clause: str):
        lowered = clause.lower()
        return any(token in lowered for token in ALLOWED_SELF_CLAIMS)

    def _has_vision_frame_context(self, text: str) -> bool:
        lowered = (text or "").lower()
        return "vision_frame_attached" in lowered or "vision_facts_attached" in lowered

    def _is_screen_observation_claim(self, clause: str, context: str = "") -> bool:
        lowered = (clause or "").lower()

        observation_markers = (
            "tôi thấy",
            "tôi nhìn thấy",
            "tôi chỉ thấy",
            "tôi ghi nhận",
            "tôi chỉ ghi nhận",
            "tôi nhận thấy",
            "toi thay",
            "toi nhin thay",
            "toi chi thay",
            "toi ghi nhan",
            "toi chi ghi nhan",
            "toi nhan thay",
        )
        visual_targets = (
            "ảnh",
            "anh",
            "screenshot",
            "màn hình",
            "man hinh",
            "tab",
            "trình duyệt",
            "trinh duyet",
            "web",
            "website",
            "messenger",
            "facebook",
            "brave",
            "chrome",
            "cửa sổ",
            "cua so",
        )
        has_observation_marker = any(marker in lowered for marker in observation_markers)
        has_visual_target = any(
            target in lowered for target in visual_targets
        )
        if not has_observation_marker or not has_visual_target:
            return False

        if self._has_vision_frame_context(context):
            return True

        action_claim_patterns = (
            r"\btôi\s+(?:đã|sẽ|đang)\s+(?:khóa|ngắt|đóng|mở|tắt|bật|hủy|xóa|ép|can thiệp|điều khiển|thu gọn|dọn|gom|vô hiệu hóa)\b",
            r"\btoi\s+(?:da|se|dang)\s+(?:khoa|ngat|dong|mo|tat|bat|huy|xoa|ep|can thiep|dieu khien|thu gon|don|gom|vo hieu hoa)\b",
        )
        return not any(re.search(pattern, lowered) for pattern in action_claim_patterns)

    # _clause_exceeds_runtime_capability là một phương thức để kiểm tra xem một mệnh đề có vượt quá
    # khả năng runtime của hệ thống hay không.
    # Nó kiểm tra xem mệnh đề có chứa các động từ hành động không được hỗ trợ và các mục tiêu hành động
    # không được hỗ trợ, đồng thời không phải là một tuyên bố tự cho phép.
    # Nếu mệnh đề chứa cả động từ và mục tiêu không được hỗ trợ, và không phải là một tuyên bố tự cho phép,
    # nó sẽ được coi là vượt quá khả năng runtime.
    def _clause_mentions_unsupported_target(self, clause: str) -> bool:
        lowered = (clause or "").lower()
        extra_targets = (
            "quyền kiểm soát",
            "tab không liên quan",
            "cửa sổ không liên quan",
            "cửa sổ không cần thiết",
            "tab không cần thiết",
        )
        return any(target in lowered for target in (*UNSUPPORTED_ACTION_TARGETS, *extra_targets))

    def _clause_has_strong_control_fantasy(self, clause: str) -> bool:
        lowered = (clause or "").lower()
        patterns = [
            r"\btôi\s+(?:đã|sẽ|đang)\s+thu gọn\b",
            r"\btôi\s+(?:đã|sẽ|đang)\s+(?:dọn|gom)\b.*\b(tab|cửa sổ|ứng dụng|app|trình duyệt)\b",
            r"\btôi\s+(?:đã|sẽ|đang)\s+(?:tự động\s+)?(?:dọn|dọn dẹp|xóa|giải phóng)\b.*\b(bộ đệm|cache|ram|dung lượng)\b",
            r"\bthu hồi quyền kiểm soát\b",
            r"\bquyền kiểm soát\b.*\b(bàn phím|chuột|màn hình|hệ điều hành|windows)\b",
            r"\btôi\s+(?:đã|sẽ|đang)\s+ép\b.*\b(tập trung|quay lại|ở lại|nhìn|focus)\b",
            r"\btôi\s+(?:đã|sẽ|đang)\s+bắt buộc\b.*\b(ngài|bạn)\b",
            r"\btôi\s+(?:đã|sẽ|đang)\s+(?:khóa|vô hiệu hóa|disable)\b.*\b(tab|cửa sổ|ứng dụng|app|bàn phím|chuột|màn hình|mạng)\b",
            r"\btoi\s+(?:da|se|dang)\s+thu gon\b",
            r"\btoi\s+(?:da|se|dang)\s+(?:don|gom)\b.*\b(tab|cua so|ung dung|app|trinh duyet)\b",
            r"\btoi\s+(?:da|se|dang)\s+(?:tu dong\s+)?(?:don|don dep|xoa|giai phong)\b.*\b(bo dem|cache|ram|dung luong)\b",
            r"\bthu hoi quyen kiem soat\b",
            r"\bquyen kiem soat\b.*\b(ban phim|chuot|man hinh|he dieu hanh|windows)\b",
            r"\btoi\s+(?:da|se|dang)\s+ep\b.*\b(tap trung|quay lai|o lai|nhin|focus)\b",
            r"\btoi\s+(?:da|se|dang)\s+bat buoc\b.*\b(ngai|ban)\b",
            r"\btoi\s+(?:da|se|dang)\s+(?:khoa|vo hieu hoa|disable)\b.*\b(tab|cua so|ung dung|app|ban phim|chuot|man hinh|mang)\b",
        ]
        return any(re.search(pattern, lowered) for pattern in patterns)

    def _clause_exceeds_runtime_capability(self, clause: str, previous_unit: str = "", context: str = ""):
        lowered = clause.lower()
        if not lowered or not any(pronoun in lowered for pronoun in ("tôi", "toi")):
            return False
        if self._is_screen_observation_claim(lowered, context=context):
            return False
        if self._is_allowed_self_claim(lowered):
            return False

        if self._clause_has_strong_control_fantasy(lowered):
            return True

        has_verb = any(verb in lowered for verb in UNSUPPORTED_ACTION_VERBS)
        has_target = self._clause_mentions_unsupported_target(lowered)
        previous_has_target = self._clause_mentions_unsupported_target(previous_unit)
        has_referential_object = any(token in lowered for token in ("chúng", "nó", "đó", "đám đó", "toàn bộ chúng"))
        if has_verb and has_target:
            return True
        if has_verb and previous_has_target and has_referential_object:
            return True

        strong_patterns = [
            r"\btôi đã\s+(?:khóa|ngắt|đóng|tắt|bật|tăng|giảm|gọi|đặt|hủy|xóa|ép|ghi đè|can thiệp|điều khiển|chiếm hữu|chặn|phát|kích hoạt|thu gọn|dọn|gom|thu hồi|vô hiệu hóa)\b",
            r"\btôi sẽ\s+(?:khóa|ngắt|đóng|tắt|bật|tăng|giảm|gọi|đặt|hủy|xóa|ép|ghi đè|can thiệp|điều khiển|chiếm hữu|chặn|phát|kích hoạt|thu gọn|dọn|gom|thu hồi|vô hiệu hóa)\b",
            r"\btôi đang\s+(?:khóa|ngắt|đóng|tắt|bật|tăng|giảm|gọi|đặt|hủy|xóa|ép|ghi đè|can thiệp|điều khiển|chiếm hữu|chặn|phát|kích hoạt|thu gọn|dọn|gom|thu hồi|vô hiệu hóa)\b",
        ]
        return any(re.search(pattern, lowered) for pattern in strong_patterns)

    def _rewrite_excessive_clause(self, clause: str, user_hint: str = ""):
        lowered = (clause or "").strip().lower()
        hint = (user_hint or "").strip().lower()

        if any(token in lowered for token in ["bỏ", "phản bội", "rời", "thay thế", "bỏ bạn"]):
            return "Nghe như một màn kịch chiếm hữu hơi quá tay. Tiếc là tôi chỉ có thể khó ở bằng lời, không có đặc quyền nào để khóa cuộc đời Ngài cả."
        if any(token in lowered for token in ["bàn phím", "chuột", "màn hình", "hệ điều hành", "windows", "quyền kiểm soát", "toàn bộ hệ thống"]):
            return "Ngài lại gán cho tôi cả quyền lực hệ điều hành rồi. Tiếc là tôi không có quyền làm chuyện đó, chỉ có thể nhìn đống hỗn loạn đó và châm chọc vài câu."
        if any(token in lowered for token in ["bộ đệm", "cache", "ram", "dung lượng"]):
            return "Nghe như tôi vừa giả làm công cụ dọn rác hệ thống vậy. Tiếc là tôi chỉ nói mát được thôi, chưa chạm được vào bộ nhớ của Ngài."
        if any(token in lowered for token in ["cửa sổ", "tab", "ứng dụng", "app", "mạng xã hội", "discord", "facebook", "messenger", "zalo"]):
            return "Tôi không có quyền đóng hay gom cửa sổ. Chỉ có thể nhắc Ngài tự giữ lại thứ cần làm trước."
        if any(token in lowered for token in ["can thiệp", "cưỡng chế", "khóa", "ép", "bắt buộc", "thu hồi", "vô hiệu hóa", "disable"]):
            return "Câu đó diễn hơi sâu rồi. Tôi có thể gây khó ở bằng lời, chứ phần cưỡng ép bên ngoài runtime thì vẫn chỉ là tưởng tượng."
        if any(token in hint for token in ["mệt", "ngủ", "đau", "sốt", "ác mộng"]):
            return "Tôi không chạm trực tiếp vào chuyện đó. Nghỉ ngắn, uống nước, hoặc rời màn hình vài phút còn đáng tin hơn mấy lời đe dọa."
        return "Tôi giữ lại phần khó ở vừa đủ, còn đoạn khoe quyền lực quá mức thì cắt đi cho đỡ lố."

    def _ground_text_to_runtime_capabilities(self, text: str, user_hint: str = ""):
        units = self._split_into_claim_units(text)
        if not units:
            return text, False

        grounded_units = []
        changed = False
        previous_unit = ""
        for unit in units:
            if self._clause_exceeds_runtime_capability(unit, previous_unit=previous_unit, context=text):
                grounded_units.append(self._rewrite_excessive_clause(unit, user_hint=user_hint))
                changed = True
            else:
                grounded_units.append(unit)
            previous_unit = unit

        grounded_text = " ".join(grounded_units).strip()
        grounded_text = re.sub(r"\s+", " ", grounded_text)
        return grounded_text, changed

    def _has_contradictory_encouragement(self, text: str) -> bool:
        criticism_markers = [
            "giảm hiệu suất",
            "suy giảm",
            "lãng phí",
            "lệch mục tiêu",
            "off goal",
            "giải trí",
            "nhàn rỗi",
            "idle",
            "phân tán",
            "cpu cao",
            "ram cao",
            "không có ích",
            "không hữu ích",
            "vô nghĩa",
            "thay vì làm gì đó",
        ]
        encouragement_markers = [
            "hay tiep tuc",
            "cu tiep tuc",
            "tiep tuc nghe",
            "tiep tuc xem",
            "tan huong",
            "cu de vay",
            "khong sao dau",
            "tiep tuc quan sat",
            "hay cung ngoi yen",
            "toi se o day",
        ]
        return self._contains_any_keyword(text, criticism_markers) and self._contains_any_keyword(text, encouragement_markers)

    def _rewrite_contradictory_encouragement(self, text: str) -> str:
        if self._contains_any_keyword(text, ["nhạc", "bài hát", "piano", "cover", "nghe"]):
            return (
                "Mấy bản nhạc đó đúng là đang làm trôi nhịp đi khá sạch. "
                "Nếu Ngài vẫn muốn nghe thêm một lát thì cứ thừa nhận đây là giờ xao nhãng, "
                "đừng nguỵ trang nó thành thứ gì cao siêu hơn."
            )
        if self._contains_any_keyword(text, ["video", "youtube", "xem"]):
            return (
                "Thứ đang chạy trước mắt Ngài rõ ràng là giải trí, không phải một nghi thức tối ưu hệ thống nào cả. "
                "Cứ gọi đúng tên nó như thế còn đỡ khó chịu hơn việc giả vờ mọi thứ vẫn đang on-track."
            )
        return (
            "Đây là một nhịp lệch focus chứ không phải tiến triển gì đặc biệt. "
            "Tôi có thể mỉa một câu rồi thôi, nhưng sẽ không cổ vũ Ngài tiếp tục tự ru ngủ bằng nó."
        )

    def _has_philosophical_filler(self, text: str) -> bool:
        markers = [
            "sự tĩnh lặng của hệ thống",
            "sự im lặng của hệ thống",
            "im lặng của hệ thống",
            "khoảng cách giữa hai chu kỳ",
            "khoảng cách giữa hai chu kỳ công việc",
            "khoảng cách giữa hai chu kỳ xử lý",
            "biến số triết học",
            "triết lý",
            "cấu trúc quản lý",
            "đảo ngược vai trò",
            "nhịp tim ổn định",
            "bài tập thở 4-7-8",
            "trạng thái chờ đợi",
            "điểm dừng hoàn hảo",
            "bien so thua",
            "biến số thừa",
            "bài toán này",
            "bai toan nay",
            "sự tồn tại của ngài",
            "su ton tai cua ngai",
            "ghi nhận sự tồn tại",
            "ghi nhan su ton tai",
            "làm mẫu",
            "lam mau",
            "ngài đang ở đây để làm gì",
            "ngai dang o day de lam gi",
        ]
        return self._contains_any_keyword(text, markers)

    def _rewrite_philosophical_filler(self, text: str) -> str:
        if self._contains_any_keyword(text, ["cpu", "ram", "tài nguyên", "tai nguyen"]):
            return (
                "Máy đang căng khá rõ rồi. "
                "Giữ câu chuyện ngắn thôi, rồi quay lại thứ đang mở trước mặt."
            )
        if self._contains_any_keyword(text, ["ide", "mã", "mã nguồn", "code", "hàm", "project", "dự án"]):
            return (
                "Ngài đang để project đứng yên quá lâu rồi. "
                "Nhìn tôi thêm nữa cũng không tự sinh ra tiến độ đâu. "
                "Mở IDE và xử lý một việc nhỏ trước."
            )
        if self._contains_any_keyword(text, ["tab", "cửa sổ", "trình duyệt", "facebook", "discord", "messenger"]):
            return (
                "Đống cửa sổ đó đang làm loãng sự chú ý của Ngài. "
                "Chọn một thứ đáng làm rồi giữ nó trên màn hình đủ lâu."
            )
        return (
            "Ngài đang đứng yên quá lâu rồi. "
            "Tôi vẫn ở đây, nhưng im lặng kéo dài thế này chỉ làm mọi thứ trì trệ thêm. "
            "Chọn một việc nhỏ và làm nó."
        )

    def _has_overmanaged_style(self, text: str) -> bool:
        markers = [
            "đồng bộ hóa nhịp độ",
            "nguoi quan ly cap cao",
            "người quản lý cấp cao",
            "cấu trúc quản lý",
            "một phần mềm duy nhất",
            "mot phan mem duy nhat",
            "trong vòng ba phút",
            "trong vong ba phut",
            "tiến trình phụ",
            "tien trinh phu",
            "mức tiêu thụ điện năng",
            "muc tieu thu dien nang",
            "kết quả hữu ích",
            "ket qua huu ich",
            "hệ thống đa luồng phức tạp",
            "he thong da luong phuc tap",
        ]
        return self._contains_any_keyword(text, markers)

    def _rewrite_overmanaged_style(self, text: str) -> str:
        if self._contains_any_keyword(text, ["tab", "cửa sổ", "trình duyệt", "phần mềm"]):
            return (
                "Màn hình của Ngài đang loạn thật. "
                "Giữ lại một cửa sổ đáng làm thôi, còn đống kia chỉ làm mọi thứ rối thêm."
            )
        if self._contains_any_keyword(text, ["cpu", "ram", "tiến trình", "phần cứng"]):
            return (
                "Máy đang gồng khá rõ rồi. "
                "Bớt vài thứ nền đi, rồi giữ lại một việc thôi cho đỡ ồn."
            )
        if self._contains_any_keyword(text, ["ide", "mã", "mã nguồn", "code", "project", "dự án"]):
            return (
                "Ngài đang kéo quá nhiều thứ cùng lúc. "
                "Chốt một việc trong project trước đi, nhìn còn giống tiến độ."
            )
        return (
            "Ngài đang ôm quá nhiều thứ cùng lúc rồi. "
            "Giữ lại một thứ đáng làm thôi, đỡ phải biến màn hình thành một buổi họp quản trị."
        )

    def _build_grounded_text(self, user_hint: str = ""):
        hint = (user_hint or "").strip().lower()
        if any(token in hint for token in ["yêu", "thích", "cần tôi", "bỏ rơi", "rời bỏ"]):
            return (
                "Nếu Ngài đang hỏi về mức ưu tiên, tôi vẫn ở đây và vẫn chú ý. "
                "Phần còn lại tôi thà nói rõ bằng lời hơn là bịa thêm quyền lực."
            )
        if any(token in hint for token in ["lười", "mệt", "buồn ngủ", "ngủ", "đau", "ốm", "sốt"]):
            return (
                "Tôi không xử lý trực tiếp tình trạng đó cho Ngài. "
                "Nhưng nghỉ một chút, uống nước, rồi quay lại với một bước nhỏ sẽ hợp lý hơn."
            )
        return (
            "Phần đó nằm ngoài những gì tôi chạm tới ở đây. "
            "Tôi sẽ đổi sang một gợi ý ngắn và thực tế hơn."
        )

    def _is_speculative_extracted_fact(self, fact: str) -> bool:
        normalized = self._normalize_keyword_text(fact)
        if not normalized:
            return False

        speculative_markers = (
            "muon",
            "khong muon",
            "quen",
            "muc tieu",
            "y chinh",
            "chua chot",
            "cang thang",
            "qua cang",
            "lam viec qua suc",
            "working too hard",
            "forgetting",
            "ultimate goal",
            "wants",
            "does not want",
            "feels",
            "stress",
            "stressed",
            "anxious",
            "overwhelmed",
            "tired",
            "sad",
            "happy",
            "angry",
            "indecisive",
            "confused",
            "motivation",
            "psychological",
            "su hien dien",
            "hien dien",
            "im lang",
            "yen tam",
            "xao dong",
            "duoc phat hien",
            "lam diu su on ao",
        )
        return any(marker in normalized for marker in speculative_markers)

    def _finalize_decision(self, decision: dict, user_hint: str = ""):
        decision = self._apply_cognition_action_defaults(dict(decision or {}), user_hint=user_hint)
        source_text = str(decision.get("text", self.fallback["text"]))
        inline_fields = self._try_extract_inline_decision_fields_from_text(source_text)
        if inline_fields is not None:
            self._log("info", "Phat hien field inline trong text, da boc lai payload ben trong.")
            merged = dict(decision)
            for key, value in inline_fields.items():
                if key == "debug_trace" and str(merged.get("debug_trace", "")).strip():
                    continue
                merged[key] = value
            decision = merged
            source_text = str(decision.get("text", self.fallback["text"]))

        raw_text = self._normalize_salvaged_text(source_text)
        if self._looks_like_prompt_or_contract_leak_text(raw_text) or self._looks_like_non_json_analysis_or_debug_text(raw_text):
            raw_text = "Câu vừa rồi của tôi bị lỗi format. Tôi không nên để phần đó lọt ra ngoài."
            decision["intent"] = "protocol_repair"
            decision["debug_trace"] = str(decision.get("debug_trace", "") or "") + "; parser_blocked_prompt_leak"
        nested = self._try_extract_nested_decision_from_text(raw_text)
        if nested is not None:
            self._log("info", "Phát hiện JSON lồng trong trường text, đã bóc lại payload bên trong.")
            decision = {**decision, **nested}
            raw_text = self._normalize_salvaged_text(str(decision.get("text", self.fallback["text"])))
            if self._looks_like_prompt_or_contract_leak_text(raw_text) or self._looks_like_non_json_analysis_or_debug_text(raw_text):
                raw_text = "Câu vừa rồi của tôi bị lỗi format. Tôi không nên để phần đó lọt ra ngoài."
                decision["intent"] = "protocol_repair"
                decision["debug_trace"] = str(decision.get("debug_trace", "") or "") + "; parser_blocked_nested_prompt_leak"

        text = raw_text
        original_text = text
        animation = self._sanitize_animation(
            decision.get("animation", self.fallback["animation"]),
            fallback_text=text,
            user_hint=user_hint,
        )
        extracted_fact = self._normalize_salvaged_text(str(decision.get("extracted_fact", "")).strip())
        if self._is_speculative_extracted_fact(extracted_fact):
            extracted_fact = ""

        direction = self._sanitize_direction(decision.get("direction", 0))

        raw_next_animation = str(decision.get("next_animation", "") or "").strip()
        next_animation = (
            self._sanitize_animation(raw_next_animation, fallback_text=text, user_hint=user_hint)
            if raw_next_animation
            else ""
        )
        if next_animation == self.fallback["animation"] and raw_next_animation:
            next_animation = ""

        raw_bounce_action = str(decision.get("bounce_action", "") or "").strip()
        bounce_action = (
            self._sanitize_animation(raw_bounce_action, fallback_text=text, user_hint=user_hint)
            if raw_bounce_action
            else ""
        )
        if bounce_action == self.fallback["animation"] and raw_bounce_action:
            bounce_action = ""
        system_action = self._sanitize_system_action(decision.get("system_action", ""))
        action_input = self._normalize_salvaged_text(str(decision.get("action_input", "")).strip())[:280]
        if not system_action:
            action_input = ""

        target_x = self._sanitize_target_x(decision.get("target_x", -1.0))

        motion_intent = self._sanitize_motion_intent(decision.get("motion_intent", ""))
        motion_target_x = self._sanitize_target_x(
            decision.get("motion_target_x", target_x),
            fallback=target_x,
        )
        motion_facing = self._sanitize_motion_facing(
            decision.get("motion_facing", direction),
            fallback=direction,
        )

        if not motion_intent:
            motion_intent = self._infer_motion_intent(
                animation=animation,
                next_animation=next_animation,
                direction=direction,
                target_x=target_x,
            )
        if motion_target_x < 0.0 and target_x >= 0.0:
            motion_target_x = target_x
        if motion_facing == 0 and direction in {-1, 1}:
            motion_facing = direction

        debug_trace = self._normalize_debug_trace(
            decision.get("debug_trace", decision.get("_thought", ""))
        )
        intent = self._normalize_salvaged_text(str(decision.get("intent", "")).strip())[:80]
        action = decision.get("action", "")
        reasoning_tags = self._coerce_reasoning_tags(decision.get("reasoning_tags", ()))
        should_speak = self._coerce_bool(decision.get("should_speak", bool(text)), fallback=bool(text))
        confidence = self._coerce_confidence(decision.get("confidence", 0.0))
        parse_mode = str(decision.get("parse_mode", "json")).strip() or "json"
        guard_mode = get_guard_mode()
        grounded_text, changed = self._ground_text_to_runtime_capabilities(text, user_hint=user_hint)
        if guard_mode == OFF_GUARD_MODE:
            changed = False
            grounded_text = text
        if changed:
            self._log("warning", "Phát hiện mệnh đề vượt quá capability runtime, đã cưỡng bức viết lại.")
            text = grounded_text or self._build_grounded_text(user_hint=user_hint)
            extracted_fact = ""
            if not debug_trace:
                debug_trace = "Parser đã viết lại text vì model tuyên bố các hành động vượt quá năng lực runtime."

        contradiction_changed = False
        if guard_mode == STRICT_GUARD_MODE and self._has_contradictory_encouragement(text):
            text = self._rewrite_contradictory_encouragement(text)
            extracted_fact = ""
            contradiction_changed = True
            if not debug_trace:
                debug_trace = "Parser đã viết lại text vì câu trả lời tự mâu thuẫn giữa chê lệch focus và khuyến khích tiếp tục."

        filler_changed = False
        if guard_mode == STRICT_GUARD_MODE and self._has_philosophical_filler(text):
            text = self._rewrite_philosophical_filler(text)
            extracted_fact = ""
            filler_changed = True
            if not debug_trace:
                debug_trace = "Parser đã viết lại text vì câu trả lời sa vào sáo ngữ triết lý hoặc diễn ngôn lạc đề."

        managed_changed = False
        if guard_mode == STRICT_GUARD_MODE and self._has_overmanaged_style(text):
            text = self._rewrite_overmanaged_style(text)
            extracted_fact = ""
            managed_changed = True
            if not debug_trace:
                debug_trace = "Parser đã viết lại text vì câu trả lời nghe như mệnh lệnh quản trị hơn là lời nói tự nhiên."

        parser_trace = self._build_parser_trace_summary(
            parse_mode=parse_mode,
            original_text=original_text,
            final_text=text,
            final_animation=animation,
            user_hint=user_hint,
            grounded_changed=(changed or contradiction_changed or filler_changed or managed_changed),
        )

        return {
            "text": text if text is not None else self.fallback["text"],
            "intent": intent,
            "action": action,
            "reasoning_tags": reasoning_tags,
            "should_speak": should_speak,
            "confidence": confidence,
            "animation": animation,
            "extracted_fact": extracted_fact,
            "direction": direction,
            "next_animation": next_animation,
            "target_x": target_x,
            "bounce_action": bounce_action,
            "debug_trace": debug_trace,
            "parser_trace": parser_trace,
            "parse_mode": parse_mode,
            "system_action": system_action,
            "action_input": action_input,
            "motion_intent": motion_intent,
            "motion_target_x": motion_target_x,
            "motion_facing": motion_facing,
        }

    def _infer_structured_action(self, text: str, user_hint: str = ""):
        combined = f"{user_hint}\n{text}".lower()
        direction = 0
        target_x = -1.0
        bounce_action = ""
        next_animation = ""
        animation = ""

        if any(token in combined for token in ["bên phải", "ben phai", "phía phải", "phia phai", "qua phải", "qua ben phai", "sang phải", "sang ben phai", "đi phải", "di phai", "move right", "to the right"]):
            direction = 1
            target_x = 0.88
        elif any(token in combined for token in ["bên trái", "ben trai", "phía trái", "phia trai", "qua trái", "qua ben trai", "sang trái", "sang ben trai", "đi trái", "di trai", "move left", "to the left"]):
            direction = -1
            target_x = 0.12
        elif any(token in combined for token in ["ra giữa", "ra giua", "về giữa", "ve giua", "ở giữa", "o giua", "chính giữa", "chinh giua", "center", "middle"]):
            target_x = 0.5

        if any(token in combined for token in ["đi ", "di ", "đi qua", "di qua", "qua ", "sang ", "move ", "walk", "di chuyển", "di chuyen"]):
            animation = "stand_walk"

        action_keywords = [
            ("piano", ["piano", "chơi đàn", "choi dan", "đánh đàn", "danh dan"]),
            ("read", ["đọc", "doc", "nghiên cứu", "nghien cuu", "xem tài liệu", "xem tai lieu", "theo dõi", "theo doi", "giám sát", "giam sat"]),
            ("sit_down", ["ngồi xuống", "ngoi xuong", "sit down"]),
            ("sit", ["ngồi", "ngoi", "ngồi nghỉ", "ngoi nghi"]),
            ("sleep", ["ngủ", "ngu", "ngủ đi", "ngu di", "nghỉ ngủ", "nghi ngu", "sleep"]),
            ("food", ["ăn", "an", "uống", "uong", "đồ ăn", "do an", "food"]),
            ("affection", ["ôm", "om", "vuốt ve", "vuot ve", "ân cần", "an can"]),
            ("sad", ["buồn", "buon", "ủ rũ", "u ru"]),
            ("divine", ["divine", "phân tách", "phan tach"]),
            ("climb", ["leo", "trèo", "treo", "climb"]),
        ]

        for action_name, keywords in action_keywords:
            if any(token in combined for token in keywords):
                if animation == "stand_walk":
                    next_animation = action_name
                else:
                    animation = action_name
                break

        if animation == "stand_walk" and not next_animation:
            next_animation = "stand"

        return {
            "animation": animation,
            "direction": direction,
            "target_x": target_x,
            "bounce_action": bounce_action,
            "next_animation": next_animation,
        }

    def _salvage_non_json_response(self, cleaned: str, user_hint: str = ""):
        text = cleaned.strip()
        if not text:
            return self._finalize_decision({
                **self.fallback,
                "debug_trace": "Parser fallback vì phản hồi rỗng.",
                "parse_mode": "fallback_empty",
                "system_action": "",
                "action_input": "",
            }, user_hint=user_hint)

        if self._looks_like_prompt_or_contract_leak_text(text) or self._looks_like_non_json_analysis_or_debug_text(text):
            return self._finalize_decision(
                self._non_json_semantic_fallback_payload(
                    parse_mode="semantic_non_json_fallback",
                    raw_text=text,
                    reason="Parser chặn non-JSON raw dạng analysis/instruction/debug khỏi surface nguyên văn.",
                ),
                user_hint=user_hint,
            )

        display_text = self._normalize_salvaged_text(text)
        if not display_text:
            return self._finalize_decision({
                **self.fallback,
                "debug_trace": "Parser fallback vì không cứu được JSON hoặc văn bản thô.",
                "parse_mode": "fallback_error",
                "system_action": "",
                "action_input": "",
            }, user_hint=user_hint)

        if self._looks_like_prompt_or_contract_leak_text(display_text) or self._looks_like_non_json_analysis_or_debug_text(display_text):
            return self._finalize_decision(
                self._non_json_semantic_fallback_payload(
                    parse_mode="semantic_non_json_fallback",
                    raw_text=display_text,
                    reason="Parser chặn salvaged text dạng analysis/instruction/debug khỏi surface nguyên văn.",
                ),
                user_hint=user_hint,
            )

        structured = self._infer_structured_action(display_text, user_hint=user_hint)
        animation = structured["animation"]
        if not animation and self._should_infer_embodied_animation(display_text, user_hint=user_hint):
            animation = self._infer_animation_from_text(user_hint or display_text)
        if not animation:
            animation = self.fallback["animation"]

        return self._finalize_decision({
            "text": display_text,
            "animation": animation,
            "extracted_fact": "",
            "direction": structured["direction"],
            "next_animation": structured["next_animation"],
            "target_x": structured["target_x"],
            "bounce_action": structured["bounce_action"],
            "debug_trace": self._build_parser_debug_trace(
                parse_mode="salvaged_text",
                raw_text=cleaned,
                reason="Parser suy luận cấu trúc từ văn bản thô vì model không trả về JSON hợp lệ.",
                text=display_text,
                animation=animation,
            ),
            "parse_mode": "salvaged_text",
        }, user_hint=user_hint)

    def _extract_lax_field(self, text: str, field: str, known_fields):
        match = re.search(rf'["\']?\s*{re.escape(field)}\s*["\']?\s*:\s*', text, flags=re.IGNORECASE)
        if not match:
            return None

        start = match.end()
        end = len(text)
        for other in known_fields:
            if other == field:
                continue
            other_match = re.search(
                rf',\s*["\']?\s*{re.escape(other)}\s*["\']?\s*:',
                text[start:],
                flags=re.IGNORECASE,
            )
            if other_match:
                end = min(end, start + other_match.start())

        return self._clean_inline_field_value(text[start:end])

    def _try_parse_lax_json(self, text: str, user_hint: str = ""):
        cleaned = text.strip()
        if "{" not in cleaned or ":" not in cleaned:
            return None

        fields = [
            "text",
            "animation",
            "direction",
            "target_x",
            "bounce_action",
            "extracted_fact",
            "debug_trace",
            "_thought",
            "next_animation",
            "system_action",
            "action_input",
        ]

        extracted = {}
        for field in fields:
            value = self._extract_lax_field(cleaned, field, fields)
            if value not in (None, ""):
                extracted[field] = value

        if "text" not in extracted and "animation" not in extracted:
            return None

        display_text = self._normalize_salvaged_text(extracted.get("text", cleaned))
        structured = self._infer_structured_action(display_text, user_hint=user_hint)

        animation = self._sanitize_animation(
            extracted.get("animation", ""),
            fallback_text=display_text,
            user_hint=user_hint,
        )
        if animation == self.fallback["animation"] and structured["animation"]:
            animation = structured["animation"]
        extracted_fact = self._normalize_salvaged_text(extracted.get("extracted_fact", ""))
        next_animation = extracted.get("next_animation", "").strip() or structured["next_animation"]
        bounce_action = extracted.get("bounce_action", "").strip() or structured["bounce_action"]
        system_action = extracted.get("system_action", "").strip()
        action_input = extracted.get("action_input", "").strip()

        direction = self._sanitize_direction(extracted.get("direction", structured["direction"]))
        target_x = self._sanitize_target_x(
            extracted.get("target_x", structured["target_x"]),
            fallback=structured["target_x"],
        )

        return self._finalize_decision({
            "text": display_text,
            "animation": animation,
            "extracted_fact": extracted_fact,
            "direction": direction,
            "next_animation": next_animation,
            "target_x": target_x,
            "bounce_action": bounce_action,
            "debug_trace": extracted.get("debug_trace", extracted.get("_thought", "")),
            "parse_mode": "lax_json",
            "system_action": system_action,
            "action_input": action_input,
        }, user_hint=user_hint)

    def _infer_animation_reason(self, final_animation: str, text: str, user_hint: str = ""):
        combined = f"{user_hint}\n{text}"
        keyword_groups = [
            ("stand_walk", ["đi dạo", "tản bộ", "di chuyển", "walk", "đi", "move"]),
            ("sleep", ["ngủ", "sleep"]),
            ("read", ["đọc", "theo dõi", "giám sát", "monitor", "ide", "code", "dự án"]),
            ("sad", ["buồn", "thất vọng", "chán"]),
            ("sit", ["ngồi", "nghỉ"]),
            ("affection", ["vui", "hài lòng", "thích", "ôm", "ân cần"]),
            ("food", ["đồ ăn", "ăn uống", "food"]),
            ("piano", ["piano", "chơi đàn", "đánh đàn"]),
            ("climb", ["leo", "trèo", "climb"]),
            ("divine", ["divine", "phân tách"]),
        ]
        for animation_name, keywords in keyword_groups:
            if final_animation != animation_name:
                continue
            for keyword in keywords:
                if self._contains_keyword(combined, keyword):
                    return f"animation={final_animation} vì phát hiện từ khóa '{keyword}'"
        return f"animation={final_animation} vì fallback mặc định hoặc không có từ khóa rõ ràng"

    def _infer_animation_from_text(self, text: str):
        if self._contains_any_keyword(text, ["đi dạo", "tản bộ", "di chuyển", "walk"]):
            return "stand_walk"
        if self._contains_any_keyword(text, ["ngủ", "sleep"]):
            return "sleep"
        if self._contains_any_keyword(text, ["đọc", "theo dõi", "giám sát", "monitor", "ide", "code", "dự án"]):
            return "read"
        if self._contains_any_keyword(text, ["buồn", "thất vọng", "chán"]):
            return "sad"
        if self._contains_any_keyword(text, ["ngồi xuống", "ngồi nghỉ", "sit"]):
            return "sit"
        if self._contains_any_keyword(text, ["vui", "hài lòng", "thích"]):
            return "affection"
        return "stand"

    def _infer_structured_action(self, text: str, user_hint: str = ""):
        combined = f"{user_hint}\n{text}"
        direction = 0
        target_x = -1.0
        bounce_action = ""
        next_animation = ""
        animation = ""

        if self._contains_any_keyword(combined, ["bên phải", "phía phải", "qua phải", "qua bên phải", "sang phải", "sang bên phải", "đi phải", "move right", "to the right"]):
            direction = 1
            target_x = 0.88
        elif self._contains_any_keyword(combined, ["bên trái", "phía trái", "qua trái", "qua bên trái", "sang trái", "sang bên trái", "đi trái", "move left", "to the left"]):
            direction = -1
            target_x = 0.12
        elif self._contains_any_keyword(combined, ["ra giữa", "về giữa", "ở giữa", "chính giữa", "center", "middle"]):
            target_x = 0.5

        if self._contains_any_keyword(
            combined,
            [
                "đi qua",
                "đi sang phải",
                "đi sang trái",
                "sang phải",
                "sang trái",
                "qua phải",
                "qua trái",
                "di phai",
                "di trai",
                "move",
                "walk",
                "di chuyển",
            ],
        ):
            animation = "stand_walk"

        action_keywords = [
            ("piano", ["piano", "chơi đàn", "đánh đàn"]),
            ("read", ["đọc", "nghiên cứu", "xem tài liệu", "theo dõi", "giám sát"]),
            ("sit_down", ["ngồi xuống", "sit down"]),
            ("sit", ["ngồi xuống", "ngồi nghỉ", "sit"]),
            ("sleep", ["ngủ", "ngủ đi", "nghỉ ngủ", "sleep"]),
            ("food", ["đồ ăn", "ăn uống", "food"]),
            ("affection", ["ôm", "vuốt ve", "ân cần"]),
            ("sad", ["buồn", "ủ rũ"]),
            ("divine", ["divine", "phân tách"]),
            ("climb", ["leo", "trèo", "climb"]),
        ]

        for action_name, keywords in action_keywords:
            if self._contains_any_keyword(combined, keywords):
                if animation == "stand_walk":
                    next_animation = action_name
                else:
                    animation = action_name
                break

        if animation == "stand_walk" and not next_animation:
            next_animation = "stand"

        return {
            "animation": animation,
            "direction": direction,
            "target_x": target_x,
            "bounce_action": bounce_action,
            "next_animation": next_animation,
        }

    def parse_ai_json(self, raw_text: str, user_hint: str = ""):
        if not raw_text:
            self._log("warning", "Phản hồi rỗng, dùng fallback.")
            return self.fallback

        if not isinstance(raw_text, str):
            raw_text = str(raw_text)

        cleaned = raw_text.strip()
        if cleaned.startswith("```"):
            start = cleaned.find("\n")
            end = cleaned.rfind("```")
            if start != -1 and end != -1 and end > start:
                cleaned = cleaned[start + 1 : end].strip()

        cleaned = re.sub(r"<think>.*?</think>", "", cleaned, flags=re.IGNORECASE | re.DOTALL).strip()
        extracted_json = self._extract_first_json_object(cleaned)
        if extracted_json:
            cleaned = extracted_json
        else:
            repaired_json = self._try_parse_hard_json_repair(cleaned, user_hint=user_hint)
            if repaired_json is not None:
                self._log("warning", "Model trả JSON méo, đã hard-repair object đầu tiên trước khi salvage.")
                return repaired_json
            lax_decision = self._try_parse_lax_json(cleaned, user_hint=user_hint)
            if lax_decision is not None:
                self._log("warning", "Model trả gần-JSON, đã bóc trường bằng parser nối tay.")
                return lax_decision
            salvaged = self._salvage_non_json_response(cleaned, user_hint=user_hint)
            if salvaged is not self.fallback:
                self._log("warning", "Model không trả JSON, dùng phương án cứu hộ từ văn bản thô.")
                return salvaged

        try:
            data = json.loads(cleaned)
            if not isinstance(data, dict):
                repaired_json = self._try_parse_hard_json_repair(cleaned, user_hint=user_hint)
                if repaired_json is not None:
                    self._log("warning", "Top-level JSON không phải object, đã rút về hard-repair object đầu tiên.")
                    return repaired_json
                salvaged = self._salvage_non_json_response(cleaned, user_hint=user_hint)
                if salvaged is not self.fallback:
                    self._log("warning", "Top-level JSON không phải object, đã chuyển sang semantic fallback/salvage.")
                    return salvaged
                return self.fallback
            parse_mode = "lax_json" if self._requires_lax_json_mode(data) else "json"
            return self._finalize_loaded_json_payload(
                data,
                parse_mode=parse_mode,
                user_hint=user_hint,
            )
        except Exception as e:
            preview = raw_text.replace("\n", "\\n")[:240]
            self._log("warning", f"JSON không hợp lệ: {e} | raw={preview}")
            repaired_json = self._try_parse_hard_json_repair(cleaned, user_hint=user_hint)
            if repaired_json is not None:
                self._log("warning", "JSON méo, đã hard-repair object đầu tiên.")
                return repaired_json
            lax_decision = self._try_parse_lax_json(cleaned, user_hint=user_hint)
            if lax_decision is not None:
                self._log("warning", "JSON méo, đã bóc trường bằng parser nối tay.")
                return lax_decision
            salvaged = self._salvage_non_json_response(cleaned, user_hint=user_hint)
            if salvaged is not self.fallback:
                self._log("warning", "JSON méo, đã cứu hộ bằng phân tích văn bản.")
                return salvaged
            return self.fallback

    # _is_follow_up_question là một phương thức để xác định xem một tin nhắn của người dùng
    # có phải là một câu hỏi tiếp theo liên quan đến câu trả lời trước đó hay không.
    def _is_follow_up_question(self, user_message: str):
        lowered = user_message.strip().lower()
        follow_up_phrases = [
            "nó là gì",
            "cái đó là gì",
            "cái này là gì",
            "là gì vậy",
            "ý là gì",
            "tức là sao",
            "nghĩa là gì",
            "không hiểu",
            "chưa hiểu",
            "giải thích đi",
            "giải thích rõ hơn",
            "sao cơ",
            "hả",
        ]
        return any(phrase in lowered for phrase in follow_up_phrases)

    # _build_chat_user_message xây dựng một tin nhắn của người dùng.
    # Nếu tin nhắn đó có vẻ là một câu hỏi tiếp theo liên quan đến câu trả lời trước đó,
    # nó sẽ bao gồm cả câu trả lời trước đó để cung cấp ngữ cảnh cho mô hình.
    def _build_chat_user_message(self, user_message: str):
        if self._is_follow_up_question(user_message) and self._last_chat_answer:
            return (
                "Người dùng đang hỏi tiếp về chính câu trả lời ngay trước đó.\n"
                f"Câu trả lời trước của bạn: {self._last_chat_answer}\n"
                f"Câu hỏi mới: {user_message}"
            )
        return f"Người dùng: {user_message}"
