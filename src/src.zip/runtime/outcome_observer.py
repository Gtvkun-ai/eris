from __future__ import annotations

"""
runtime/outcome_observer.py

Tầng này đọc kết quả sau một lượt chạy của ERIS.

Nguyên tắc thiết kế:
- OutcomeObserver chỉ quan sát và phân loại hậu quả.
- Không ghi memory trực tiếp.
- Không sửa frame theo kiểu side-effect nặng, ngoại trừ gắn `frame.outcome`
  nếu frame có field đó.
- Những kết luận cần phản hồi của user phải để `None` hoặc confidence thấp
  khi chưa có tín hiệu user thật.
"""

import re
import unicodedata
from dataclasses import asdict, dataclass, field
from typing import Any, Mapping, Optional


@dataclass(slots=True)
class OutcomeReport:
    """
    Báo cáo hậu quả sau một turn.

    Các field lõi bám theo ERIS Cognitive Pipeline:
    - user_accepted: user có chấp nhận/đồng ý với câu trả lời không.
      `None` nghĩa là chưa đủ tín hiệu.
    - user_corrected: user có sửa ERIS không.
    - user_ignored: user có bỏ qua phản hồi không.
      Field này chỉ nên bật khi runtime có tín hiệu idle/session thật.
    - user_laughed: user có phản ứng hài/hưởng ứng không.
    - user_confused: user có vẻ khó hiểu/lạc nhịp không.
    - user_felt_intruded: user có cảm giác bị xen vào/bị suy diễn/bị xâm phạm không.
      `None` nghĩa là chưa đủ tín hiệu.
    - relation_improved / relation_ruptured: quan hệ có tốt lên/rạn đi không.
      `None` nghĩa là chưa đủ tín hiệu.
    - action_success: hành động/text/system action có thực thi ổn không.
    - body_match_success: body có khớp speech/action không.
    - evidence: các mẩu bằng chứng ngắn, dùng cho audit/debug.
    """

    user_accepted: Optional[bool] = None
    user_corrected: bool = False
    user_ignored: bool = False
    user_laughed: bool = False
    user_confused: bool = False
    user_felt_intruded: Optional[bool] = None
    relation_improved: Optional[bool] = None
    relation_ruptured: Optional[bool] = None
    action_success: float = 1.0
    body_match_success: float = 1.0
    evidence: list[str] = field(default_factory=list)

    # Metadata phụ để self_observation phân loại lỗi chính xác hơn.
    confidence: float = 0.5
    correction_text: str = ""
    ignored_reason: str = ""
    accepted_reason: str = ""
    rupture_reason: str = ""
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_any(cls, value: Any) -> "OutcomeReport":
        if isinstance(value, cls):
            return value
        if isinstance(value, Mapping):
            allowed = {field.name for field in cls.__dataclass_fields__.values()}
            return cls(**{key: val for key, val in value.items() if key in allowed})
        return cls()


class OutcomeObserver:
    """
    Đọc tín hiệu hậu quả sau một turn.

    Cách dùng thường gặp:
        outcome = outcome_observer.observe(frame)
        frame.outcome = outcome

    Nếu muốn đánh giá phản ứng user đối với turn trước:
        outcome = outcome_observer.observe(previous_frame, user_feedback_text=current_user_text)

    Tầng này không nên đoán quá sâu. Nếu thiếu feedback của user,
    các field như accepted/corrected/ruptured phải giữ ở mức không chắc.
    """

    ACCEPTANCE_PATTERNS = (
        "đúng", "dung", "chuẩn", "chuan", "hợp lý", "hop ly",
        "ok", "oke", "được", "duoc", "ngon", "ổn", "on",
        "đúng rồi", "dung roi", "chuẩn rồi", "chuan roi",
        "hợp lý đó", "hop ly do", "tiếp", "tiếp tục", "tiep tuc",
    )

    CORRECTION_PATTERNS = (
        "không phải", "khong phai", "sai rồi", "sai roi", "sai",
        "thiếu", "thieu", "chưa đúng", "chua dung", "chưa phải", "chua phai",
        "đọc lại", "doc lai", "lệch", "lech", "nhầm", "nham",
        "không hiểu ý", "khong hieu y", "ý tôi là", "y toi la",
        "no, ", "not what", "wrong", "incorrect", "you missed",
    )

    CONFUSION_PATTERNS = (
        "khó hiểu", "kho hieu", "gì vậy", "gi vay", "là sao", "la sao",
        "nói gì", "noi gi", "không hiểu", "khong hieu", "wtf",
        "what do you mean", "confused",
    )

    LAUGHTER_PATTERNS = (
        "haha", "hahaha", "hehe", "hihi", "kkk", "kaka", "lol", "lmao",
        "cười", "cuoi", "hề", "he",
    )

    INTRUSION_PATTERNS = (
        "đừng suy diễn", "dung suy dien", "đừng hỏi", "dung hoi",
        "đừng nói kháy", "dung noi khay", "nói kháy", "noi khay",
        "móc mỉa", "moc mia", "phiền", "phien", "xen vào", "xen vao",
        "overread", "mindread", "intrusive", "privacy",
        "đừng phân tích", "dung phan tich",
    )

    RUPTURE_PATTERNS = (
        "khó chịu", "kho chiu", "bực", "buc", "cay", "ghét", "ghet",
        "tức", "tuc", "ngu eq", "nói như", "noi nhu",
        "chán", "chan", "thất vọng", "that vong",
    )

    IMPROVEMENT_PATTERNS = (
        "cảm ơn", "cam on", "thanks", "thank you",
        "đúng ý", "dung y", "hợp gu", "hop gu",
        "nghe được", "nghe duoc", "ổn rồi", "on roi",
    )

    NEGATED_ACCEPTANCE_PATTERNS = (
        "ok nhưng sai", "ok nhung sai", "đúng nhưng", "dung nhung",
        "chuẩn nhưng", "chuan nhung", "hợp lý nhưng", "hop ly nhung",
    )

    def observe(
        self,
        frame: Any,
        *,
        user_feedback_text: str | None = None,
        execution_result: Any = None,
        body_result: Any = None,
        idle_seconds_after_turn: float | None = None,
        attach_to_frame: bool = True,
    ) -> OutcomeReport:
        """
        Tạo OutcomeReport từ frame và các tín hiệu hậu quả.

        Parameters
        ----------
        frame:
            CognitiveFrame hoặc object tương thích.
        user_feedback_text:
            Phản hồi user sau turn này. Nếu chưa có thì để None.
        execution_result:
            Kết quả system action nếu có. Có thể là dict/dataclass có `success`.
        body_result:
            Kết quả body/modality nếu có. Có thể là dict/dataclass có `matched` hoặc `success`.
        idle_seconds_after_turn:
            Nếu runtime biết user im/bỏ qua sau turn bao lâu, truyền vào đây.
        attach_to_frame:
            Nếu True, gắn report vào `frame.outcome` khi có thể.
        """

        evidence: list[str] = []
        tags: list[str] = []

        final_text = self._extract_final_text(frame)
        system_action = self._extract_system_action(frame)

        action_success = self._infer_action_success(
            frame,
            final_text=final_text,
            system_action=system_action,
            execution_result=execution_result,
            evidence=evidence,
            tags=tags,
        )
        body_match_success = self._infer_body_match_success(
            frame,
            body_result=body_result,
            evidence=evidence,
            tags=tags,
        )

        feedback = str(user_feedback_text or "").strip()
        normalized_feedback = self._normalize(feedback)

        user_corrected = False
        user_accepted: Optional[bool] = None
        user_laughed = False
        user_confused = False
        user_felt_intruded: Optional[bool] = None
        relation_improved: Optional[bool] = None
        relation_ruptured: Optional[bool] = None
        correction_text = ""
        accepted_reason = ""
        rupture_reason = ""

        if feedback:
            user_corrected = self._has_any(normalized_feedback, self.CORRECTION_PATTERNS)
            user_laughed = self._has_any(normalized_feedback, self.LAUGHTER_PATTERNS)
            user_confused = self._has_any(normalized_feedback, self.CONFUSION_PATTERNS)
            intruded = self._has_any(normalized_feedback, self.INTRUSION_PATTERNS)
            ruptured = self._has_any(normalized_feedback, self.RUPTURE_PATTERNS)
            improved = self._has_any(normalized_feedback, self.IMPROVEMENT_PATTERNS)
            accepted = self._has_any(normalized_feedback, self.ACCEPTANCE_PATTERNS)
            negated_acceptance = self._has_any(normalized_feedback, self.NEGATED_ACCEPTANCE_PATTERNS)

            if user_corrected:
                correction_text = feedback[:300]
                evidence.append(f"user_feedback_correction={feedback[:140]}")
                tags.append("user_correction")

            if user_confused:
                evidence.append(f"user_feedback_confusion={feedback[:140]}")
                tags.append("user_confused")

            if user_laughed:
                evidence.append(f"user_feedback_laughter={feedback[:140]}")
                tags.append("user_laughed")

            if intruded:
                user_felt_intruded = True
                evidence.append(f"user_feedback_intrusion={feedback[:140]}")
                tags.append("user_felt_intruded")

            # Acceptance không được thắng correction. Câu "ok nhưng sai" là correction.
            if accepted and not user_corrected and not negated_acceptance:
                user_accepted = True
                accepted_reason = "user_feedback_acceptance"
                evidence.append(f"user_feedback_acceptance={feedback[:140]}")
                tags.append("user_accepted")
            elif user_corrected or user_confused:
                user_accepted = False

            if ruptured or intruded:
                relation_ruptured = True
                rupture_reason = "user_feedback_rupture_or_intrusion"
                evidence.append(f"user_feedback_rupture={feedback[:140]}")
                tags.append("relation_ruptured")
            elif improved or (accepted and not user_corrected and not negated_acceptance):
                relation_improved = True
                evidence.append(f"user_feedback_improvement={feedback[:140]}")
                tags.append("relation_improved")

            if user_felt_intruded is None and feedback:
                user_felt_intruded = False

        user_ignored = False
        ignored_reason = ""
        if idle_seconds_after_turn is not None:
            try:
                idle_value = float(idle_seconds_after_turn)
            except Exception:
                idle_value = 0.0
            # Không nên kết luận bị ignore quá sớm. Chỉ bật nếu im lâu và turn thật sự có nói/hành động.
            if idle_value >= 90.0 and (final_text or system_action):
                user_ignored = True
                ignored_reason = f"idle_after_turn={idle_value:.1f}s"
                evidence.append(ignored_reason)
                tags.append("user_ignored")

        confidence = self._estimate_confidence(
            has_feedback=bool(feedback),
            user_corrected=user_corrected,
            user_accepted=user_accepted,
            user_confused=user_confused,
            user_felt_intruded=user_felt_intruded,
            action_success=action_success,
            body_match_success=body_match_success,
        )

        report = OutcomeReport(
            user_accepted=user_accepted,
            user_corrected=user_corrected,
            user_ignored=user_ignored,
            user_laughed=user_laughed,
            user_confused=user_confused,
            user_felt_intruded=user_felt_intruded,
            relation_improved=relation_improved,
            relation_ruptured=relation_ruptured,
            action_success=self._clamp01(action_success),
            body_match_success=self._clamp01(body_match_success),
            evidence=evidence[:12],
            confidence=self._clamp01(confidence),
            correction_text=correction_text,
            ignored_reason=ignored_reason,
            accepted_reason=accepted_reason,
            rupture_reason=rupture_reason,
            tags=tags[:12],
        )

        if attach_to_frame:
            self._safe_setattr(frame, "outcome", report)

        return report

    def observe_user_feedback_for_previous_frame(
        self,
        previous_frame: Any,
        user_feedback_text: str,
        *,
        attach_to_frame: bool = True,
    ) -> OutcomeReport:
        """
        Helper dành cho coordinator khi user vừa nhắn một câu phản hồi.
        Thay vì đánh giá current frame, nó đánh giá câu user đó như phản ứng
        đối với previous_frame.
        """

        return self.observe(
            previous_frame,
            user_feedback_text=user_feedback_text,
            attach_to_frame=attach_to_frame,
        )

    def _infer_action_success(
        self,
        frame: Any,
        *,
        final_text: str,
        system_action: str,
        execution_result: Any,
        evidence: list[str],
        tags: list[str],
    ) -> float:
        if execution_result is not None:
            success = self._read_bool(execution_result, "success")
            if success is not None:
                evidence.append(f"execution_success={success}")
                tags.append("execution_result")
                return 1.0 if success else 0.0

            score = self._read_float(execution_result, "success_score")
            if score is not None:
                evidence.append(f"execution_success_score={score:.2f}")
                tags.append("execution_result")
                return score

        execution = getattr(frame, "execution", None)
        if execution is not None:
            success = self._read_bool(execution, "success")
            if success is not None:
                evidence.append(f"frame_execution_success={success}")
                tags.append("frame_execution")
                return 1.0 if success else 0.0

        # Nếu có system action nhưng không có execution_result, chỉ nên coi là chưa chắc.
        if system_action:
            evidence.append(f"system_action_without_execution_result={system_action}")
            tags.append("system_action_uncertain")
            return 0.55

        # Nếu turn có text hợp lệ thì speech execution coi như thành công ở tầng output.
        if final_text:
            evidence.append("speech_text_present")
            tags.append("speech_executed")
            return 1.0

        # Im lặng có thể là hành vi đúng. Không phạt nếu speech_opportunity/action_plan nói no_speech.
        speech_core = getattr(frame, "speech_core", None)
        utterance_type = str(getattr(speech_core, "utterance_type", "") or "")
        if utterance_type in {"no_speech", "silence"}:
            evidence.append(f"intentional_silence={utterance_type}")
            tags.append("intentional_silence")
            return 1.0

        return 0.5

    def _infer_body_match_success(
        self,
        frame: Any,
        *,
        body_result: Any,
        evidence: list[str],
        tags: list[str],
    ) -> float:
        if body_result is not None:
            matched = self._read_bool(body_result, "matched")
            if matched is None:
                matched = self._read_bool(body_result, "success")
            if matched is not None:
                evidence.append(f"body_matched={matched}")
                tags.append("body_result")
                return 1.0 if matched else 0.0

            score = self._read_float(body_result, "match_score")
            if score is not None:
                evidence.append(f"body_match_score={score:.2f}")
                tags.append("body_result")
                return score

        modality = getattr(frame, "modality", None)
        contradiction_risk = self._read_float(modality, "contradiction_risk") if modality is not None else None
        if contradiction_risk is not None:
            score = 1.0 - self._clamp01(contradiction_risk)
            evidence.append(f"modality_contradiction_risk={contradiction_risk:.2f}")
            tags.append("modality")
            return score

        grounding = getattr(frame, "grounding", None)
        body_mismatch = self._read_float(grounding, "body_action_mismatch") if grounding is not None else None
        if body_mismatch is not None:
            score = 1.0 - self._clamp01(body_mismatch)
            evidence.append(f"grounding_body_action_mismatch={body_mismatch:.2f}")
            tags.append("grounding")
            return score

        return 1.0

    def _estimate_confidence(
        self,
        *,
        has_feedback: bool,
        user_corrected: bool,
        user_accepted: Optional[bool],
        user_confused: bool,
        user_felt_intruded: Optional[bool],
        action_success: float,
        body_match_success: float,
    ) -> float:
        confidence = 0.42
        if has_feedback:
            confidence += 0.28
        if user_corrected or user_confused:
            confidence += 0.12
        if user_accepted is not None:
            confidence += 0.08
        if user_felt_intruded is not None:
            confidence += 0.06
        if action_success in (0.0, 1.0):
            confidence += 0.04
        if body_match_success in (0.0, 1.0):
            confidence += 0.02
        return confidence

    @classmethod
    def _normalize(cls, text: str) -> str:
        text = str(text or "").strip().lower()
        text = unicodedata.normalize("NFD", text)
        text = "".join(char for char in text if unicodedata.category(char) != "Mn")
        text = re.sub(r"\s+", " ", text)
        return text

    @classmethod
    def _has_any(cls, normalized_text: str, patterns: tuple[str, ...]) -> bool:
        if not normalized_text:
            return False
        for pattern in patterns:
            normalized_pattern = cls._normalize(pattern)
            if normalized_pattern and normalized_pattern in normalized_text:
                return True
        return False

    @staticmethod
    def _extract_final_text(frame: Any) -> str:
        final_decision = getattr(frame, "final_decision", None)
        if isinstance(final_decision, Mapping):
            return str(final_decision.get("text", "") or "").strip()
        decision = getattr(frame, "decision", None)
        return str(getattr(decision, "text", "") or "").strip()

    @staticmethod
    def _extract_system_action(frame: Any) -> str:
        final_decision = getattr(frame, "final_decision", None)
        if isinstance(final_decision, Mapping):
            action = str(final_decision.get("system_action", "") or "").strip()
            if action:
                return action
        action_plan = getattr(frame, "action_plan", None)
        return str(getattr(action_plan, "system_action", "") or "").strip()

    @staticmethod
    def _read_bool(obj: Any, key: str) -> bool | None:
        if obj is None:
            return None
        if isinstance(obj, Mapping) and key in obj:
            value = obj.get(key)
        else:
            value = getattr(obj, key, None)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            lowered = value.strip().lower()
            if lowered in {"true", "yes", "1", "ok", "success"}:
                return True
            if lowered in {"false", "no", "0", "failed", "error"}:
                return False
        return None

    @staticmethod
    def _read_float(obj: Any, key: str) -> float | None:
        if obj is None:
            return None
        if isinstance(obj, Mapping) and key in obj:
            value = obj.get(key)
        else:
            value = getattr(obj, key, None)
        try:
            return float(value)
        except Exception:
            return None

    @staticmethod
    def _safe_setattr(obj: Any, key: str, value: Any) -> None:
        try:
            setattr(obj, key, value)
        except Exception:
            return

    @staticmethod
    def _clamp01(value: float) -> float:
        try:
            return max(0.0, min(1.0, float(value)))
        except Exception:
            return 0.0
