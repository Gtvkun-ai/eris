Runtime logs are intentionally excluded from this source package.
Eris will recreate log files when it starts.
