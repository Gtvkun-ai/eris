"""
LangGraph State definition for the Agent Harness.
Defines the schema for the agent's memory that will be checkpointed.
"""
from typing import TypedDict, Annotated, List, Dict, Any, Optional
from langchain_core.messages import BaseMessage

def add_messages(left: List[BaseMessage], right: List[BaseMessage]) -> List[BaseMessage]:
    """Reducer function to append new messages to the existing list."""
    # LangGraph's default add_messages handles message ID deduplication and updates
    from langgraph.graph.message import add_messages as builtin_add_messages
    return builtin_add_messages(left, right)

class AgentState(TypedDict):
    """
    The state dictionary that LangGraph passes between nodes.
    This entire dictionary is snapshotted by the checkpointer.
    """
    # The conversational history and tool invocations
    messages: Annotated[List[BaseMessage], add_messages]
    
    # The top-level goal provided by the user/Subject Core
    goal: str
    
    # Skills that have been dynamically loaded (Progressive Disclosure)
    active_skills: List[str]
    
    # A scratchpad for the agent's current plan or internal thoughts
    plan: Optional[str]
    
    # Any context injected by SkillLoader (e.g., SKILL.md contents)
    injected_context: str
    
    # Number of steps taken (for loop detection/limits)
    step_count: int
