"""
LangGraph Builder for the Unified Agent Harness.
Compiles the state machine (nodes and edges) and applies the checkpointer.
"""
from typing import Literal
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage, SystemMessage
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver

from .graph_state import AgentState
from .permission_gate import PermissionGate, Permission
from .capability_discovery import CapabilityDiscovery
from .skill_loader import SkillLoader

class AgentHarness:
    def __init__(self, llm, powers_root: str):
        self.llm = llm
        self.discovery = CapabilityDiscovery(powers_root)
        self.skill_loader = SkillLoader(self.discovery)
        self.permission_gate = PermissionGate()
        
        self.graph = self._build_graph()
        
    def _agent_node(self, state: AgentState) -> dict:
        """The core reasoning step."""
        messages = state.get("messages", [])
        injected = state.get("injected_context", "")
        
        sys_msg = SystemMessage(content=(
            f"You are Eris, operating under a unified agent harness.\n"
            f"Current Goal: {state.get('goal')}\n"
            f"Active Skills: {', '.join(state.get('active_skills', []))}\n"
            f"\n--- INJECTED SKILL CONTEXT ---\n"
            f"{injected}\n"
            f"--- END SKILL CONTEXT ---\n"
        ))
        
        # If we had tools bound to self.llm, it would automatically decide to call them here.
        # response = self.llm.invoke([sys_msg] + messages)
        
        # Scaffold response logic
        step = state.get("step_count", 0) + 1
        
        return {"step_count": step}
        
    def _tool_execution_node(self, state: AgentState) -> dict:
        """Executes tools and enforces PermissionGate."""
        messages = state.get("messages", [])
        if not messages:
            return {}
            
        last_message = messages[-1]
        
        # In a real implementation, you would iterate over last_message.tool_calls
        # For each tool:
        #   perm = self.permission_gate.check_permission(tool_name)
        #   if perm == Permission.ASK:
        #       # LangGraph allows returning a state that triggers an interrupt,
        #       # or we can use workflow.compile(interrupt_before=["tools"])
        #       pass
        
        return {}

    def _should_continue(self, state: AgentState) -> Literal["tools", "__end__"]:
        messages = state.get("messages", [])
        if not messages:
            return "__end__"
        last_message = messages[-1]
        
        # If LLM decides to call tools, route to 'tools' node
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
            
        return "__end__"

    def _build_graph(self):
        workflow = StateGraph(AgentState)
        
        workflow.add_node("agent", self._agent_node)
        workflow.add_node("tools", self._tool_execution_node)
        
        workflow.add_edge(START, "agent")
        workflow.add_conditional_edges(
            "agent",
            self._should_continue,
            {
                "tools": "tools",
                "__end__": END
            }
        )
        workflow.add_edge("tools", "agent")
        
        # MemorySaver provides the Time Travel / Checkpoint capability!
        checkpointer = MemorySaver()
        
        # Compile with checkpointer.
        # If we want Human-in-the-loop (for ASK permissions), we could interrupt before 'tools'.
        return workflow.compile(checkpointer=checkpointer)

    def invoke(self, goal: str, thread_id: str = "default_thread"):
        """Entry point to start the agent loop."""
        config = {"configurable": {"thread_id": thread_id}}
        
        initial_state = {
            "goal": goal,
            "messages": [HumanMessage(content=goal)],
            "active_skills": [],
            "injected_context": "",
            "step_count": 0
        }
        
        return self.graph.invoke(initial_state, config)
