using Godot;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.Json;

public partial class UdpListener
{
    // Agent Console là control surface cho executor (Gemini/Codex/...). Nó chỉ
    // render typed events từ Brain; tuyệt đối không parse log để đoán Agent đang làm gì.
    private sealed class AgentConsoleChoiceView
    {
        public string Id { get; set; } = "";
        public string Label { get; set; } = "";
        public string Description { get; set; } = "";
        public string Value { get; set; } = "";
    }

    private sealed class AgentConsoleEventView
    {
        public string EventId { get; set; } = "";
        public string Type { get; set; } = "";
        public string Actor { get; set; } = "system";
        public string Summary { get; set; } = "";
        public string Detail { get; set; } = "";
        public string DataText { get; set; } = "";
        public string Question { get; set; } = "";
        public bool AllowOther { get; set; } = true;
        public List<AgentConsoleChoiceView> Choices { get; set; } = new();
        public int Step { get; set; }
        public float Importance { get; set; }
        public double CreatedAt { get; set; }
    }

    private sealed class AgentConsoleTaskView
    {
        public string TaskId { get; set; } = "";
        public string Goal { get; set; } = "";
        public string ClarifiedGoal { get; set; } = "";
        public string Status { get; set; } = "queued";
        public string Executor { get; set; } = "gemini";
        public string Model { get; set; } = "";
        public int CurrentStep { get; set; }
        public int PendingControls { get; set; }
        public string CheckpointId { get; set; } = "";
        public int CheckpointCount { get; set; }
        public int TestsPassed { get; set; }
        public int TestsFailed { get; set; }
        public string TestsSummary { get; set; } = "";
        public List<string> ActiveSkills { get; set; } = new();
        public List<string> ChangedFiles { get; set; } = new();
        public List<AgentConsoleEventView> Events { get; set; } = new();
        public double CreatedAt { get; set; }
        public double StartedAt { get; set; }
        public double FinishedAt { get; set; }
        public double UpdatedAt { get; set; }
        public string Source { get; set; } = "";
        public string TaskMode { get; set; } = "execute";
        public string WorkspaceId { get; set; } = "";
        public string WorkspacePath { get; set; } = "";
        public string WorkspaceName { get; set; } = "";
    }
    private sealed class AgentWorkspaceView
    {
        public string WorkspaceId { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public string Path { get; set; } = "";
        public string SourceType { get; set; } = "";
        public string Branch { get; set; } = "";
        public bool Favorite { get; set; }
        public bool Active { get; set; }
        public double LastOpenedAt { get; set; }
    }


    // V3: visual pass bám mockup đã chốt. Agent Console giờ là execution UI thật,
    // không còn cảm giác admin dashboard pastel vô hồn.
    private static readonly Vector2 AgentConsolePreferredSize = new(1260f, 760f);
    private static readonly Vector2 AgentConsoleMinimumSize = new(860f, 560f);
    private const float AgentConsoleViewportPaddingX = 34f;
    private const float AgentConsoleViewportPaddingY = 36f;
    private static readonly Color AgentConsoleBg = new(0.035f, 0.047f, 0.052f, 0.995f);
    private static readonly Color AgentConsoleCard = new(0.060f, 0.078f, 0.086f, 0.985f);
    private static readonly Color AgentConsoleSoft = new(0.074f, 0.094f, 0.102f, 0.94f);
    private static readonly Color AgentConsoleBorder = new(0.175f, 0.215f, 0.225f, 0.90f);
    private static readonly Color AgentConsoleInk = new(0.925f, 0.950f, 0.935f, 1f);
    private static readonly Color AgentConsoleMuted = new(0.610f, 0.660f, 0.625f, 1f);
    private static readonly Color AgentConsoleFaint = new(0.390f, 0.445f, 0.415f, 1f);
    private static readonly Color AgentConsolePink = new(0.36f, 0.76f, 0.51f, 1f);
    private static readonly Color AgentConsoleGreen = new(0.36f, 0.78f, 0.52f, 1f);
    private static readonly Color AgentConsoleGold = new(0.86f, 0.69f, 0.34f, 1f);
    private static readonly Color AgentConsoleBlue = new(0.45f, 0.64f, 0.92f, 1f);
    private static readonly Color AgentConsoleRed = new(0.95f, 0.32f, 0.42f, 1f);
    private static readonly Color AgentConsoleSidebarBg = new(0.043f, 0.057f, 0.063f, 0.995f);
    private static readonly Color AgentConsoleSidebarAccent = new(0.36f, 0.78f, 0.52f, 1f);

    private Button _contextAgentConsoleButton;
    private Panel _agentConsolePanel;
    private Label _agentConsoleStatusLabel;
    private Label _agentConsoleExecutorLabel;
    private Label _agentConsoleTaskTitleLabel;
    private Label _agentConsoleTaskMetaLabel;
    private PanelContainer _agentConsoleTaskDrawer;
    private PanelContainer _agentConsoleInspectorDrawer;
    private VBoxContainer _agentConsoleTaskList;
    private VBoxContainer _agentConsoleEventList;
    private ScrollContainer _agentConsoleEventScroll;
    private Label _agentConsoleStepLabel;
    private Button _agentConsoleInspectorToggleButton;
    private Button _agentConsoleFilterAllButton;
    private Button _agentConsoleFilterConversationButton;
    private Button _agentConsoleFilterToolsButton;
    private Button _agentConsoleFollowButton;
    private Label _agentConsoleInspectorLabel;
    private Label _agentConsoleInspectorDetailLabel;
    private Label _agentConsoleControlStatusLabel;
    private LineEdit _agentConsoleDirectiveInput;
    private Button _agentConsolePauseButton;
    private Button _agentConsoleResumeButton;
    private Button _agentConsoleStopButton;
    private Button _agentConsoleRollbackButton;
    private Button _agentConsoleSendButton;
    private Button _agentConsoleNewTaskButton;
    private Button _agentConsoleWorkspaceToggleButton;
    private Button _agentConsoleStatusToggleButton;
    private Control _agentConsoleWorkspaceStrip;
    private OptionButton _agentConsoleWorkspaceSelect;
    private Button _agentConsoleWorkspaceFavoriteButton;
    private FileDialog _agentConsoleWorkspaceDialog;
    private FileDialog _agentConsoleAttachmentDialog;
    private Button _agentConsoleInspectModeButton;
    private OptionButton _agentConsoleTaskModeSelect;
    private OptionButton _agentConsoleModelSelect;
    private OptionButton _agentConsoleEventKindSelect;
    private LineEdit _agentConsoleEventSearchInput;
    private Button _agentConsoleEventSearchToggle;
    private ProgressBar _agentConsoleProgressBar;
    private Label _agentConsoleProgressMetaLabel;
    private Label _agentConsoleInspectorWorkspaceLabel;
    private Label _agentConsoleInspectorWorkspaceMetaLabel;
    private VBoxContainer _agentConsoleInspectorSkillsList;
    private Button _agentConsoleInspectorOpenWorkspaceButton;
    private static Font _agentConsoleFontRegular;
    private static Font _agentConsoleFontBold;
    private readonly List<AgentConsoleTaskView> _agentConsoleTasks = new();
    private string _agentSelectedTaskId = "";
    private string _agentLastRequestId = "";
    private ulong _agentLastSnapshotRequestMs;
    private ulong _agentLastPacketMs;
    private bool _agentConsoleTaskDrawerVisible;
    private bool _agentConsoleWorkspaceVisible = false;
    private bool _agentConsoleInspectorVisible = false;
    private bool _agentConsoleAutoFollow = true;
    private bool _agentConsoleCreatingTask;
    private string _agentConsoleEventFilter = "all";
    private string _agentConsoleEventKindFilter = "all";
    private readonly List<AgentWorkspaceView> _agentConsoleWorkspaces = new();
    private string _agentConsoleActiveWorkspaceId = "";
    private string _agentConsoleWorkspaceUiSignature = "";
    // Incremental event stream tracking — tránh full rebuild mỗi packet
    private string _agentConsoleStreamTaskId = "";
    private string _agentConsoleStreamFilter = "";
    private string _agentConsoleStreamKind = "";
    private string _agentConsoleStreamSearch = "";
    private int _agentConsoleStreamRenderedCount = 0;
    private string _agentConsoleTaskListSignature = "";

    private void BuildAgentConsoleUi()
    {
        if (_agentConsolePanel != null)
            return;

        _agentConsolePanel = new Panel
        {
            Name = "AgentConsolePanel",
            Visible = false,
            CustomMinimumSize = Vector2.Zero,
            Size = new Vector2(1180f, 760f),
            ZIndex = 100,
            ClipContents = true,
        };
        _agentConsolePanel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            new Color(0.035f, 0.047f, 0.052f, 0.998f),
            new Color(0.20f, 0.25f, 0.23f, 0.96f),
            22,
            1,
            shadow: true));
        ApplyAgentConsoleTheme();
        GetNode<Control>("CanvasLayer/Control").AddChild(_agentConsolePanel);

        var margin = new MarginContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        margin.SetAnchorsPreset(Control.LayoutPreset.FullRect);
        margin.AddThemeConstantOverride("margin_left", 16);
        margin.AddThemeConstantOverride("margin_right", 16);
        margin.AddThemeConstantOverride("margin_top", 14);
        margin.AddThemeConstantOverride("margin_bottom", 14);
        _agentConsolePanel.AddChild(margin);

        var root = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        root.AddThemeConstantOverride("separation", 10);
        margin.AddChild(root);

        // V4 simple-first: chat panel có workspace, không phải dashboard vận hành.
        root.AddChild(BuildAgentConsoleHeader());
        root.AddChild(BuildAgentConsoleBody());
        BuildAgentWorkspaceDialog();
        BuildAgentAttachmentDialog();
        RefreshAgentConsole();
    }

    private Control BuildAgentSidebar()
    {
        var panel = new PanelContainer
        {
            CustomMinimumSize = new Vector2(104f, 0f),
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            AgentConsoleSidebarBg,
            new Color(AgentConsoleSidebarAccent.R, AgentConsoleSidebarAccent.G, AgentConsoleSidebarAccent.B, 0.22f),
            24,
            1,
            shadow: false));

        var margin = AgentConsoleMargin(14, 16, 14, 16);
        panel.AddChild(margin);
        var box = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        box.AddThemeConstantOverride("separation", 18);
        margin.AddChild(box);

        var logoWrap = new CenterContainer { CustomMinimumSize = new Vector2(0f, 56f), MouseFilter = Control.MouseFilterEnum.Ignore };
        var logo = new Label
        {
            Text = "◈",
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            CustomMinimumSize = new Vector2(54f, 54f),
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        logo.AddThemeFontSizeOverride("font_size", 28);
        logo.AddThemeColorOverride("font_color", AgentConsoleSidebarAccent);
        logo.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
            new Color(0.08f, 0.16f, 0.24f, 0.84f),
            new Color(AgentConsoleSidebarAccent.R, AgentConsoleSidebarAccent.G, AgentConsoleSidebarAccent.B, 0.25f),
            18,
            1,
            shadow: true));
        logoWrap.AddChild(logo);
        box.AddChild(logoWrap);

        box.AddChild(BuildAgentSidebarNav("⌘", "Công việc", active: true));
        box.AddChild(BuildAgentSidebarNav("◌", "Phiên"));
        box.AddChild(BuildAgentSidebarNav("▦", "Tools"));
        box.AddChild(BuildAgentSidebarNav("⌁", "Logs"));
        box.AddChild(BuildAgentSidebarNav("⚙", "Cài đặt"));

        box.AddChild(new Control { SizeFlagsVertical = Control.SizeFlags.ExpandFill, MouseFilter = Control.MouseFilterEnum.Ignore });

        var status = new VBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        status.AddThemeConstantOverride("separation", 3);
        status.AddChild(AgentConsoleLabel("● Eris Online", 10, new Color(0.57f, 0.95f, 0.75f, 1f), bold: true));
        status.AddChild(AgentConsoleLabel("v1.9.3", 9, new Color(0.60f, 0.72f, 0.82f, 0.90f)));
        box.AddChild(status);
        return panel;
    }

    private Control BuildAgentSidebarNav(string icon, string text, bool active = false)
    {
        var panel = new PanelContainer
        {
            CustomMinimumSize = new Vector2(0f, 44f),
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            active ? new Color(0.13f, 0.22f, 0.30f, 0.96f) : Colors.Transparent,
            Colors.Transparent,
            12,
            0));

        var margin = AgentConsoleMargin(10, 6, 10, 6);
        panel.AddChild(margin);
        var row = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        row.AddThemeConstantOverride("separation", 8);
        margin.AddChild(row);

        var iconLabel = AgentConsoleLabel(icon, 14, active ? AgentConsoleSidebarAccent : new Color(0.72f, 0.82f, 0.90f, 0.88f), bold: true);
        iconLabel.CustomMinimumSize = new Vector2(18f, 0f);
        row.AddChild(iconLabel);
        var textLabel = AgentConsoleLabel(text, 11, active ? new Color(0.78f, 1f, 0.92f, 1f) : new Color(0.70f, 0.78f, 0.86f, 0.88f), bold: active);
        row.AddChild(textLabel);
        return panel;
    }

    private Control BuildAgentConsoleHeader()
    {
        var row = new HBoxContainer
        {
            CustomMinimumSize = new Vector2(0f, 44f),
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        row.AddThemeConstantOverride("separation", 10);

        var titleBox = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        titleBox.AddThemeConstantOverride("separation", 1);
        titleBox.AddChild(AgentConsoleLabel("Eris Console", 18, AgentConsoleInk, bold: true));

        var metaRow = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        metaRow.AddThemeConstantOverride("separation", 8);
        _agentConsoleStatusLabel = AgentConsoleLabel("● Sẵn sàng", 9, AgentConsoleGreen, bold: true);
        metaRow.AddChild(_agentConsoleStatusLabel);
        _agentConsoleTaskMetaLabel = AgentConsoleLabel("Gemini autopilot", 9, AgentConsoleMuted);
        metaRow.AddChild(_agentConsoleTaskMetaLabel);
        titleBox.AddChild(metaRow);
        row.AddChild(titleBox);

        var close = CreateWindowControlButton("×", CloseAgentConsolePanel, 36f, 17);
        row.AddChild(close);
        return row;
    }

    private Control BuildAgentConsoleBody()
    {
        var body = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        body.AddThemeConstantOverride("separation", 10);

        // IDE-like: sidebar cố định + timeline cố định. Không drawer, không inspector.
        _agentConsoleTaskDrawer = BuildAgentTaskPane();
        _agentConsoleTaskDrawerVisible = true;
        _agentConsoleTaskDrawer.Visible = true;
        body.AddChild(_agentConsoleTaskDrawer);
        body.AddChild(BuildAgentStreamPane());
        return body;
    }

    private PanelContainer BuildAgentTaskPane()
    {
        var panel = new PanelContainer
        {
            CustomMinimumSize = new Vector2(258f, 0f),
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            new Color(0.043f, 0.057f, 0.063f, 0.995f),
            new Color(0.14f, 0.18f, 0.17f, 0.95f),
            16,
            1));

        var margin = AgentConsoleMargin(12, 12, 12, 12);
        panel.AddChild(margin);
        var box = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        box.AddThemeConstantOverride("separation", 8);
        margin.AddChild(box);

        box.AddChild(AgentConsoleLabel("WORKSPACE", 9, AgentConsoleGreen, bold: true));
        _agentConsoleWorkspaceSelect = new OptionButton
        {
            CustomMinimumSize = new Vector2(0f, 38f),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            FocusMode = Control.FocusModeEnum.None,
        };
        StyleAgentConsoleOptionButton(_agentConsoleWorkspaceSelect);
        _agentConsoleWorkspaceSelect.ItemSelected += OnAgentWorkspaceSelected;
        box.AddChild(_agentConsoleWorkspaceSelect);

        var workspaceActions = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        workspaceActions.AddThemeConstantOverride("separation", 6);
        var open = AgentConsoleQuietButton("Mở thư mục", ShowAgentWorkspaceDialog, 116f);
        open.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        workspaceActions.AddChild(open);
        _agentConsoleWorkspaceFavoriteButton = AgentConsoleQuietButton("☆", ToggleAgentWorkspaceFavorite, 40f);
        _agentConsoleWorkspaceFavoriteButton.TooltipText = "Ghim workspace thường dùng";
        workspaceActions.AddChild(_agentConsoleWorkspaceFavoriteButton);
        box.AddChild(workspaceActions);

        var spacer = new HSeparator { MouseFilter = Control.MouseFilterEnum.Ignore };
        spacer.AddThemeConstantOverride("separation", 6);
        box.AddChild(spacer);

        var chatsHeader = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        var chatsTitle = AgentConsoleLabel("LỊCH SỬ CHAT", 9, AgentConsoleGreen, bold: true);
        chatsTitle.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        chatsHeader.AddChild(chatsTitle);
        _agentConsoleNewTaskButton = AgentConsoleQuietButton("＋ Mới", EnterAgentNewTaskMode, 68f);
        _agentConsoleNewTaskButton.CustomMinimumSize = new Vector2(68f, 32f);
        chatsHeader.AddChild(_agentConsoleNewTaskButton);
        box.AddChild(chatsHeader);

        var scroll = new ScrollContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled,
        };
        ApplyHiddenScrollBarTheme(scroll.GetVScrollBar());
        box.AddChild(scroll);
        _agentConsoleTaskList = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        _agentConsoleTaskList.AddThemeConstantOverride("separation", 4);
        scroll.AddChild(_agentConsoleTaskList);

        var profile = new PanelContainer
        {
            CustomMinimumSize = new Vector2(0f, 48f),
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        profile.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            new Color(0.055f, 0.071f, 0.078f, 0.98f),
            new Color(0.14f, 0.18f, 0.17f, 0.92f),
            12,
            1));
        var profileMargin = AgentConsoleMargin(10, 7, 10, 7);
        profile.AddChild(profileMargin);
        var profileRow = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        profileRow.AddThemeConstantOverride("separation", 8);
        profileMargin.AddChild(profileRow);
        var avatar = AgentConsoleLabel("E", 13, AgentConsoleInk, bold: true);
        avatar.CustomMinimumSize = new Vector2(32f, 32f);
        avatar.HorizontalAlignment = HorizontalAlignment.Center;
        avatar.VerticalAlignment = VerticalAlignment.Center;
        avatar.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
            new Color(0.12f, 0.22f, 0.16f, 1f),
            new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.35f),
            16,
            1));
        profileRow.AddChild(avatar);
        var profileText = AgentConsoleLabel("Eris Dev   ●", 10, AgentConsoleInk, bold: true);
        profileText.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        profileText.VerticalAlignment = VerticalAlignment.Center;
        profileRow.AddChild(profileText);
        profileRow.AddChild(AgentConsoleLabel("⌄", 12, AgentConsoleFaint));
        box.AddChild(profile);
        return panel;
    }

    private Control BuildAgentStreamPane()
    {
        var root = new VBoxContainer
        {
            CustomMinimumSize = new Vector2(0f, 0f),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        root.AddThemeConstantOverride("separation", 8);

        var conversationHeader = new HBoxContainer
        {
            CustomMinimumSize = new Vector2(0f, 38f),
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        conversationHeader.AddThemeConstantOverride("separation", 8);
        _agentConsoleTaskTitleLabel = AgentConsoleLabel("Chat mới", 14, AgentConsoleInk, bold: true);
        _agentConsoleTaskTitleLabel.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        _agentConsoleTaskTitleLabel.TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis;
        _agentConsoleTaskTitleLabel.ClipText = true;
        conversationHeader.AddChild(_agentConsoleTaskTitleLabel);
        _agentConsoleStepLabel = AgentConsoleLabel("Sẵn sàng", 9, AgentConsoleMuted);
        _agentConsoleStepLabel.VerticalAlignment = VerticalAlignment.Center;
        conversationHeader.AddChild(_agentConsoleStepLabel);
        root.AddChild(conversationHeader);

        var streamSurface = new PanelContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        streamSurface.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            new Color(0.032f, 0.043f, 0.048f, 0.98f),
            new Color(0.12f, 0.16f, 0.15f, 0.92f),
            16,
            1));
        var streamMargin = AgentConsoleMargin(14, 12, 14, 12);
        streamSurface.AddChild(streamMargin);
        var streamBox = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        streamMargin.AddChild(streamBox);
        _agentConsoleEventScroll = new ScrollContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled,
        };
        ApplyHiddenScrollBarTheme(_agentConsoleEventScroll.GetVScrollBar());
        streamBox.AddChild(_agentConsoleEventScroll);
        _agentConsoleEventList = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            CustomMinimumSize = new Vector2(0f, 360f),
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        _agentConsoleEventList.AddThemeConstantOverride("separation", 8);
        _agentConsoleEventScroll.AddChild(_agentConsoleEventList);
        root.AddChild(streamSurface);
        root.AddChild(BuildAgentConsoleFooter());
        return root;
    }

    private Control BuildAgentWorkspaceStrip()
    {
        var panel = new PanelContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            Colors.White,
            new Color(0.88f, 0.91f, 0.96f, 0.95f),
            18,
            1,
            shadow: true));
        var margin = AgentConsoleMargin(14, 8, 14, 8);
        panel.AddChild(margin);
        var row = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        row.AddThemeConstantOverride("separation", 8);
        margin.AddChild(row);

        var label = AgentConsoleLabel("Workspace", 10, AgentConsoleMuted, bold: true);
        label.CustomMinimumSize = new Vector2(76f, 0f);
        row.AddChild(label);

        _agentConsoleWorkspaceSelect = new OptionButton
        {
            CustomMinimumSize = new Vector2(300f, 38f),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            FocusMode = Control.FocusModeEnum.None,
        };
        StyleAgentConsoleOptionButton(_agentConsoleWorkspaceSelect);
        _agentConsoleWorkspaceSelect.ItemSelected += OnAgentWorkspaceSelected;
        row.AddChild(_agentConsoleWorkspaceSelect);

        _agentConsoleWorkspaceFavoriteButton = AgentConsoleQuietButton("☆  Ghim", ToggleAgentWorkspaceFavorite, 82f);
        _agentConsoleWorkspaceFavoriteButton.TooltipText = "Ghim workspace thường dùng";
        row.AddChild(_agentConsoleWorkspaceFavoriteButton);

        var open = AgentConsoleQuietButton("＋  Mở", ShowAgentWorkspaceDialog, 76f);
        open.TooltipText = "Mở workspace khác";
        row.AddChild(open);

        var collapse = AgentConsoleQuietButton("⌃", ToggleAgentWorkspaceStrip, 40f);
        collapse.TooltipText = "Thu gọn workspace";
        row.AddChild(collapse);
        return panel;
    }

    private Control AgentConsoleToolChip(string text, Color accent)
    {
        var button = AgentConsoleQuietButton(text, null, 36f);
        button.CustomMinimumSize = new Vector2(36f, 32f);
        button.AddThemeFontSizeOverride("font_size", 10);
        button.AddThemeColorOverride("font_color", accent);
        return button;
    }

    private TextureRect AgentConsoleAssetImage(string fileName, Vector2 size, TextureRect.StretchModeEnum stretchMode)
    {
        string path = ResolveIdentityAssetPath(IdentityAsset(fileName));
        if (!ResourceLoader.Exists(path))
            return null;
        return new TextureRect
        {
            Texture = GD.Load<Texture2D>(path),
            CustomMinimumSize = size,
            Size = size,
            ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
            StretchMode = stretchMode,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
    }

    private void ApplyAgentConsoleTheme()
    {
        var theme = _agentConsolePanel.Theme ?? new Theme();
        theme.DefaultFont = AgentConsoleFont(false);
        _agentConsolePanel.Theme = theme;
    }

    private static Font AgentConsoleFont(bool bold)
    {
        if (bold)
        {
            _agentConsoleFontBold ??= new SystemFont
            {
                FontNames = new[] { "Segoe UI Semibold", "Segoe UI", "Inter", "Arial" },
                FontWeight = 650,
            };
            return _agentConsoleFontBold;
        }

        _agentConsoleFontRegular ??= new SystemFont
        {
            FontNames = new[] { "Segoe UI", "Inter", "Arial" },
            FontWeight = 400,
        };
        return _agentConsoleFontRegular;
    }

    private Control BuildAgentQuickSummary()
    {
        var panel = new PanelContainer
        {
            CustomMinimumSize = new Vector2(0f, 40f),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            new Color(0.985f, 0.990f, 0.998f, 0.96f),
            new Color(0.88f, 0.91f, 0.96f, 0.75f),
            14,
            1));
        var margin = AgentConsoleMargin(14, 6, 14, 6);
        panel.AddChild(margin);
        _agentConsoleStepLabel = AgentConsoleLabel("Chưa có task · Autopilot sẵn sàng", 11, AgentConsoleMuted);
        _agentConsoleStepLabel.VerticalAlignment = VerticalAlignment.Center;
        _agentConsoleStepLabel.TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis;
        _agentConsoleStepLabel.ClipText = true;
        margin.AddChild(_agentConsoleStepLabel);
        return panel;
    }

    private Control BuildAgentFilterBar()
    {
        var root = new VBoxContainer
        {
            CustomMinimumSize = new Vector2(0f, 44f),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        root.AddThemeConstantOverride("separation", 6);

        var row = new HBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, MouseFilter = Control.MouseFilterEnum.Ignore };
        row.AddThemeConstantOverride("separation", 8);
        _agentConsoleFilterAllButton = AgentConsoleFilterButton("◈  Timeline", "all");
        _agentConsoleFilterConversationButton = AgentConsoleFilterButton("◌  Hội thoại", "conversation");
        _agentConsoleFilterToolsButton = AgentConsoleFilterButton("⚒  Công cụ", "tools");
        row.AddChild(_agentConsoleFilterAllButton);
        row.AddChild(_agentConsoleFilterConversationButton);
        row.AddChild(_agentConsoleFilterToolsButton);
        row.AddChild(new Control { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, MouseFilter = Control.MouseFilterEnum.Ignore });

        _agentConsoleEventKindSelect = new OptionButton { CustomMinimumSize = new Vector2(148f, 36f), FocusMode = Control.FocusModeEnum.None, Visible = false };
        StyleAgentConsoleOptionButton(_agentConsoleEventKindSelect);
        _agentConsoleEventKindSelect.AddItem("Tất cả sự kiện");
        _agentConsoleEventKindSelect.AddItem("Quan trọng");
        _agentConsoleEventKindSelect.AddItem("Lỗi / cảnh báo");
        _agentConsoleEventKindSelect.AddItem("Thay đổi file");
        _agentConsoleEventKindSelect.AddItem("Tests");
        _agentConsoleEventKindSelect.ItemSelected += OnAgentEventKindSelected;
        row.AddChild(_agentConsoleEventKindSelect);

        _agentConsoleEventSearchToggle = AgentConsoleQuietButton("⌕  Lọc", ToggleAgentEventSearch, 68f);
        row.AddChild(_agentConsoleEventSearchToggle);
        _agentConsoleFollowButton = AgentConsoleQuietButton("⇅", ToggleAgentAutoFollow, 42f);
        _agentConsoleFollowButton.TooltipText = "Theo dõi event mới";
        row.AddChild(_agentConsoleFollowButton);
        root.AddChild(row);

        _agentConsoleEventSearchInput = new LineEdit
        {
            PlaceholderText = "Tìm trong timeline: tool, file, lỗi, checkpoint...",
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            Visible = false,
            ClearButtonEnabled = true,
        };
        StyleAgentConsoleInput(_agentConsoleEventSearchInput);
        _agentConsoleEventSearchInput.CustomMinimumSize = new Vector2(0f, 36f);
        _agentConsoleEventSearchInput.TextChanged += _ => RebuildAgentEventStream();
        root.AddChild(_agentConsoleEventSearchInput);

        RefreshAgentFilterButtons();
        return root;
    }

    private PanelContainer BuildAgentInspectorPane()
    {
        var panel = new PanelContainer
        {
            CustomMinimumSize = new Vector2(340f, 0f),
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            Colors.White,
            new Color(0.88f, 0.91f, 0.96f, 0.95f),
            22,
            1,
            shadow: true));
        var margin = AgentConsoleMargin(18, 16, 18, 16);
        panel.AddChild(margin);
        var box = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        box.AddThemeConstantOverride("separation", 12);
        margin.AddChild(box);

        var top = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        var title = AgentConsoleLabel("Phiên làm việc", 18, AgentConsoleInk, bold: true);
        title.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        top.AddChild(title);
        top.AddChild(AgentConsoleLabel("NÂNG CAO", 9, AgentConsoleFaint, bold: true));
        top.AddChild(AgentConsoleQuietButton("⌃", ToggleAgentInspector, 34f));
        box.AddChild(top);

        box.AddChild(AgentConsoleLabel("Tiến trình tổng quan", 13, AgentConsoleInk, bold: true));
        _agentConsoleProgressBar = new ProgressBar
        {
            MinValue = 0,
            MaxValue = 100,
            Value = 0,
            ShowPercentage = false,
            CustomMinimumSize = new Vector2(0f, 10f),
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        _agentConsoleProgressBar.AddThemeStyleboxOverride("background", AgentConsoleStyle(new Color(0.93f,0.95f,0.98f,1f), Colors.Transparent, 5, 0));
        _agentConsoleProgressBar.AddThemeStyleboxOverride("fill", AgentConsoleStyle(new Color(0.65f,0.76f,1f,1f), Colors.Transparent, 5, 0));
        box.AddChild(_agentConsoleProgressBar);
        _agentConsoleProgressMetaLabel = AgentConsoleLabel("Chưa có task đang chạy.", 11, AgentConsoleMuted);
        _agentConsoleProgressMetaLabel.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        box.AddChild(_agentConsoleProgressMetaLabel);

        _agentConsoleRollbackButton = AgentConsoleQuietButton("⟲  Rollback checkpoint", () => SendAgentControl("rollback", checkpointId: SelectedAgentTask()?.CheckpointId ?? ""), 176f);
        _agentConsoleRollbackButton.TooltipText = "Khôi phục checkpoint gần nhất của task";
        box.AddChild(_agentConsoleRollbackButton);

        var detailScroll = new ScrollContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled,
            VerticalScrollMode = ScrollContainer.ScrollMode.Auto,
            ClipContents = true,
            MouseFilter = Control.MouseFilterEnum.Stop,
        };
        ApplyHiddenScrollBarTheme(detailScroll.GetVScrollBar());
        box.AddChild(detailScroll);

        var detailBox = new VBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, MouseFilter = Control.MouseFilterEnum.Ignore };
        detailBox.AddThemeConstantOverride("separation", 14);
        detailScroll.AddChild(detailBox);

        var workspaceSection = new VBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        workspaceSection.AddThemeConstantOverride("separation", 6);
        var workspaceTop = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        var workspaceTitle = AgentConsoleLabel("Workspace", 16, AgentConsoleInk, bold: true);
        workspaceTitle.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        workspaceTop.AddChild(workspaceTitle);
        _agentConsoleInspectorOpenWorkspaceButton = AgentConsoleQuietButton("Mở thư mục", OpenSelectedTaskWorkspace, 98f);
        workspaceTop.AddChild(_agentConsoleInspectorOpenWorkspaceButton);
        workspaceSection.AddChild(workspaceTop);
        _agentConsoleInspectorWorkspaceLabel = AgentConsoleLabel("Chưa khóa workspace", 13, AgentConsoleInk, bold: true);
        workspaceSection.AddChild(_agentConsoleInspectorWorkspaceLabel);
        _agentConsoleInspectorWorkspaceMetaLabel = AgentConsoleLabel("—", 11, AgentConsoleMuted);
        _agentConsoleInspectorWorkspaceMetaLabel.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        workspaceSection.AddChild(_agentConsoleInspectorWorkspaceMetaLabel);
        detailBox.AddChild(workspaceSection);

        var taskSection = new VBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        taskSection.AddThemeConstantOverride("separation", 6);
        taskSection.AddChild(AgentConsoleLabel("Thông tin task", 16, AgentConsoleInk, bold: true));
        _agentConsoleInspectorLabel = AgentConsoleLabel("Chưa chọn task", 12, AgentConsoleMuted);
        _agentConsoleInspectorLabel.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        taskSection.AddChild(_agentConsoleInspectorLabel);
        _agentConsoleInspectorDetailLabel = AgentConsoleLabel("—", 11, AgentConsoleMuted);
        _agentConsoleInspectorDetailLabel.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        taskSection.AddChild(_agentConsoleInspectorDetailLabel);
        detailBox.AddChild(taskSection);

        var toolSection = new VBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        toolSection.AddThemeConstantOverride("separation", 8);
        toolSection.AddChild(AgentConsoleLabel("Kỹ năng & Công cụ", 16, AgentConsoleInk, bold: true));
        _agentConsoleInspectorSkillsList = new VBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        _agentConsoleInspectorSkillsList.AddThemeConstantOverride("separation", 6);
        toolSection.AddChild(_agentConsoleInspectorSkillsList);
        detailBox.AddChild(toolSection);
        return panel;
    }

    private Control BuildAgentConsoleFooter()
    {
        var box = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        box.AddThemeConstantOverride("separation", 3);

        var panel = new PanelContainer
        {
            CustomMinimumSize = new Vector2(0f, 56f),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            new Color(0.064f, 0.082f, 0.090f, 0.99f),
            new Color(0.21f, 0.27f, 0.25f, 0.95f),
            16,
            1));
        var margin = AgentConsoleMargin(8, 6, 8, 6);
        panel.AddChild(margin);

        var row = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        row.AddThemeConstantOverride("separation", 6);
        margin.AddChild(row);

        var attach = AgentConsoleQuietButton("＋", ShowAgentAttachmentDialog, 38f);
        attach.TooltipText = "Đính kèm đường dẫn file vào tin nhắn";
        attach.CustomMinimumSize = new Vector2(38f, 44f);
        row.AddChild(attach);

        var mention = AgentConsoleQuietButton("@", () =>
        {
            AgentWorkspaceView workspace = ActiveAgentWorkspace();
            InsertAgentComposerText(workspace == null ? "@workspace " : $"@workspace `{workspace.Path}` ");
        }, 38f);
        mention.TooltipText = "Chèn workspace hiện tại";
        mention.CustomMinimumSize = new Vector2(38f, 44f);
        row.AddChild(mention);

        _agentConsoleInspectModeButton = AgentConsoleQuietButton("✦", ToggleAgentComposerInspectMode, 38f);
        _agentConsoleInspectModeButton.TooltipText = "Đổi Execute / Inspect";
        _agentConsoleInspectModeButton.CustomMinimumSize = new Vector2(38f, 44f);
        row.AddChild(_agentConsoleInspectModeButton);

        _agentConsoleDirectiveInput = new LineEdit
        {
            PlaceholderText = "Nhập tin nhắn của bạn...",
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            ClearButtonEnabled = true,
        };
        StyleAgentConsoleInput(_agentConsoleDirectiveInput);
        _agentConsoleDirectiveInput.TextSubmitted += _ => SubmitAgentComposer();
        row.AddChild(_agentConsoleDirectiveInput);

        _agentConsoleSendButton = AgentConsoleButton("Gửi", SubmitAgentComposer, primary: true);
        _agentConsoleSendButton.CustomMinimumSize = new Vector2(76f, 44f);
        row.AddChild(_agentConsoleSendButton);

        // Chỉ giữ nút dừng khi thực sự có task đang chạy.
        _agentConsolePauseButton = AgentConsoleQuietButton("Ⅱ", () => SendAgentControl("pause"), 40f);
        _agentConsolePauseButton.Visible = false;
        _agentConsoleResumeButton = AgentConsoleQuietButton("▶", () => SendAgentControl("resume"), 40f);
        _agentConsoleResumeButton.Visible = false;
        _agentConsoleStopButton = AgentConsoleQuietButton("■", () => SendAgentControl("stop"), 40f, danger: true);
        _agentConsoleStopButton.TooltipText = "Dừng task đang chạy";
        row.AddChild(_agentConsoleStopButton);

        // Giữ protocol cũ nhưng không bắt người dùng chọn mode/model cho mỗi chat.
        _agentConsoleTaskModeSelect = new OptionButton { Visible = false, FocusMode = Control.FocusModeEnum.None };
        _agentConsoleTaskModeSelect.AddItem("Execute");
        _agentConsoleTaskModeSelect.AddItem("Inspect");
        box.AddChild(_agentConsoleTaskModeSelect);

        _agentConsoleModelSelect = new OptionButton { Visible = false, FocusMode = Control.FocusModeEnum.None };
        _agentConsoleModelSelect.AddItem("gemini-3-pro", 0);
        _agentConsoleModelSelect.AddItem("gemini-3-flash", 1);
        _agentConsoleModelSelect.AddItem("gemini-3-flash-thinking", 2);
        _agentConsoleModelSelect.Select(0); // webapi backend default
        box.AddChild(_agentConsoleModelSelect);

        _agentConsoleControlStatusLabel = AgentConsoleLabel("Eris có thể mắc sai sót. Hãy kiểm tra các thay đổi quan trọng.", 9, AgentConsoleFaint);
        _agentConsoleControlStatusLabel.TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis;
        _agentConsoleControlStatusLabel.ClipText = true;
        _agentConsoleControlStatusLabel.HorizontalAlignment = HorizontalAlignment.Center;
        box.AddChild(panel);
        box.AddChild(_agentConsoleControlStatusLabel);
        return box;
    }

    private void ToggleAgentTaskDrawer()
    {
        _agentConsoleTaskDrawerVisible = !_agentConsoleTaskDrawerVisible;
        if (_agentConsoleTaskDrawer != null)
            _agentConsoleTaskDrawer.Visible = _agentConsoleTaskDrawerVisible;
        if (_agentConsoleStatusToggleButton != null)
        {
            _agentConsoleStatusToggleButton.Text = _agentConsoleTaskDrawerVisible ? "×" : "☷";
            _agentConsoleStatusToggleButton.TooltipText = _agentConsoleTaskDrawerVisible ? "Đóng danh sách task" : "Task gần đây";
        }
    }

    private void ToggleAgentInspector()
    {
        _agentConsoleInspectorVisible = !_agentConsoleInspectorVisible;
        if (_agentConsoleInspectorDrawer != null)
            _agentConsoleInspectorDrawer.Visible = _agentConsoleInspectorVisible;
        if (_agentConsoleInspectorToggleButton != null)
        {
            _agentConsoleInspectorToggleButton.Text = _agentConsoleInspectorVisible ? "×" : "⋯";
            _agentConsoleInspectorToggleButton.TooltipText = _agentConsoleInspectorVisible ? "Đóng chi tiết" : "Chi tiết và tùy chọn nâng cao";
        }
    }

    private void ToggleAgentAutoFollow()
    {
        _agentConsoleAutoFollow = !_agentConsoleAutoFollow;
        if (_agentConsoleFollowButton != null)
            _agentConsoleFollowButton.Text = _agentConsoleAutoFollow ? "Theo dõi ●" : "Theo dõi ○";
        if (_agentConsoleAutoFollow)
            CallDeferred(nameof(ScrollAgentConsoleToBottom));
    }

    private Button AgentConsoleFilterButton(string text, string filter)
    {
        string captured = filter;
        var button = AgentConsoleQuietButton(text, () =>
        {
            _agentConsoleEventFilter = captured;
            RefreshAgentFilterButtons();
            RebuildAgentEventStream();
            if (_agentConsoleAutoFollow)
                CallDeferred(nameof(ScrollAgentConsoleToBottom));
        }, text == "Hội thoại" ? 76f : 62f);
        return button;
    }

    private void RefreshAgentFilterButtons()
    {
        StyleAgentFilterButton(_agentConsoleFilterAllButton, _agentConsoleEventFilter == "all");
        StyleAgentFilterButton(_agentConsoleFilterConversationButton, _agentConsoleEventFilter == "conversation");
        StyleAgentFilterButton(_agentConsoleFilterToolsButton, _agentConsoleEventFilter == "tools");
    }

    private static void StyleAgentFilterButton(Button button, bool active)
    {
        if (button == null)
            return;
        button.AddThemeColorOverride("font_color", active ? AgentConsolePink : AgentConsoleMuted);
        button.AddThemeColorOverride("font_hover_color", active ? AgentConsolePink : AgentConsoleInk);
        button.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
            Colors.Transparent,
            Colors.Transparent,
            8,
            0));
        button.AddThemeStyleboxOverride("hover", AgentConsoleStyle(
            new Color(0.98f,0.985f,0.995f,1f),
            Colors.Transparent,
            8,
            0));
    }

    private static bool AgentEventMatchesFilter(AgentConsoleEventView ev, string filter)
    {
        if (ev == null || string.IsNullOrWhiteSpace(filter) || filter == "all")
            return true;
        string actor = (ev.Actor ?? "").Trim().ToLowerInvariant();
        string type = (ev.Type ?? "").Trim().ToLowerInvariant();
        if (filter == "conversation")
            return actor is "eris" or "executor" or "gemini" or "user"
                || type.StartsWith("supervisor_", StringComparison.Ordinal)
                || type is "agent_summary" or "agent_plan" or "clarification_requested" or "user_directive" or "user_choice";
        if (filter == "tools")
            return actor == "tool"
                || type.StartsWith("tool_", StringComparison.Ordinal)
                || type.StartsWith("skill_", StringComparison.Ordinal)
                || type.StartsWith("checkpoint_", StringComparison.Ordinal)
                || type.Contains("test", StringComparison.Ordinal)
                || type.Contains("file", StringComparison.Ordinal)
                || type.StartsWith("permission_", StringComparison.Ordinal);
        return true;
    }

    private static bool AgentEventMatchesKind(AgentConsoleEventView ev, string kind)
    {
        if (ev == null || string.IsNullOrWhiteSpace(kind) || kind == "all")
            return true;
        string type = (ev.Type ?? "").Trim().ToLowerInvariant();
        if (kind == "important")
            return ev.Importance >= 0.75f;
        if (kind == "errors")
            return type.Contains("fail", StringComparison.Ordinal)
                || type.Contains("error", StringComparison.Ordinal)
                || type.Contains("veto", StringComparison.Ordinal)
                || type.Contains("permission", StringComparison.Ordinal)
                || ev.Importance >= 0.90f;
        if (kind == "files")
            return type.Contains("file", StringComparison.Ordinal)
                || type.Contains("diff", StringComparison.Ordinal)
                || type.Contains("patch", StringComparison.Ordinal);
        if (kind == "tests")
            return type.Contains("test", StringComparison.Ordinal);
        return true;
    }

    private static bool AgentEventMatchesSearch(AgentConsoleEventView ev, string query)
    {
        string needle = (query ?? "").Trim();
        if (ev == null || string.IsNullOrWhiteSpace(needle))
            return true;
        string haystack = string.Join("\n", new[] { ev.Type, ev.Actor, ev.Summary, ev.Detail, ev.DataText });
        return haystack.IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0;
    }

    private void OnContextAgentConsolePressed()
    {
        _bodyAutonomy?.RecordUserInteraction();
        CloseCharacterContextMenu();
        if (_agentConsolePanel == null)
            return;
        if (_agentConsolePanel.Visible)
            CloseAgentConsolePanel();
        else
            ShowAgentConsolePanel();
    }

    private void ShowAgentConsolePanel()
    {
        if (_agentConsolePanel == null)
            return;
        Vector2 viewport = GetViewportRect().Size;
        float availableWidth = Mathf.Max(520f, viewport.X - AgentConsoleViewportPaddingX * 2f);
        float availableHeight = Mathf.Max(440f, viewport.Y - AgentConsoleViewportPaddingY * 2f);
        Vector2 target = new(
            Mathf.Min(AgentConsolePreferredSize.X, availableWidth),
            Mathf.Min(AgentConsolePreferredSize.Y, availableHeight));
        if (availableWidth >= AgentConsoleMinimumSize.X)
            target.X = Mathf.Max(target.X, AgentConsoleMinimumSize.X);
        if (availableHeight >= AgentConsoleMinimumSize.Y)
            target.Y = Mathf.Max(target.Y, AgentConsoleMinimumSize.Y);
        _agentConsolePanel.Size = target;
        _agentConsolePanel.Position = new Vector2(
            Mathf.Max(AgentConsoleViewportPaddingX, (viewport.X - target.X) * 0.5f),
            Mathf.Max(AgentConsoleViewportPaddingY, (viewport.Y - target.Y) * 0.5f));
        _agentConsolePanel.Visible = true;
        _agentConsolePanel.MoveToFront();
        RefreshAgentConsole();
        SendAgentControl("snapshot");
        UpdateMousePassthrough();
    }

    private void CloseAgentConsolePanel()
    {
        if (_agentConsolePanel == null)
            return;
        if (_draggingPanel == _agentConsolePanel)
            _draggingPanel = null;
        _agentConsolePanel.Visible = false;
        UpdateMousePassthrough();
    }

    private void TickAgentConsole()
    {
        if (_agentConsolePanel == null || !_agentConsolePanel.Visible)
            return;
        ulong now = Time.GetTicksMsec();
        if (now - _agentLastSnapshotRequestMs >= 2200)
            SendAgentControl("snapshot", quiet: true);

        // Nếu Brain không phản hồi, nói thẳng là stale thay vì giả trạng thái "running".
        if (_agentLastPacketMs > 0 && now - _agentLastPacketMs > 9000 && _agentConsoleControlStatusLabel != null)
        {
            _agentConsoleControlStatusLabel.Text = "Agent stream chưa có packet mới trong 9 giây.";
            _agentConsoleControlStatusLabel.AddThemeColorOverride("font_color", AgentConsoleGold);
        }
    }

    private void BuildAgentWorkspaceDialog()
    {
        if (_agentConsoleWorkspaceDialog != null || _agentConsolePanel == null)
            return;
        _agentConsoleWorkspaceDialog = new FileDialog
        {
            Title = "Chọn workspace cho Eris",
            Access = FileDialog.AccessEnum.Filesystem,
            FileMode = FileDialog.FileModeEnum.OpenDir,
            Size = new Vector2I(860, 600),
        };
        _agentConsoleWorkspaceDialog.DirSelected += path =>
        {
            string selected = (path ?? "").Trim();
            if (!string.IsNullOrWhiteSpace(selected))
                SendAgentControl("workspace_open", workspaceRef: selected);
        };
        _agentConsolePanel.AddChild(_agentConsoleWorkspaceDialog);
    }

    private void ShowAgentWorkspaceDialog()
    {
        BuildAgentWorkspaceDialog();
        _agentConsoleWorkspaceDialog?.PopupCentered(new Vector2I(860, 600));
    }

    private void BuildAgentAttachmentDialog()
    {
        if (_agentConsoleAttachmentDialog != null || _agentConsolePanel == null)
            return;
        _agentConsoleAttachmentDialog = new FileDialog
        {
            Title = "Chèn file vào tin nhắn",
            Access = FileDialog.AccessEnum.Filesystem,
            FileMode = FileDialog.FileModeEnum.OpenFile,
            Size = new Vector2I(860, 600),
        };
        _agentConsoleAttachmentDialog.FileSelected += path =>
        {
            string selected = (path ?? "").Trim();
            if (!string.IsNullOrWhiteSpace(selected))
                InsertAgentComposerText($"`{selected}` ");
        };
        _agentConsolePanel.AddChild(_agentConsoleAttachmentDialog);
    }

    private void ShowAgentAttachmentDialog()
    {
        BuildAgentAttachmentDialog();
        _agentConsoleAttachmentDialog?.PopupCentered(new Vector2I(860, 600));
    }

    private void InsertAgentComposerText(string text)
    {
        if (_agentConsoleDirectiveInput == null || string.IsNullOrEmpty(text))
            return;
        string prefix = string.IsNullOrWhiteSpace(_agentConsoleDirectiveInput.Text) ? "" : " ";
        _agentConsoleDirectiveInput.Text += prefix + text;
        _agentConsoleDirectiveInput.CaretColumn = _agentConsoleDirectiveInput.Text.Length;
        _agentConsoleDirectiveInput.GrabFocus();
    }

    private void ToggleAgentComposerInspectMode()
    {
        if (_agentConsoleTaskModeSelect == null)
            return;
        _agentConsoleTaskModeSelect.Selected = _agentConsoleTaskModeSelect.Selected == 1 ? 0 : 1;
        bool inspect = _agentConsoleTaskModeSelect.Selected == 1;
        if (_agentConsoleInspectModeButton != null)
        {
            _agentConsoleInspectModeButton.Text = inspect ? "✦ I" : "✦";
            _agentConsoleInspectModeButton.TooltipText = inspect
                ? "Inspect mode: chỉ đọc/đánh giá, không sửa file"
                : "Execute mode: Gemini được phép sửa/test trong policy";
        }
        SetAgentConsoleControlStatus(inspect
            ? "Chat mới sẽ chạy Inspect mode."
            : "Chat mới sẽ chạy Execute mode.");
    }

    private void ToggleAgentWorkspaceStrip()
    {
        _agentConsoleWorkspaceVisible = !_agentConsoleWorkspaceVisible;
        if (_agentConsoleWorkspaceStrip != null)
            _agentConsoleWorkspaceStrip.Visible = _agentConsoleWorkspaceVisible;
        RefreshAgentWorkspaceButton();
    }

    private void EnterAgentNewTaskMode()
    {
        _agentConsoleCreatingTask = true;
        _agentSelectedTaskId = "";
        if (_agentConsoleDirectiveInput != null)
        {
            _agentConsoleDirectiveInput.Editable = true;
            _agentConsoleDirectiveInput.Text = "";
            _agentConsoleDirectiveInput.PlaceholderText = "Giao task mới cho Gemini...";
            _agentConsoleDirectiveInput.GrabFocus();
        }
        if (_agentConsoleTaskTitleLabel != null)
            _agentConsoleTaskTitleLabel.Text = "Chat mới";
        SetAgentConsoleControlStatus(ActiveAgentWorkspace() == null
            ? "Chọn workspace ở cột trái trước khi giao task cần sửa file."
            : $"Task mới sẽ dùng workspace {ActiveAgentWorkspace().DisplayName}.");
        RefreshAgentConsole();
    }

    private void ExitAgentNewTaskMode()
    {
        _agentConsoleCreatingTask = false;
        if (_agentConsoleDirectiveInput != null)
            _agentConsoleDirectiveInput.PlaceholderText = "Nhập tin nhắn của bạn...";
        RefreshAgentConsoleControls();
    }

    private void SubmitAgentComposer()
    {
        string text = (_agentConsoleDirectiveInput?.Text ?? "").Trim();
        if (string.IsNullOrWhiteSpace(text))
        {
            SetAgentConsoleControlStatus("Tin nhắn đang trống.", error: true);
            return;
        }

        AgentConsoleTaskView selected = SelectedAgentTask();
        bool startNewChat = _agentConsoleCreatingTask || selected == null || AgentTaskTerminal(selected.Status);
        if (startNewChat)
        {
            string mode = (_agentConsoleTaskModeSelect?.Selected ?? 0) == 1 ? "inspect" : "execute";
            // webapi backend: dùng model name không có prefix playwright/
            string model = "gemini-3-pro";
            if (_agentConsoleModelSelect != null)
                model = _agentConsoleModelSelect.GetItemText(_agentConsoleModelSelect.Selected);

            SendAgentControl(
                "create_task",
                text: text,
                workspaceRef: _agentConsoleActiveWorkspaceId,
                taskMode: mode,
                model: model);
            if (_agentConsoleDirectiveInput != null)
                _agentConsoleDirectiveInput.Text = "";
            ExitAgentNewTaskMode();
            return;
        }

        SendAgentDirective();
    }

    private void OnAgentWorkspaceSelected(long index)
    {
        int selected = (int)index;
        if (selected < 0 || selected >= _agentConsoleWorkspaces.Count)
            return;
        AgentWorkspaceView workspace = _agentConsoleWorkspaces[selected];
        if (!string.IsNullOrWhiteSpace(workspace.WorkspaceId)
            && !string.Equals(workspace.WorkspaceId, _agentConsoleActiveWorkspaceId, StringComparison.Ordinal))
            SendAgentControl("workspace_switch", workspaceRef: workspace.WorkspaceId);
    }

    private void ToggleAgentWorkspaceFavorite()
    {
        AgentWorkspaceView active = ActiveAgentWorkspace();
        if (active == null)
        {
            SetAgentConsoleControlStatus("Chưa có workspace để lưu.", error: true);
            return;
        }
        SendAgentControl(active.Favorite ? "workspace_unfavorite" : "workspace_favorite", workspaceRef: active.WorkspaceId);
    }

    private AgentWorkspaceView ActiveAgentWorkspace()
    {
        foreach (AgentWorkspaceView item in _agentConsoleWorkspaces)
            if (string.Equals(item.WorkspaceId, _agentConsoleActiveWorkspaceId, StringComparison.Ordinal))
                return item;
        return null;
    }

    private void OpenSelectedTaskWorkspace()
    {
        AgentConsoleTaskView task = SelectedAgentTask();
        string path = task?.WorkspacePath ?? "";
        if (string.IsNullOrWhiteSpace(path))
            path = ActiveAgentWorkspace()?.Path ?? "";
        if (string.IsNullOrWhiteSpace(path))
        {
            SetAgentConsoleControlStatus("Task chưa có workspace để mở.", error: true);
            return;
        }
        Error error = OS.ShellOpen(path);
        SetAgentConsoleControlStatus(error == Error.Ok ? $"Đã mở {path}" : $"Không mở được workspace: {error}", error: error != Error.Ok);
    }

    private void OnAgentEventKindSelected(long index)
    {
        _agentConsoleEventKindFilter = index switch
        {
            1 => "important",
            2 => "errors",
            3 => "files",
            4 => "tests",
            _ => "all",
        };
        RebuildAgentEventStream();
    }

    private void ToggleAgentEventSearch()
    {
        if (_agentConsoleEventSearchInput == null)
            return;
        bool showAdvanced = !_agentConsoleEventSearchInput.Visible;
        _agentConsoleEventSearchInput.Visible = showAdvanced;
        if (_agentConsoleEventKindSelect != null)
            _agentConsoleEventKindSelect.Visible = showAdvanced;
        if (_agentConsoleEventSearchToggle != null)
            _agentConsoleEventSearchToggle.Text = showAdvanced ? "×  Lọc" : "⌕  Lọc";

        if (showAdvanced)
        {
            _agentConsoleEventSearchInput.GrabFocus();
            return;
        }

        bool changed = !string.IsNullOrWhiteSpace(_agentConsoleEventSearchInput.Text)
            || _agentConsoleEventKindFilter != "all";
        _agentConsoleEventSearchInput.Text = "";
        _agentConsoleEventKindFilter = "all";
        if (_agentConsoleEventKindSelect != null)
            _agentConsoleEventKindSelect.Selected = 0;
        if (changed)
            RebuildAgentEventStream();
    }

    private void SendAgentDirective()
    {
        string text = (_agentConsoleDirectiveInput?.Text ?? "").Trim();
        if (string.IsNullOrWhiteSpace(text))
        {
            SetAgentConsoleControlStatus("Chỉ thị đang trống.", error: true);
            return;
        }
        if (SelectedAgentTask() == null)
        {
            EnterAgentNewTaskMode();
            SubmitAgentComposer();
            return;
        }
        SendAgentControl("directive", text: text);
        if (_agentConsoleDirectiveInput != null)
            _agentConsoleDirectiveInput.Text = "";
    }

    private void SendAgentControl(
        string action,
        string text = "",
        string checkpointId = "",
        bool quiet = false,
        string workspaceRef = "",
        string taskMode = "",
        string model = "",
        string choiceId = "",
        string choiceEventId = "")
    {
        if (_chatSend == null)
            return;
        string normalized = (action ?? "").Trim().ToLowerInvariant();
        bool taskRequired = normalized is "pause" or "resume" or "stop" or "rollback" or "directive" or "choice";
        if (taskRequired && string.IsNullOrWhiteSpace(_agentSelectedTaskId))
        {
            SetAgentConsoleControlStatus("Chưa chọn task để điều khiển.", error: true);
            return;
        }

        _agentLastRequestId = $"agent-{Time.GetTicksMsec()}-{GD.Randi()}";
        var payload = new Dictionary<string, object>
        {
            ["type"] = "agent_control",
            ["action"] = normalized,
            ["request_id"] = _agentLastRequestId,
            ["task_id"] = taskRequired ? _agentSelectedTaskId : "",
            ["selected_task_id"] = _agentSelectedTaskId,
        };
        if (!string.IsNullOrWhiteSpace(text))
            payload["text"] = text;
        if (!string.IsNullOrWhiteSpace(checkpointId))
            payload["checkpoint_id"] = checkpointId;
        if (!string.IsNullOrWhiteSpace(workspaceRef))
            payload["workspace_ref"] = workspaceRef;
        if (!string.IsNullOrWhiteSpace(taskMode))
            payload["task_mode"] = taskMode;
        if (!string.IsNullOrWhiteSpace(model))
            payload["model"] = model;
        if (!string.IsNullOrWhiteSpace(choiceId))
            payload["choice_id"] = choiceId;
        if (!string.IsNullOrWhiteSpace(choiceEventId))
            payload["choice_event_id"] = choiceEventId;

        Error error = _chatSend.PutPacket(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(payload)));
        if (error != Error.Ok)
        {
            SetAgentConsoleControlStatus($"Không gửi được Agent control: {error}", error: true);
            return;
        }
        _agentLastSnapshotRequestMs = Time.GetTicksMsec();
        if (!quiet)
        {
            string status = normalized switch
            {
                "create_task" => "Đã giao task; đang chờ Gemini khởi tạo phiên.",
                "workspace_open" => "Đang đăng ký workspace...",
                "workspace_switch" => "Đang chuyển workspace...",
                "workspace_favorite" => "Đang lưu workspace thường dùng...",
                "workspace_unfavorite" => "Đang bỏ ghim workspace...",
                "snapshot" => "Đang đồng bộ Agent Console...",
                "choice" => "Đã chọn phương án; Gemini đang tiếp tục...",
                _ => $"Đã gửi {normalized}; executor sẽ nhận ở node boundary.",
            };
            SetAgentConsoleControlStatus(status);
        }
    }

    private bool TryHandleAgentConsolePacket(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)
            || (raw.IndexOf("agent_event", StringComparison.Ordinal) < 0
                && raw.IndexOf("agent_console_ack", StringComparison.Ordinal) < 0))
            return false;
        try
        {
            using JsonDocument doc = JsonDocument.Parse(raw);
            JsonElement root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object || !root.TryGetProperty("type", out JsonElement typeNode))
                return false;
            string type = typeNode.GetString() ?? "";
            if (type == "agent_event")
            {
                if (!root.TryGetProperty("agent", out JsonElement agent) || agent.ValueKind != JsonValueKind.Object)
                    return true;
                AgentConsoleTaskView task = null;
                if (agent.TryGetProperty("task", out JsonElement taskNode) && taskNode.ValueKind == JsonValueKind.Object)
                    task = UpsertAgentTask(taskNode, replaceEvents: false);
                if (agent.TryGetProperty("event", out JsonElement eventNode) && eventNode.ValueKind == JsonValueKind.Object)
                {
                    AgentConsoleEventView ev = ParseAgentEvent(eventNode);
                    if (task != null && ev != null && !AgentEventAlreadyExists(task, ev.EventId))
                        task.Events.Add(ev);
                }
                _agentLastPacketMs = Time.GetTicksMsec();
                RefreshAgentConsole();
                if (_agentConsoleAutoFollow)
                    CallDeferred(nameof(ScrollAgentConsoleToBottom));
                return true;
            }
            if (type != "agent_console_ack")
                return false;

            _agentLastPacketMs = Time.GetTicksMsec();
            string status = AgentReadJsonString(root, "status");
            string message = AgentReadJsonString(root, "message");
            if (root.TryGetProperty("agent_console", out JsonElement console) && console.ValueKind == JsonValueKind.Object)
                ApplyAgentConsoleSnapshot(console);
            SetAgentConsoleControlStatus(
                string.IsNullOrWhiteSpace(message) ? "Agent Console đã đồng bộ." : message,
                error: status == "error");
            RefreshAgentConsole();
            if (_agentConsoleAutoFollow)
                CallDeferred(nameof(ScrollAgentConsoleToBottom));
            return true;
        }
        catch (JsonException)
        {
            return false;
        }
        catch (Exception ex)
        {
            SetAgentConsoleControlStatus($"Không đọc được Agent packet: {ex.Message}", error: true);
            return true;
        }
    }

    private void ApplyAgentConsoleSnapshot(JsonElement console)
    {
        string selected = AgentReadJsonString(console, "selected_task_id");
        _agentConsoleTasks.Clear();
        if (console.TryGetProperty("tasks", out JsonElement tasks) && tasks.ValueKind == JsonValueKind.Array)
        {
            foreach (JsonElement taskNode in tasks.EnumerateArray())
            {
                if (taskNode.ValueKind != JsonValueKind.Object)
                    continue;
                AgentConsoleTaskView task = ParseAgentTask(taskNode);
                if (task != null)
                    _agentConsoleTasks.Add(task);
            }
        }
        if (!string.IsNullOrWhiteSpace(selected))
            _agentSelectedTaskId = selected;
        if (string.IsNullOrWhiteSpace(_agentSelectedTaskId) && _agentConsoleTasks.Count > 0)
            _agentSelectedTaskId = _agentConsoleTasks[0].TaskId;
        if (SelectedAgentTask() == null && _agentConsoleTasks.Count > 0)
            _agentSelectedTaskId = _agentConsoleTasks[0].TaskId;

        if (console.TryGetProperty("workspace_state", out JsonElement workspaceState)
            && workspaceState.ValueKind == JsonValueKind.Object)
            ApplyAgentWorkspaceSnapshot(workspaceState);
    }

    private void ApplyAgentWorkspaceSnapshot(JsonElement state)
    {
        _agentConsoleActiveWorkspaceId = AgentReadJsonString(state, "active_workspace_id");
        _agentConsoleWorkspaces.Clear();
        if (state.TryGetProperty("workspaces", out JsonElement items) && items.ValueKind == JsonValueKind.Array)
        {
            foreach (JsonElement node in items.EnumerateArray())
            {
                if (node.ValueKind != JsonValueKind.Object)
                    continue;
                var workspace = new AgentWorkspaceView
                {
                    WorkspaceId = AgentReadJsonString(node, "workspace_id"),
                    DisplayName = AgentReadJsonString(node, "display_name"),
                    Path = AgentReadJsonString(node, "path"),
                    SourceType = AgentReadJsonString(node, "source_type"),
                    Branch = AgentReadJsonString(node, "default_branch"),
                    Favorite = AgentReadJsonBool(node, "favorite"),
                    Active = AgentReadJsonBool(node, "active"),
                    LastOpenedAt = AgentReadJsonDouble(node, "last_opened_at"),
                };
                if (!string.IsNullOrWhiteSpace(workspace.WorkspaceId))
                    _agentConsoleWorkspaces.Add(workspace);
            }
        }
        RefreshAgentWorkspaceUi();
    }

    private void RefreshAgentWorkspaceUi()
    {
        var signatureBuilder = new StringBuilder(_agentConsoleActiveWorkspaceId);
        foreach (AgentWorkspaceView item in _agentConsoleWorkspaces)
            signatureBuilder.Append('|').Append(item.WorkspaceId).Append(':').Append(item.DisplayName).Append(':').Append(item.Branch).Append(':').Append(item.Favorite).Append(':').Append(item.Active);
        string signature = signatureBuilder.ToString();
        if (string.Equals(signature, _agentConsoleWorkspaceUiSignature, StringComparison.Ordinal)
            && _agentConsoleWorkspaceSelect != null
            && _agentConsoleWorkspaceSelect.ItemCount > 0)
        {
            RefreshAgentWorkspaceButton();
            return;
        }
        _agentConsoleWorkspaceUiSignature = signature;

        if (_agentConsoleWorkspaceSelect != null)
        {
            _agentConsoleWorkspaceSelect.ItemSelected -= OnAgentWorkspaceSelected;
            _agentConsoleWorkspaceSelect.Clear();
            int selectedIndex = -1;
            for (int i = 0; i < _agentConsoleWorkspaces.Count; i++)
            {
                AgentWorkspaceView workspace = _agentConsoleWorkspaces[i];
                string branch = string.IsNullOrWhiteSpace(workspace.Branch) ? "" : $" / {workspace.Branch}";
                string favorite = workspace.Favorite ? "★" : "🗀";
                _agentConsoleWorkspaceSelect.AddItem($"{favorite}  {workspace.DisplayName}{branch}");
                if (workspace.Active || string.Equals(workspace.WorkspaceId, _agentConsoleActiveWorkspaceId, StringComparison.Ordinal))
                    selectedIndex = i;
            }
            if (_agentConsoleWorkspaces.Count == 0)
            {
                _agentConsoleWorkspaceSelect.AddItem("Chưa có workspace");
                _agentConsoleWorkspaceSelect.Disabled = true;
            }
            else
            {
                _agentConsoleWorkspaceSelect.Disabled = false;
                _agentConsoleWorkspaceSelect.Selected = Math.Max(0, selectedIndex);
            }
            _agentConsoleWorkspaceSelect.ItemSelected += OnAgentWorkspaceSelected;
        }

        AgentWorkspaceView active = ActiveAgentWorkspace();
        if (_agentConsoleWorkspaceFavoriteButton != null)
        {
            _agentConsoleWorkspaceFavoriteButton.Disabled = active == null;
            _agentConsoleWorkspaceFavoriteButton.Text = active?.Favorite == true ? "★  Đã ghim" : "☆  Ghim";
        }

        RefreshAgentWorkspaceButton();
    }

    private void RefreshAgentWorkspaceButton()
    {
        if (_agentConsoleWorkspaceToggleButton == null)
            return;
        AgentWorkspaceView active = ActiveAgentWorkspace();
        string name = active == null ? "Chọn workspace" : CompactAgentText(active.DisplayName, 22);
        string prefix = _agentConsoleWorkspaceVisible ? "⌃" : "▦";
        _agentConsoleWorkspaceToggleButton.Text = $"{prefix}  {name}";
        _agentConsoleWorkspaceToggleButton.TooltipText = active == null
            ? "Chọn workspace cho task"
            : $"Workspace: {active.Path}";
    }

    private AgentConsoleTaskView UpsertAgentTask(JsonElement node, bool replaceEvents)
    {
        string taskId = AgentReadJsonString(node, "task_id");
        if (string.IsNullOrWhiteSpace(taskId))
            return null;
        AgentConsoleTaskView existing = FindAgentTask(taskId);
        AgentConsoleTaskView parsed = ParseAgentTask(node);
        if (parsed == null)
            return existing;
        if (existing == null)
        {
            _agentConsoleTasks.Insert(0, parsed);
            // Luôn auto-select task mới để chat liên tiếp không bị stuck ở task cũ
            _agentSelectedTaskId = parsed.TaskId;
            _agentConsoleCreatingTask = false;
            // Reset stream tracking để force rebuild cho task mới
            _agentConsoleStreamTaskId = "";
            _agentConsoleStreamRenderedCount = 0;
            _agentConsoleTaskListSignature = "";
            return parsed;
        }

        List<AgentConsoleEventView> oldEvents = existing.Events;
        CopyAgentTaskProjection(existing, parsed);
        if (replaceEvents || parsed.Events.Count > 0)
            existing.Events = parsed.Events;
        else
            existing.Events = oldEvents;
        return existing;
    }

    private static void CopyAgentTaskProjection(AgentConsoleTaskView target, AgentConsoleTaskView source)
    {
        target.Goal = source.Goal;
        target.ClarifiedGoal = source.ClarifiedGoal;
        target.Status = source.Status;
        target.Executor = source.Executor;
        target.Model = source.Model;
        target.CurrentStep = source.CurrentStep;
        target.PendingControls = source.PendingControls;
        target.CheckpointId = source.CheckpointId;
        target.CheckpointCount = source.CheckpointCount;
        target.TestsPassed = source.TestsPassed;
        target.TestsFailed = source.TestsFailed;
        target.TestsSummary = source.TestsSummary;
        target.ActiveSkills = source.ActiveSkills;
        target.ChangedFiles = source.ChangedFiles;
        target.CreatedAt = source.CreatedAt;
        target.StartedAt = source.StartedAt;
        target.FinishedAt = source.FinishedAt;
        target.UpdatedAt = source.UpdatedAt;
        target.Source = source.Source;
        target.TaskMode = source.TaskMode;
        target.WorkspaceId = source.WorkspaceId;
        target.WorkspacePath = source.WorkspacePath;
        target.WorkspaceName = source.WorkspaceName;
    }

    private AgentConsoleTaskView ParseAgentTask(JsonElement node)
    {
        string taskId = AgentReadJsonString(node, "task_id");
        if (string.IsNullOrWhiteSpace(taskId))
            return null;
        var task = new AgentConsoleTaskView
        {
            TaskId = taskId,
            Goal = AgentReadJsonString(node, "goal"),
            ClarifiedGoal = AgentReadJsonString(node, "clarified_goal"),
            Status = AgentReadJsonString(node, "status"),
            Executor = AgentReadJsonString(node, "executor"),
            Model = AgentReadJsonString(node, "model"),
            CurrentStep = AgentReadJsonInt(node, "current_step"),
            PendingControls = AgentReadJsonInt(node, "pending_controls"),
            CheckpointId = AgentReadJsonString(node, "checkpoint_id"),
            CheckpointCount = AgentReadJsonInt(node, "checkpoint_count"),
            CreatedAt = AgentReadJsonDouble(node, "created_at"),
            StartedAt = AgentReadJsonDouble(node, "started_at"),
            FinishedAt = AgentReadJsonDouble(node, "finished_at"),
            UpdatedAt = AgentReadJsonDouble(node, "updated_at"),
        };
        if (string.IsNullOrWhiteSpace(task.Status)) task.Status = "queued";
        if (string.IsNullOrWhiteSpace(task.Executor)) task.Executor = "executor";

        if (node.TryGetProperty("active_skills", out JsonElement skills) && skills.ValueKind == JsonValueKind.Array)
            foreach (JsonElement item in skills.EnumerateArray())
                if (item.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(item.GetString()))
                    task.ActiveSkills.Add(item.GetString());
        if (node.TryGetProperty("changed_files", out JsonElement files) && files.ValueKind == JsonValueKind.Array)
            foreach (JsonElement item in files.EnumerateArray())
                if (item.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(item.GetString()))
                    task.ChangedFiles.Add(item.GetString());
        if (node.TryGetProperty("tests", out JsonElement tests) && tests.ValueKind == JsonValueKind.Object)
        {
            task.TestsPassed = AgentReadJsonInt(tests, "passed");
            task.TestsFailed = AgentReadJsonInt(tests, "failed");
            task.TestsSummary = AgentReadJsonString(tests, "summary");
        }
        if (node.TryGetProperty("metadata", out JsonElement metadata) && metadata.ValueKind == JsonValueKind.Object)
        {
            task.Source = AgentReadJsonString(metadata, "source");
            task.TaskMode = AgentReadJsonString(metadata, "task_mode");
            task.WorkspaceId = AgentReadJsonString(metadata, "workspace_id");
            task.WorkspacePath = AgentReadJsonString(metadata, "workspace_path");
            task.WorkspaceName = AgentReadJsonString(metadata, "workspace_name");
        }
        if (string.IsNullOrWhiteSpace(task.TaskMode)) task.TaskMode = "execute";
        if (node.TryGetProperty("events", out JsonElement events) && events.ValueKind == JsonValueKind.Array)
            foreach (JsonElement eventNode in events.EnumerateArray())
            {
                AgentConsoleEventView ev = ParseAgentEvent(eventNode);
                if (ev != null)
                    task.Events.Add(ev);
            }
        return task;
    }

    private AgentConsoleEventView ParseAgentEvent(JsonElement node)
    {
        if (node.ValueKind != JsonValueKind.Object)
            return null;
        var ev = new AgentConsoleEventView
        {
            EventId = AgentReadJsonString(node, "event_id"),
            Type = AgentReadJsonString(node, "type"),
            Actor = AgentReadJsonString(node, "actor"),
            Summary = AgentReadJsonString(node, "summary"),
            Detail = AgentReadJsonString(node, "detail"),
            Step = AgentReadJsonInt(node, "step"),
            Importance = (float)AgentReadJsonDouble(node, "importance"),
            CreatedAt = AgentReadJsonDouble(node, "created_at"),
        };
        if (string.IsNullOrWhiteSpace(ev.Actor)) ev.Actor = "system";
        if (string.IsNullOrWhiteSpace(ev.Type)) ev.Type = "agent_status";
        if (node.TryGetProperty("data", out JsonElement data) && data.ValueKind == JsonValueKind.Object)
        {
            ev.DataText = CompactAgentData(data);
            ev.Question = AgentReadJsonString(data, "question");
            ev.AllowOther = !data.TryGetProperty("allow_other", out JsonElement allowNode)
                || allowNode.ValueKind != JsonValueKind.False;
            if (data.TryGetProperty("options", out JsonElement options) && options.ValueKind == JsonValueKind.Array)
            {
                foreach (JsonElement option in options.EnumerateArray())
                {
                    if (option.ValueKind != JsonValueKind.Object)
                        continue;
                    string label = AgentReadJsonString(option, "label");
                    if (string.IsNullOrWhiteSpace(label))
                        continue;
                    ev.Choices.Add(new AgentConsoleChoiceView
                    {
                        Id = AgentReadJsonString(option, "id"),
                        Label = label,
                        Description = AgentReadJsonString(option, "description"),
                        Value = AgentReadJsonString(option, "value"),
                    });
                }
            }
        }
        return ev;
    }

    private static bool AgentEventAlreadyExists(AgentConsoleTaskView task, string eventId)
    {
        if (task == null || string.IsNullOrWhiteSpace(eventId))
            return false;
        foreach (AgentConsoleEventView ev in task.Events)
            if (string.Equals(ev.EventId, eventId, StringComparison.Ordinal))
                return true;
        return false;
    }

    private void RefreshAgentConsole()
    {
        if (_agentConsoleTaskList == null || _agentConsoleEventList == null)
            return;
        RefreshAgentWorkspaceUi();
        RebuildAgentTaskList();
        RebuildAgentEventStream();
        RefreshAgentInspectorForTask();
        RefreshAgentConsoleControls();
    }

    private void RebuildAgentTaskList()
    {
        // Signature check: skip rebuild nếu danh sách task không thay đổi
        var sig = new System.Text.StringBuilder(_agentSelectedTaskId);
        foreach (AgentConsoleTaskView t in _agentConsoleTasks)
            sig.Append('|').Append(t.TaskId).Append(':').Append(t.Status).Append(':').Append(t.CurrentStep);
        string signature = sig.ToString();
        if (string.Equals(signature, _agentConsoleTaskListSignature, StringComparison.Ordinal)
            && _agentConsoleTaskList.GetChildCount() > 0)
            return;
        _agentConsoleTaskListSignature = signature;

        ClearAgentChildren(_agentConsoleTaskList);
        if (_agentConsoleTasks.Count == 0)
        {
            _agentConsoleTaskList.AddChild(AgentConsoleLabel("Chưa có chat nào.", 10, AgentConsoleMuted));
            return;
        }

        foreach (AgentConsoleTaskView task in _agentConsoleTasks)
        {
            AgentConsoleTaskView captured = task;
            bool selected = string.Equals(task.TaskId, _agentSelectedTaskId, StringComparison.Ordinal);
            var button = new Button
            {
                Text = $"{CompactAgentText(task.Goal, 30)}\n{AgentStatusGlyph(task.Status)} {AgentStatusLabel(task.Status)}",
                CustomMinimumSize = new Vector2(0f, 52f),
                SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
                Alignment = HorizontalAlignment.Left,
                FocusMode = Control.FocusModeEnum.None,
                MouseDefaultCursorShape = Control.CursorShape.PointingHand,
            };
            button.AddThemeFontOverride("font", AgentConsoleFont(false));
            button.AddThemeFontSizeOverride("font_size", 10);
            button.AddThemeColorOverride("font_color", selected ? AgentConsoleInk : AgentConsoleMuted);
            button.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
                selected ? new Color(0.085f, 0.145f, 0.105f, 0.96f) : Colors.Transparent,
                selected ? new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.28f) : Colors.Transparent,
                10,
                selected ? 1 : 0));
            button.AddThemeStyleboxOverride("hover", AgentConsoleStyle(
                new Color(0.065f, 0.085f, 0.090f, 0.92f),
                new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.22f),
                10,
                1));
            button.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            button.Pressed += () =>
            {
                _agentSelectedTaskId = captured.TaskId;
                _agentConsoleCreatingTask = false;
                // Reset stream để force rebuild khi switch task
                _agentConsoleStreamTaskId = "";
                _agentConsoleStreamRenderedCount = 0;
                _agentConsoleTaskListSignature = "";
                RefreshAgentConsole();
                SendAgentControl("snapshot", quiet: true);
            };
            _agentConsoleTaskList.AddChild(button);
        }
    }

    private void RebuildAgentEventStream()
    {
        AgentConsoleTaskView task = SelectedAgentTask();
        string searchQuery = _agentConsoleEventSearchInput?.Text ?? "";

        if (task == null)
        {
            _agentConsoleStreamTaskId = "";
            _agentConsoleStreamRenderedCount = 0;
            ClearAgentChildren(_agentConsoleEventList);
            if (_agentConsoleTaskTitleLabel != null)
                _agentConsoleTaskTitleLabel.Text = _agentConsoleCreatingTask ? "Chat mới" : "Eris Console";
            _agentConsoleEventList.AddChild(BuildAgentEmptyState(
                ActiveAgentWorkspace() == null
                    ? "Chọn workspace ở cột trái rồi nhắn ở dưới để bắt đầu."
                    : $"Workspace {ActiveAgentWorkspace().DisplayName} đã sẵn sàng. Nhắn ở dưới để bắt đầu."));
            CallDeferred(nameof(ResetAgentConsoleEventScrollTop));
            return;
        }

        if (_agentConsoleTaskTitleLabel != null)
            _agentConsoleTaskTitleLabel.Text = CompactAgentText(
                string.IsNullOrWhiteSpace(task.ClarifiedGoal) ? task.Goal : task.ClarifiedGoal,
                78);

        // Thu thập các event visible theo filter hiện tại
        int start = Math.Max(0, task.Events.Count - 200);
        var visible = new List<AgentConsoleEventView>();
        for (int i = start; i < task.Events.Count; i++)
        {
            AgentConsoleEventView ev = task.Events[i];
            if (!AgentEventVisibleInSimpleTimeline(ev)) continue;
            if (!AgentEventMatchesFilter(ev, _agentConsoleEventFilter)) continue;
            if (!AgentEventMatchesKind(ev, _agentConsoleEventKindFilter)) continue;
            if (!AgentEventMatchesSearch(ev, searchQuery)) continue;
            visible.Add(ev);
        }

        // Incremental append: nếu cùng task + filter + đếm chỉ tăng, chỉ thêm card mới
        bool sameContext =
            string.Equals(_agentConsoleStreamTaskId, task.TaskId, StringComparison.Ordinal) &&
            _agentConsoleStreamFilter == _agentConsoleEventFilter &&
            _agentConsoleStreamKind == _agentConsoleEventKindFilter &&
            _agentConsoleStreamSearch == searchQuery &&
            _agentConsoleStreamRenderedCount > 0;

        if (sameContext && visible.Count >= _agentConsoleStreamRenderedCount)
        {
            // Chỉ append card mới — không xóa, không rebuild
            for (int i = _agentConsoleStreamRenderedCount; i < visible.Count; i++)
                _agentConsoleEventList.AddChild(BuildAgentEventCard(visible[i]));
            _agentConsoleStreamRenderedCount = visible.Count;
            return;
        }

        // Full rebuild khi context thay đổi (switch task, đổi filter, search...)
        ClearAgentChildren(_agentConsoleEventList);
        _agentConsoleStreamTaskId = task.TaskId;
        _agentConsoleStreamFilter = _agentConsoleEventFilter;
        _agentConsoleStreamKind = _agentConsoleEventKindFilter;
        _agentConsoleStreamSearch = searchQuery;
        _agentConsoleStreamRenderedCount = 0;

        if (visible.Count == 0)
        {
            _agentConsoleEventList.AddChild(BuildAgentEmptyState("Task đã tạo. Gemini đang bắt đầu làm việc..."));
            CallDeferred(nameof(ResetAgentConsoleEventScrollTop));
            return;
        }

        foreach (AgentConsoleEventView ev in visible)
            _agentConsoleEventList.AddChild(BuildAgentEventCard(ev));
        _agentConsoleStreamRenderedCount = visible.Count;
    }

    private static bool AgentEventVisibleInSimpleTimeline(AgentConsoleEventView ev)
    {
        if (ev == null)
            return false;
        string actor = (ev.Actor ?? "").Trim().ToLowerInvariant();
        string type = (ev.Type ?? "").Trim().ToLowerInvariant();

        // Những event này hữu ích cho trace/backend nhưng vô nghĩa trong một chat timeline.
        // Giấu chúng trước để executor/tool không vô tình biến UI thành terminal log.
        if (type is "agent_status" or "tool_started" or "tool_result" or "skill_search"
            or "directive_consumed" or "choice_consumed")
            return false;
        if (type.StartsWith("tool_", StringComparison.Ordinal)
            || type.StartsWith("skill_", StringComparison.Ordinal))
            return false;

        // Hội thoại thật giữa user / Eris.
        if (type is "task_started" or "agent_summary" or "task_completed"
            or "clarification_requested" or "user_directive" or "user_choice")
            return true;
        if (type.StartsWith("supervisor_", StringComparison.Ordinal))
            return true;
        if (actor is "user" or "eris")
            return true;

        // Tiến độ có meaning: plan, file, test, checkpoint và các trạng thái quan trọng.
        if (type == "agent_plan"
            || type.StartsWith("file_", StringComparison.Ordinal)
            || type.StartsWith("test_", StringComparison.Ordinal)
            || type.StartsWith("checkpoint_", StringComparison.Ordinal)
            || type.StartsWith("diff_", StringComparison.Ordinal)
            || type.StartsWith("permission_", StringComparison.Ordinal)
            || type.StartsWith("rollback_", StringComparison.Ordinal)
            || type is "task_failed" or "task_paused" or "task_resumed" or "task_stopped")
            return true;
        if (type.Contains("fail", StringComparison.Ordinal)
            || type.Contains("error", StringComparison.Ordinal)
            || type.Contains("veto", StringComparison.Ordinal))
            return true;

        return false;
    }

    private Control BuildAgentEventCard(AgentConsoleEventView ev)
    {
        if (string.Equals(ev?.Type, "clarification_requested", StringComparison.OrdinalIgnoreCase)
            && ev.Choices != null && ev.Choices.Count >= 2)
            return BuildAgentChoiceCard(ev);

        string actor = (ev.Actor ?? "").Trim().ToLowerInvariant();
        string type = (ev.Type ?? "").Trim().ToLowerInvariant();
        bool conversational = actor is "eris" or "user"
            || type.StartsWith("supervisor_", StringComparison.Ordinal)
            || type is "task_started" or "agent_summary" or "task_completed"
                or "clarification_requested" or "user_directive" or "user_choice";
        return conversational ? BuildAgentConversationEvent(ev) : BuildAgentCompactEvent(ev);
    }

    private Control BuildAgentChoiceCard(AgentConsoleEventView ev)
    {
        AgentConsoleTaskView task = SelectedAgentTask();
        bool pending = AgentChoicePending(task, ev);
        var outer = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        outer.AddThemeConstantOverride("separation", 8);
        outer.AddChild(new Control { CustomMinimumSize = new Vector2(28f, 0f), MouseFilter = Control.MouseFilterEnum.Ignore });

        var panel = new PanelContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            new Color(0.055f, 0.072f, 0.078f, 0.995f),
            new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, pending ? 0.34f : 0.18f),
            16,
            1,
            shadow: true));
        var margin = AgentConsoleMargin(16, 14, 16, 14);
        panel.AddChild(margin);
        var box = new VBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, MouseFilter = Control.MouseFilterEnum.Ignore };
        box.AddThemeConstantOverride("separation", 10);
        margin.AddChild(box);

        var author = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        author.AddThemeConstantOverride("separation", 7);
        author.AddChild(AgentConsoleLabel("✦", 15, AgentConsoleGreen, bold: true));
        var eris = AgentConsoleLabel("Eris", 11, AgentConsoleGreen, bold: true);
        eris.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        author.AddChild(eris);
        if (ev.CreatedAt > 0)
            author.AddChild(AgentConsoleLabel(AgentTimeText(ev.CreatedAt), 9, AgentConsoleFaint));
        box.AddChild(author);

        string questionText = string.IsNullOrWhiteSpace(ev.Question) ? ev.Summary : ev.Question;
        Label question = AgentConsoleLabel(questionText, 14, AgentConsoleInk, bold: true);
        question.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        box.AddChild(question);

        string helperText = string.IsNullOrWhiteSpace(ev.Detail)
            ? "Chọn một phương án bên dưới để tiếp tục."
            : ev.Detail;
        Label helper = AgentConsoleLabel(helperText, 10, AgentConsoleMuted);
        helper.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        box.AddChild(helper);

        for (int index = 0; index < ev.Choices.Count; index++)
        {
            AgentConsoleChoiceView choice = ev.Choices[index];
            AgentConsoleChoiceView capturedChoice = choice;
            string description = string.IsNullOrWhiteSpace(choice.Description) ? "" : "\n    " + choice.Description;
            var option = new Button
            {
                Text = $"{index + 1}    {choice.Label}{description}",
                Alignment = HorizontalAlignment.Left,
                CustomMinimumSize = new Vector2(0f, string.IsNullOrWhiteSpace(choice.Description) ? 52f : 72f),
                SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
                FocusMode = Control.FocusModeEnum.None,
                MouseDefaultCursorShape = pending ? Control.CursorShape.PointingHand : Control.CursorShape.Arrow,
                Disabled = !pending,
                TooltipText = pending ? "Chọn phương án này" : "Lựa chọn này đã được xử lý.",
            };
            option.AddThemeFontOverride("font", AgentConsoleFont(false));
            option.AddThemeFontSizeOverride("font_size", 11);
            option.AddThemeColorOverride("font_color", AgentConsoleInk);
            option.AddThemeColorOverride("font_hover_color", Colors.White);
            option.AddThemeColorOverride("font_disabled_color", new Color(AgentConsoleMuted.R, AgentConsoleMuted.G, AgentConsoleMuted.B, 0.70f));
            option.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
                new Color(0.070f, 0.090f, 0.096f, 1f),
                new Color(0.18f, 0.23f, 0.21f, 0.92f),
                13,
                1));
            option.AddThemeStyleboxOverride("hover", AgentConsoleStyle(
                new Color(0.082f, 0.112f, 0.098f, 1f),
                new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.64f),
                13,
                1));
            option.AddThemeStyleboxOverride("pressed", AgentConsoleStyle(
                new Color(0.10f, 0.15f, 0.115f, 1f),
                new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.82f),
                13,
                1));
            option.AddThemeStyleboxOverride("disabled", AgentConsoleStyle(
                new Color(0.052f, 0.064f, 0.068f, 0.92f),
                new Color(0.13f, 0.15f, 0.14f, 0.75f),
                13,
                1));
            option.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            option.Pressed += () => SendAgentChoice(ev, capturedChoice);
            box.AddChild(option);
        }

        if (ev.AllowOther)
        {
            var other = AgentConsoleQuietButton("✎   Khác · viết phương án của bạn", () =>
            {
                if (_agentConsoleDirectiveInput == null)
                    return;
                _agentConsoleDirectiveInput.Text = "";
                _agentConsoleDirectiveInput.PlaceholderText = "Viết phương án khác...";
                _agentConsoleDirectiveInput.GrabFocus();
            }, 0f);
            other.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            other.CustomMinimumSize = new Vector2(0f, 44f);
            other.Disabled = !pending;
            box.AddChild(other);
        }

        if (!pending)
            box.AddChild(AgentConsoleLabel("Đã nhận lựa chọn · Gemini đang tiếp tục.", 9, AgentConsoleFaint));

        outer.AddChild(panel);
        outer.AddChild(new Control { CustomMinimumSize = new Vector2(36f, 0f), MouseFilter = Control.MouseFilterEnum.Ignore });
        return outer;
    }

    private bool AgentChoicePending(AgentConsoleTaskView task, AgentConsoleEventView ev)
    {
        if (task == null || ev == null || !string.Equals(task.Status, "waiting_user", StringComparison.OrdinalIgnoreCase))
            return false;
        foreach (AgentConsoleEventView item in task.Events)
        {
            if (item.CreatedAt <= ev.CreatedAt)
                continue;
            string type = (item.Type ?? "").Trim().ToLowerInvariant();
            if (type is "user_choice" or "user_directive" or "task_resumed")
                return false;
        }
        return true;
    }

    private void SendAgentChoice(AgentConsoleEventView ev, AgentConsoleChoiceView choice)
    {
        if (ev == null || choice == null || string.IsNullOrWhiteSpace(_agentSelectedTaskId))
            return;
        AgentConsoleTaskView task = SelectedAgentTask();
        if (!AgentChoicePending(task, ev))
        {
            SetAgentConsoleControlStatus("Lựa chọn này đã được xử lý.", error: true);
            return;
        }
        string value = string.IsNullOrWhiteSpace(choice.Value) ? choice.Label : choice.Value;
        string text = string.Equals(value.Trim(), choice.Label.Trim(), StringComparison.OrdinalIgnoreCase)
            ? $"Tôi chọn: {choice.Label}"
            : $"Tôi chọn: {choice.Label}\n{value}";
        SendAgentControl(
            "choice",
            text: text,
            choiceId: choice.Id,
            choiceEventId: ev.EventId);
    }

    private Control BuildAgentConversationEvent(AgentConsoleEventView ev)
    {
        Color accent = AgentActorColor(ev.Actor, ev.Type);
        bool isUser = string.Equals(ev.Actor, "user", StringComparison.OrdinalIgnoreCase)
            || string.Equals(ev.Type, "task_started", StringComparison.OrdinalIgnoreCase)
            || string.Equals(ev.Type, "user_directive", StringComparison.OrdinalIgnoreCase)
            || string.Equals(ev.Type, "user_choice", StringComparison.OrdinalIgnoreCase);

        var outer = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        outer.AddThemeConstantOverride("separation", 8);
        if (isUser)
            outer.AddChild(new Control { CustomMinimumSize = new Vector2(70f, 0f), MouseFilter = Control.MouseFilterEnum.Ignore });

        var panel = new PanelContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        Color bubble = isUser
            ? new Color(0.070f, 0.086f, 0.094f, 0.99f)
            : new Color(0.057f, 0.075f, 0.081f, 0.99f);
        panel.AddThemeStyleboxOverride("panel", AgentConsoleStyle(
            bubble,
            new Color(accent.R, accent.G, accent.B, isUser ? 0.16f : 0.24f),
            13,
            1));
        var margin = AgentConsoleMargin(11, 8, 11, 8);
        panel.AddChild(margin);
        var box = new VBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        box.AddThemeConstantOverride("separation", 3);
        margin.AddChild(box);

        var top = new HBoxContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        Label actorLabel = AgentConsoleLabel(AgentActorLabel(ev.Actor, ev.Type), 9, accent, bold: true);
        actorLabel.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        top.AddChild(actorLabel);
        if (ev.CreatedAt > 0)
            top.AddChild(AgentConsoleLabel(AgentTimeText(ev.CreatedAt), 8, AgentConsoleFaint));
        box.AddChild(top);

        Label summary = AgentConsoleLabel(
            string.IsNullOrWhiteSpace(ev.Summary) ? AgentEventLabel(ev.Type) : ev.Summary,
            11,
            AgentConsoleInk);
        summary.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        box.AddChild(summary);

        if (!string.IsNullOrWhiteSpace(ev.Detail))
        {
            Label detail = AgentConsoleLabel(CompactAgentText(ev.Detail, 1600), 9, AgentConsoleMuted);
            detail.AutowrapMode = TextServer.AutowrapMode.WordSmart;
            box.AddChild(detail);
        }
        outer.AddChild(panel);
        if (!isUser)
            outer.AddChild(new Control { CustomMinimumSize = new Vector2(40f, 0f), MouseFilter = Control.MouseFilterEnum.Ignore });
        return outer;
    }

    private Control BuildAgentCompactEvent(AgentConsoleEventView ev)
    {
        Color accent = AgentActorColor(ev.Actor, ev.Type);
        var row = new HBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
            TooltipText = string.Join("\n", new[] { ev.Detail, ev.DataText }).Trim(),
        };
        row.AddThemeConstantOverride("separation", 7);
        Label dot = AgentConsoleLabel("•", 11, accent, bold: true);
        dot.CustomMinimumSize = new Vector2(10f, 0f);
        row.AddChild(dot);
        Label kind = AgentConsoleLabel(AgentEventLabel(ev.Type), 9, accent, bold: true);
        kind.CustomMinimumSize = new Vector2(86f, 0f);
        row.AddChild(kind);
        Label summary = AgentConsoleLabel(
            string.IsNullOrWhiteSpace(ev.Summary) ? AgentActorLabel(ev.Actor, ev.Type) : CompactAgentText(ev.Summary, 220),
            9,
            AgentConsoleMuted);
        summary.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
        summary.TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis;
        summary.ClipText = true;
        row.AddChild(summary);
        if (ev.CreatedAt > 0)
            row.AddChild(AgentConsoleLabel(AgentTimeText(ev.CreatedAt), 8, AgentConsoleFaint));
        return row;
    }

    private Control BuildAgentEmptyState(string message)
    {
        var outer = new CenterContainer
        {
            CustomMinimumSize = new Vector2(0f, 235f),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        var box = new VBoxContainer { CustomMinimumSize = new Vector2(420f, 180f), MouseFilter = Control.MouseFilterEnum.Ignore };
        box.AddThemeConstantOverride("separation", 8);
        outer.AddChild(box);
        TextureRect thread = AgentConsoleAssetImage("identity_trace_thread_crystal.png", new Vector2(250f, 92f), TextureRect.StretchModeEnum.KeepAspectCentered);
        if (thread != null)
        {
            thread.Modulate = new Color(1f, 1f, 1f, 0.72f);
            var imageWrap = new CenterContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
            imageWrap.AddChild(thread);
            box.AddChild(imageWrap);
        }
        else
        {
            var icon = AgentConsoleLabel("◇", 48, AgentConsoleGreen, bold: true);
            icon.HorizontalAlignment = HorizontalAlignment.Center;
            box.AddChild(icon);
        }
        Label title = AgentConsoleLabel("Chưa có task đang chạy", 16, AgentConsoleInk, bold: true);
        title.HorizontalAlignment = HorizontalAlignment.Center;
        box.AddChild(title);
        Label detail = AgentConsoleLabel(@"Hãy giao việc cho Eris. Gemini sẽ lập kế hoạch, sử dụng công cụ,
chạy task và cập nhật tiến trình tại đây.", 11, AgentConsoleMuted);
        detail.HorizontalAlignment = HorizontalAlignment.Center;
        box.AddChild(detail);
        var cta = AgentConsoleButton("＋  Tạo task mới", EnterAgentNewTaskMode, primary: false);
        cta.CustomMinimumSize = new Vector2(146f, 38f);
        var wrap = new CenterContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        wrap.AddChild(cta);
        box.AddChild(wrap);
        return outer;
    }





    private void RefreshAgentInspectorForTask()
    {
        AgentConsoleTaskView task = SelectedAgentTask();

        if (task == null)
        {
            if (_agentConsoleTaskMetaLabel != null)
                _agentConsoleTaskMetaLabel.Text = _agentConsoleCreatingTask ? "Chat mới" : "Gemini autopilot";
            if (_agentConsoleStatusLabel != null)
            {
                _agentConsoleStatusLabel.Text = "● Sẵn sàng";
                _agentConsoleStatusLabel.AddThemeColorOverride("font_color", AgentConsoleGreen);
            }
            SetAgentQuickSummary(null);
            return;
        }

        if (_agentConsoleTaskMetaLabel != null)
            _agentConsoleTaskMetaLabel.Text = $"{AgentStatusLabel(task.Status)} · {task.Executor}";
        if (_agentConsoleStatusLabel != null)
        {
            _agentConsoleStatusLabel.Text = $"● {AgentStatusLabel(task.Status)}";
            _agentConsoleStatusLabel.AddThemeColorOverride("font_color", AgentStatusColor(task.Status));
        }
        SetAgentQuickSummary(task);

        if (_agentConsoleInspectorLabel == null || _agentConsoleInspectorDetailLabel == null)
            return;
        _agentConsoleInspectorLabel.Text = CompactAgentText(task.Goal, 150);
        _agentConsoleInspectorDetailLabel.Text = $"{task.Executor} · {AgentStatusLabel(task.Status)} · bước {task.CurrentStep}";
    }

    private void RefreshAgentInspectorSkills(AgentConsoleTaskView task)
    {
        if (_agentConsoleInspectorSkillsList == null)
            return;
        ClearAgentChildren(_agentConsoleInspectorSkillsList);
        if (task == null || task.ActiveSkills.Count == 0)
        {
            _agentConsoleInspectorSkillsList.AddChild(AgentConsoleLabel("Chưa activate skill nào.", 10, AgentConsoleMuted));
            return;
        }
        int shown = 0;
        foreach (string skill in task.ActiveSkills)
        {
            if (shown++ >= 10) break;
            _agentConsoleInspectorSkillsList.AddChild(AgentConsoleChip(CompactAgentText(skill, 36), AgentConsoleBlue));
        }
    }

    private void SetAgentQuickSummary(AgentConsoleTaskView task)
    {
        if (_agentConsoleStepLabel == null)
            return;
        if (task == null)
        {
            _agentConsoleStepLabel.Text = _agentConsoleCreatingTask ? "Task mới" : "Sẵn sàng";
            _agentConsoleStepLabel.AddThemeColorOverride("font_color", AgentConsoleMuted);
            return;
        }

        string tests = task.TestsPassed == 0 && task.TestsFailed == 0
            ? ""
            : $" · test {task.TestsPassed}✓ {task.TestsFailed}×";
        string files = task.ChangedFiles.Count == 0 ? "" : $" · {task.ChangedFiles.Count} file";
        _agentConsoleStepLabel.Text = $"{AgentStatusGlyph(task.Status)} {AgentStatusLabel(task.Status)}{files}{tests}";
        _agentConsoleStepLabel.AddThemeColorOverride("font_color", task.TestsFailed > 0 ? AgentConsoleRed : AgentConsoleMuted);
    }

    private void ShowAgentEventInspector(AgentConsoleEventView ev)
    {
        if (_agentConsoleInspectorLabel == null || _agentConsoleInspectorDetailLabel == null || ev == null)
            return;
        _agentConsoleInspectorLabel.Text = $"{AgentActorLabel(ev.Actor, ev.Type)} · {AgentEventLabel(ev.Type)}";
        var sb = new StringBuilder();
        if (ev.Step > 0) sb.AppendLine($"Step: {ev.Step}");
        if (ev.CreatedAt > 0) sb.AppendLine($"Time: {AgentTimeText(ev.CreatedAt)}");
        if (!string.IsNullOrWhiteSpace(ev.Summary))
        {
            sb.AppendLine();
            sb.AppendLine(ev.Summary);
        }
        if (!string.IsNullOrWhiteSpace(ev.Detail))
        {
            sb.AppendLine();
            sb.AppendLine(ev.Detail);
        }
        if (!string.IsNullOrWhiteSpace(ev.DataText))
        {
            sb.AppendLine();
            sb.AppendLine("Metadata:");
            sb.AppendLine(ev.DataText);
        }
        _agentConsoleInspectorDetailLabel.Text = sb.ToString().TrimEnd();
    }

    private void RefreshAgentConsoleControls()
    {
        AgentConsoleTaskView task = SelectedAgentTask();
        bool hasTask = task != null;
        string status = task?.Status ?? "";
        bool terminal = AgentTaskTerminal(status);

        if (_agentConsolePauseButton != null)
            _agentConsolePauseButton.Visible = false;
        if (_agentConsoleResumeButton != null)
            _agentConsoleResumeButton.Visible = false;
        if (_agentConsoleStopButton != null)
        {
            _agentConsoleStopButton.Visible = hasTask && !terminal;
            _agentConsoleStopButton.Disabled = !hasTask || terminal;
        }
        if (_agentConsoleRollbackButton != null)
            _agentConsoleRollbackButton.Visible = false;
        if (_agentConsoleTaskModeSelect != null)
            _agentConsoleTaskModeSelect.Visible = false;
        if (_agentConsoleModelSelect != null)
            _agentConsoleModelSelect.Visible = false;

        if (_agentConsoleDirectiveInput != null)
        {
            _agentConsoleDirectiveInput.Editable = true;
            _agentConsoleDirectiveInput.PlaceholderText = _agentConsoleCreatingTask || !hasTask || terminal
                ? "Giao task mới cho Gemini..."
                : string.Equals(status, "waiting_user", StringComparison.OrdinalIgnoreCase)
                    ? "Trả lời hoặc viết phương án khác..."
                    : "Nhắn thêm cho Gemini...";
        }
        if (_agentConsoleSendButton != null)
        {
            _agentConsoleSendButton.Text = "Gửi";
            _agentConsoleSendButton.Disabled = false;
        }
    }

    private AgentConsoleTaskView SelectedAgentTask()
    {
        return FindAgentTask(_agentSelectedTaskId);
    }

    private AgentConsoleTaskView FindAgentTask(string taskId)
    {
        if (string.IsNullOrWhiteSpace(taskId))
            return null;
        foreach (AgentConsoleTaskView task in _agentConsoleTasks)
            if (string.Equals(task.TaskId, taskId, StringComparison.Ordinal))
                return task;
        return null;
    }

    private void ScrollAgentConsoleToBottom()
    {
        if (_agentConsoleEventScroll == null)
            return;
        AgentConsoleTaskView task = SelectedAgentTask();
        if (task == null || task.Events.Count == 0)
        {
            ResetAgentConsoleEventScrollTop();
            return;
        }
        VScrollBar bar = _agentConsoleEventScroll.GetVScrollBar();
        if (bar != null)
            bar.Value = bar.MaxValue;
    }

    private void ResetAgentConsoleEventScrollTop()
    {
        if (_agentConsoleEventScroll == null)
            return;
        VScrollBar bar = _agentConsoleEventScroll.GetVScrollBar();
        if (bar != null)
            bar.Value = 0;
    }

    private void SetAgentConsoleControlStatus(string text, bool error = false)
    {
        if (_agentConsoleControlStatusLabel == null)
            return;
        _agentConsoleControlStatusLabel.Text = text ?? "";
        _agentConsoleControlStatusLabel.AddThemeColorOverride("font_color", error ? AgentConsoleRed : AgentConsoleMuted);
    }

    private static void ClearAgentChildren(Control parent)
    {
        if (parent == null)
            return;
        foreach (Node child in parent.GetChildren())
            child.QueueFree();
    }

    private static string CompactAgentData(JsonElement data)
    {
        var sb = new StringBuilder();
        int count = 0;
        foreach (JsonProperty prop in data.EnumerateObject())
        {
            if (count++ >= 16)
            {
                sb.AppendLine("…");
                break;
            }
            string value;
            if (prop.Value.ValueKind == JsonValueKind.String)
                value = prop.Value.GetString() ?? "";
            else
                value = prop.Value.GetRawText();
            sb.Append(prop.Name).Append(": ").AppendLine(CompactAgentText(value, 260));
        }
        return sb.ToString().TrimEnd();
    }

    private static string AgentReadJsonString(JsonElement root, string name)
    {
        if (!root.TryGetProperty(name, out JsonElement node))
            return "";
        if (node.ValueKind == JsonValueKind.String)
            return node.GetString() ?? "";
        if (node.ValueKind is JsonValueKind.Number or JsonValueKind.True or JsonValueKind.False)
            return node.ToString();
        return "";
    }

    private static int AgentReadJsonInt(JsonElement root, string name)
    {
        if (!root.TryGetProperty(name, out JsonElement node))
            return 0;
        if (node.ValueKind == JsonValueKind.Number && node.TryGetInt32(out int value))
            return value;
        return int.TryParse(node.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value) ? value : 0;
    }

    private static bool AgentReadJsonBool(JsonElement root, string name)
    {
        if (!root.TryGetProperty(name, out JsonElement node))
            return false;
        if (node.ValueKind == JsonValueKind.True) return true;
        if (node.ValueKind == JsonValueKind.False) return false;
        return bool.TryParse(node.ToString(), out bool value) && value;
    }

    private static double AgentReadJsonDouble(JsonElement root, string name)
    {
        if (!root.TryGetProperty(name, out JsonElement node))
            return 0.0;
        if (node.ValueKind == JsonValueKind.Number && node.TryGetDouble(out double value))
            return value;
        return double.TryParse(node.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out value) ? value : 0.0;
    }

    private static double AgentTaskProgressEstimate(AgentConsoleTaskView task)
    {
        if (task == null) return 0.0;
        string status = (task.Status ?? "").ToLowerInvariant();
        if (status == "completed") return 100.0;
        if (status is "failed" or "stopped") return 100.0;
        if (status == "queued") return 3.0;
        double byStep = 8.0 + Math.Min(82.0, Math.Max(0, task.CurrentStep) * 7.0);
        if (status == "paused") return Math.Min(92.0, byStep);
        return Math.Min(92.0, byStep);
    }

    private static string AgentDurationText(double seconds)
    {
        TimeSpan span = TimeSpan.FromSeconds(Math.Max(0, seconds));
        if (span.TotalHours >= 1)
            return $"{(int)span.TotalHours:00}:{span.Minutes:00}:{span.Seconds:00}";
        return $"{span.Minutes:00}:{span.Seconds:00}";
    }

    private static string AgentDateTimeText(double unix)
    {
        try
        {
            return DateTimeOffset.FromUnixTimeMilliseconds((long)(unix * 1000.0)).ToLocalTime().ToString("dd/MM HH:mm:ss", CultureInfo.InvariantCulture);
        }
        catch (ArgumentOutOfRangeException)
        {
            return "—";
        }
    }

    private static string AgentTimeText(double unix)
    {
        try
        {
            return DateTimeOffset.FromUnixTimeMilliseconds((long)(unix * 1000.0)).ToLocalTime().ToString("HH:mm:ss", CultureInfo.InvariantCulture);
        }
        catch (ArgumentOutOfRangeException)
        {
            return "";
        }
    }

    private static string CompactAgentText(string text, int max)
    {
        string value = (text ?? "").Replace("\r", " ").Trim();
        if (value.Length <= max)
            return value;
        return value.Substring(0, Math.Max(0, max - 1)).TrimEnd() + "…";
    }

    private static string AgentActorLabel(string actor, string eventType)
    {
        string value = (actor ?? "").Trim().ToLowerInvariant();
        string type = (eventType ?? "").Trim().ToLowerInvariant();
        if (type == "task_started" || value == "user") return "Bạn";
        if (value == "eris" || type.StartsWith("supervisor_", StringComparison.Ordinal)) return "Eris";
        if (value == "executor" || value == "gemini") return "Eris · Gemini";
        if (value == "tool") return "Công cụ";
        return "Hệ thống";
    }

    private static Color AgentActorColor(string actor, string eventType)
    {
        string value = (actor ?? "").Trim().ToLowerInvariant();
        string type = (eventType ?? "").Trim().ToLowerInvariant();
        if (type == "task_started" || value == "user") return AgentConsoleBlue;
        if (value == "eris" || type.StartsWith("supervisor_", StringComparison.Ordinal)) return AgentConsoleGreen;
        if (value == "executor" || value == "gemini") return AgentConsoleGreen;
        if (value == "tool") return AgentConsoleGold;
        if (type.Contains("failed", StringComparison.Ordinal) || type.Contains("veto", StringComparison.Ordinal)) return AgentConsoleRed;
        return AgentConsoleMuted;
    }

    private static string AgentEventLabel(string eventType)
    {
        return (eventType ?? "") switch
        {
            "task_started" => "Task bắt đầu",
            "task_completed" => "Task hoàn tất",
            "task_failed" => "Task thất bại",
            "agent_plan" => "Kế hoạch bước kế",
            "agent_summary" => "Executor update",
            "skill_search" => "Tìm skill",
            "skill_activated" => "Kích hoạt skill",
            "tool_started" => "Tool call",
            "tool_result" => "Observation",
            "tool_failed" => "Tool lỗi",
            "checkpoint_created" => "Checkpoint",
            "checkpoint_restored" => "Checkpoint restored",
            "rollback_requested" => "Rollback requested",
            "rollback_queued" => "Rollback queued",
            "user_directive" => "Tin nhắn",
            "user_choice" => "Lựa chọn",
            "supervisor_comment" => "Eris bình luận",
            "supervisor_advisory" => "Eris advisory",
            "supervisor_redirect" => "Eris redirect",
            "supervisor_veto" => "Eris veto",
            "permission_requested" => "Chờ quyền",
            "clarification_requested" => "Cần hỏi user",
            _ => string.IsNullOrWhiteSpace(eventType) ? "Agent event" : eventType.Replace('_', ' '),
        };
    }

    private static string AgentStatusGlyph(string status)
    {
        return (status ?? "").ToLowerInvariant() switch
        {
            "running" => "●",
            "paused" => "Ⅱ",
            "waiting_user" => "?",
            "waiting_permission" => "!",
            "completed" => "✓",
            "failed" => "×",
            "stopped" => "■",
            _ => "○",
        };
    }

    private static string AgentStatusLabel(string status)
    {
        return (status ?? "").ToLowerInvariant() switch
        {
            "running" => "Đang chạy",
            "paused" => "Tạm dừng",
            "waiting_user" => "Chờ user",
            "waiting_permission" => "Chờ quyền",
            "completed" => "Hoàn tất",
            "failed" => "Thất bại",
            "stopped" => "Đã dừng",
            "queued" => "Xếp hàng",
            _ => string.IsNullOrWhiteSpace(status) ? "Không rõ" : status,
        };
    }

    private static Color AgentStatusColor(string status)
    {
        return (status ?? "").ToLowerInvariant() switch
        {
            "running" => AgentConsoleGreen,
            "paused" => AgentConsoleGold,
            "waiting_user" => AgentConsoleBlue,
            "waiting_permission" => AgentConsoleGold,
            "completed" => AgentConsoleGreen,
            "failed" => AgentConsoleRed,
            "stopped" => AgentConsoleRed,
            _ => AgentConsoleMuted,
        };
    }

    private static bool AgentTaskTerminal(string status)
    {
        string value = (status ?? "").ToLowerInvariant();
        return value is "completed" or "failed" or "stopped";
    }

    private static Label AgentConsoleLabel(string text, int size, Color color, bool bold = false)
    {
        var label = new Label
        {
            Text = text ?? "",
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        label.AddThemeFontOverride("font", AgentConsoleFont(bold));
        label.AddThemeFontSizeOverride("font_size", size);
        label.AddThemeColorOverride("font_color", color);
        if (bold)
            label.AddThemeConstantOverride("outline_size", 0);
        return label;
    }

    private static Label AgentConsoleChip(string text, Color color)
    {
        var label = AgentConsoleLabel(text, 10, color, bold: true);
        label.CustomMinimumSize = new Vector2(92f, 30f);
        label.HorizontalAlignment = HorizontalAlignment.Center;
        label.VerticalAlignment = VerticalAlignment.Center;
        label.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
            new Color(color.R, color.G, color.B, 0.07f),
            new Color(color.R, color.G, color.B, 0.22f),
            10,
            1));
        return label;
    }

    private static Label AgentConsoleTinyStatus(string text, Color color)
    {
        var label = AgentConsoleLabel(text, 10, color, bold: true);
        label.CustomMinimumSize = new Vector2(92f, 42f);
        label.HorizontalAlignment = HorizontalAlignment.Center;
        label.VerticalAlignment = VerticalAlignment.Center;
        label.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
            Colors.White,
            new Color(0.86f, 0.91f, 0.96f, 0.72f),
            16,
            1));
        return label;
    }

    private static Button AgentConsoleQuietButton(string text, Action onPressed, float width, bool danger = false)
    {
        Color accent = danger ? AgentConsoleRed : AgentConsoleMuted;
        var button = new Button
        {
            Text = text,
            CustomMinimumSize = new Vector2(width, 40f),
            FocusMode = Control.FocusModeEnum.None,
            MouseDefaultCursorShape = Control.CursorShape.PointingHand,
        };
        button.AddThemeFontOverride("font", AgentConsoleFont(false));
        button.AddThemeFontSizeOverride("font_size", 11);
        button.AddThemeColorOverride("font_color", danger ? AgentConsoleRed : AgentConsoleMuted);
        button.AddThemeColorOverride("font_hover_color", danger ? new Color(1f, 0.54f, 0.60f, 1f) : AgentConsoleInk);
        button.AddThemeColorOverride("font_disabled_color", new Color(AgentConsoleFaint.R, AgentConsoleFaint.G, AgentConsoleFaint.B, 0.45f));
        StyleBoxFlat normal = AgentConsoleStyle(
            new Color(0.055f, 0.071f, 0.078f, 0.98f),
            new Color(0.18f, 0.22f, 0.21f, 0.90f),
            12,
            1);
        normal.ContentMarginLeft = 11f;
        normal.ContentMarginRight = 11f;
        button.AddThemeStyleboxOverride("normal", normal);
        StyleBoxFlat hover = AgentConsoleStyle(
            new Color(0.080f, 0.105f, 0.112f, 1f),
            new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.38f),
            12,
            1);
        hover.ContentMarginLeft = 11f;
        hover.ContentMarginRight = 11f;
        button.AddThemeStyleboxOverride("hover", hover);
        StyleBoxFlat pressed = AgentConsoleStyle(
            new Color(accent.R, accent.G, accent.B, 0.13f),
            new Color(accent.R, accent.G, accent.B, 0.48f),
            12,
            1);
        pressed.ContentMarginLeft = 11f;
        pressed.ContentMarginRight = 11f;
        button.AddThemeStyleboxOverride("pressed", pressed);
        button.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
        if (onPressed != null)
            button.Pressed += onPressed;
        return button;
    }

    private static MarginContainer AgentConsoleMargin(int left, int top, int right, int bottom)
    {
        var margin = new MarginContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
        margin.AddThemeConstantOverride("margin_left", left);
        margin.AddThemeConstantOverride("margin_top", top);
        margin.AddThemeConstantOverride("margin_right", right);
        margin.AddThemeConstantOverride("margin_bottom", bottom);
        return margin;
    }

    private static StyleBoxFlat AgentConsoleStyle(Color bg, Color border, int radius, int borderWidth, bool shadow = false)
    {
        var style = new StyleBoxFlat
        {
            BgColor = bg,
            BorderColor = border,
            BorderWidthLeft = borderWidth,
            BorderWidthTop = borderWidth,
            BorderWidthRight = borderWidth,
            BorderWidthBottom = borderWidth,
            CornerRadiusTopLeft = radius,
            CornerRadiusTopRight = radius,
            CornerRadiusBottomLeft = radius,
            CornerRadiusBottomRight = radius,
            ContentMarginLeft = 7f,
            ContentMarginTop = 5f,
            ContentMarginRight = 7f,
            ContentMarginBottom = 5f,
        };
        if (shadow)
        {
            style.ShadowColor = new Color(0f, 0f, 0f, 0.34f);
            style.ShadowSize = 10;
        }
        return style;
    }

    private static Button AgentConsoleButton(string text, Action onPressed, bool primary, bool danger = false)
    {
        Color accent = danger ? AgentConsoleRed : AgentConsoleGreen;
        var button = new Button
        {
            Text = text,
            CustomMinimumSize = new Vector2(96f, 42f),
            FocusMode = Control.FocusModeEnum.None,
            MouseDefaultCursorShape = Control.CursorShape.PointingHand,
        };
        button.AddThemeFontOverride("font", AgentConsoleFont(primary));
        button.AddThemeFontSizeOverride("font_size", 12);
        button.AddThemeColorOverride("font_color", primary ? new Color(0.96f, 1f, 0.97f, 1f) : accent);
        button.AddThemeColorOverride("font_hover_color", Colors.White);
        button.AddThemeColorOverride("font_disabled_color", new Color(0.44f, 0.49f, 0.46f, 0.55f));

        StyleBoxFlat normal = AgentConsoleStyle(
            primary ? new Color(0.22f, 0.47f, 0.31f, 1f) : new Color(0.055f, 0.071f, 0.078f, 0.98f),
            primary ? new Color(0.36f, 0.78f, 0.52f, 0.78f) : new Color(accent.R, accent.G, accent.B, 0.32f),
            13,
            1,
            shadow: primary);
        normal.ContentMarginLeft = primary ? 18f : 14f;
        normal.ContentMarginRight = primary ? 18f : 14f;
        normal.ShadowSize = primary ? 8 : 0;
        normal.ShadowColor = new Color(0.14f, 0.50f, 0.27f, primary ? 0.18f : 0f);
        button.AddThemeStyleboxOverride("normal", normal);

        StyleBoxFlat hover = AgentConsoleStyle(
            primary ? new Color(0.27f, 0.57f, 0.38f, 1f) : new Color(0.080f, 0.105f, 0.112f, 1f),
            new Color(accent.R, accent.G, accent.B, 0.72f),
            13,
            1);
        hover.ContentMarginLeft = normal.ContentMarginLeft;
        hover.ContentMarginRight = normal.ContentMarginRight;
        button.AddThemeStyleboxOverride("hover", hover);
        button.AddThemeStyleboxOverride("pressed", hover);

        StyleBoxFlat disabled = AgentConsoleStyle(
            new Color(0.055f, 0.065f, 0.068f, 0.70f),
            new Color(0.15f, 0.17f, 0.16f, 0.70f),
            13,
            1);
        button.AddThemeStyleboxOverride("disabled", disabled);
        button.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
        if (onPressed != null)
            button.Pressed += onPressed;
        return button;
    }

    private static void StyleAgentConsoleOptionButton(OptionButton option)
    {
        if (option == null)
            return;
        option.AddThemeFontOverride("font", AgentConsoleFont(false));
        option.AddThemeFontSizeOverride("font_size", 11);
        option.AddThemeColorOverride("font_color", AgentConsoleInk);
        option.AddThemeColorOverride("font_hover_color", AgentConsoleInk);
        option.AddThemeColorOverride("font_disabled_color", AgentConsoleFaint);
        option.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
            new Color(0.055f, 0.071f, 0.078f, 0.98f),
            new Color(0.17f, 0.21f, 0.20f, 0.95f),
            12,
            1));
        option.AddThemeStyleboxOverride("hover", AgentConsoleStyle(
            new Color(0.072f, 0.094f, 0.100f, 1f),
            new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.44f),
            12,
            1));
        option.AddThemeStyleboxOverride("pressed", AgentConsoleStyle(
            new Color(0.072f, 0.094f, 0.100f, 1f),
            new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.58f),
            12,
            1));
        option.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
    }

    private static void StyleAgentConsoleInput(LineEdit input)
    {
        if (input == null)
            return;
        input.CustomMinimumSize = new Vector2(260f, 44f);
        input.AddThemeFontOverride("font", AgentConsoleFont(false));
        input.AddThemeFontSizeOverride("font_size", 12);
        input.AddThemeColorOverride("font_color", AgentConsoleInk);
        input.AddThemeColorOverride("caret_color", AgentConsoleGreen);
        input.AddThemeColorOverride("font_placeholder_color", new Color(AgentConsoleMuted.R, AgentConsoleMuted.G, AgentConsoleMuted.B, 0.68f));
        input.AddThemeStyleboxOverride("normal", AgentConsoleStyle(
            new Color(0.050f, 0.064f, 0.070f, 0.98f),
            new Color(0.18f, 0.23f, 0.21f, 0.96f),
            13,
            1));
        input.AddThemeStyleboxOverride("focus", AgentConsoleStyle(
            new Color(0.055f, 0.071f, 0.078f, 1f),
            new Color(AgentConsoleGreen.R, AgentConsoleGreen.G, AgentConsoleGreen.B, 0.62f),
            13,
            1));
    }
}
